import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.38.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const GENERIC_ERROR = 'Dados informados não conferem';

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const body = await req.json();
    const { step, identifier, matricula, newPassword } = body;

    if (!step || !identifier) {
      return new Response(
        JSON.stringify({ error: 'Parâmetros inválidos' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const ident = String(identifier).trim();

    // Buscar perfil por username (case-insensitive) OU nome completo (case-insensitive)
    const { data: profiles, error: profilesError } = await supabaseAdmin
      .from('profiles')
      .select('id, username, name, matricula')
      .or(`username.ilike.${ident},name.ilike.${ident}`);

    if (profilesError) {
      console.error('Erro ao buscar perfil:', profilesError);
      return new Response(
        JSON.stringify({ error: GENERIC_ERROR }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const profile = profiles && profiles.length === 1 ? profiles[0] : null;

    // Step 1: apenas verifica existência do usuário (sempre responde sucesso genérico)
    if (step === 'find') {
      // Não revelar se o usuário existe ou não
      return new Response(
        JSON.stringify({ ok: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    // Step 2: validar matrícula + atualizar senha
    if (step === 'reset') {
      if (!matricula || !newPassword) {
        return new Response(
          JSON.stringify({ error: 'Parâmetros inválidos' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      if (String(newPassword).length < 6) {
        return new Response(
          JSON.stringify({ error: 'A senha deve ter no mínimo 6 caracteres' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      if (!profile || !profile.matricula) {
        return new Response(
          JSON.stringify({ error: GENERIC_ERROR }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      const provided = String(matricula).trim().toLowerCase();
      const stored = String(profile.matricula).trim().toLowerCase();

      if (provided !== stored) {
        return new Response(
          JSON.stringify({ error: GENERIC_ERROR }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      const { error: updateError } = await supabaseAdmin.auth.admin.updateUserById(
        profile.id,
        { password: newPassword }
      );

      if (updateError) {
        console.error('Erro ao atualizar senha:', updateError);
        return new Response(
          JSON.stringify({ error: 'Erro ao atualizar senha' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
        );
      }

      console.log(`Senha resetada via matrícula para usuário ${profile.id}`);

      return new Response(
        JSON.stringify({ ok: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    return new Response(
      JSON.stringify({ error: 'Step inválido' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  } catch (error: any) {
    console.error('Erro na função reset-password-with-matricula:', error);
    return new Response(
      JSON.stringify({ error: GENERIC_ERROR }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    );
  }
});
