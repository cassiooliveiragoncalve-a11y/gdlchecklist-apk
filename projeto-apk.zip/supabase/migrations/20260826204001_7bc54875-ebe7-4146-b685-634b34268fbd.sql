CREATE POLICY "Operators can close their own checklist sessions"
ON public.checklist_records
FOR UPDATE
TO authenticated
USING (
  session_status = 'em_andamento'
  AND operator_id = (SELECT profiles.matricula FROM public.profiles WHERE profiles.id = auth.uid())
)
WITH CHECK (
  operator_id = (SELECT profiles.matricula FROM public.profiles WHERE profiles.id = auth.uid())
);