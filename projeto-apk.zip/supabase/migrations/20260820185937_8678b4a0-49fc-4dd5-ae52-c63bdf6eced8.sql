CREATE OR REPLACE FUNCTION public.checklist_block_unavailable_equipment()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  eq RECORD;
  os RECORD;
BEGIN
  IF NEW.equipment_id IS NULL THEN
    RETURN NEW;
  END IF;

  IF COALESCE(NEW.checklist_type, 'empilhadeira') <> 'empilhadeira' THEN
    RETURN NEW;
  END IF;

  SELECT code, status, observations INTO eq FROM public.equipment WHERE id = NEW.equipment_id;
  IF NOT FOUND THEN
    RETURN NEW;
  END IF;

  SELECT numero_os, status, descricao_ocorrencia INTO os
  FROM public.service_orders
  WHERE equipment_id = NEW.equipment_id
    AND status IN ('aberta', 'em_manutencao')
  ORDER BY data_hora_abertura DESC
  LIMIT 1;

  IF lower(coalesce(eq.status, '')) IN ('manutencao', 'maintenance', 'inactive', 'indisponivel', 'parado') THEN
    RAISE EXCEPTION 'EQUIPAMENTO_INDISPONIVEL: O equipamento % não pode realizar checklist porque está indisponível.%',
      eq.code,
      CASE WHEN os.numero_os IS NOT NULL THEN ' OS: #' || os.numero_os || ' - ' || os.descricao_ocorrencia ELSE '' END;
  END IF;

  IF os.numero_os IS NOT NULL THEN
    RAISE EXCEPTION 'OS_ABERTA: O equipamento % possui uma OS aberta (#%) e não pode iniciar um novo checklist.',
      eq.code, os.numero_os;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_checklist_block_unavailable_equipment ON public.checklist_records;
CREATE TRIGGER trg_checklist_block_unavailable_equipment
BEFORE INSERT ON public.checklist_records
FOR EACH ROW EXECUTE FUNCTION public.checklist_block_unavailable_equipment();