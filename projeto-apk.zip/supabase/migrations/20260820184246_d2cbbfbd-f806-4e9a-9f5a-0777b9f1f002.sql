ALTER TABLE public.checklist_records
  ADD COLUMN IF NOT EXISTS session_status text NOT NULL DEFAULT 'finalizado',
  ADD COLUMN IF NOT EXISTS started_at timestamptz,
  ADD COLUMN IF NOT EXISTS ended_at timestamptz,
  ADD COLUMN IF NOT EXISTS hour_meter_start numeric,
  ADD COLUMN IF NOT EXISTS hour_meter_end numeric,
  ADD COLUMN IF NOT EXISTS worked_hours numeric,
  ADD COLUMN IF NOT EXISTS hour_meter_justification text;

UPDATE public.checklist_records
SET started_at = COALESCE(started_at, timestamp),
    ended_at = COALESCE(ended_at, timestamp),
    hour_meter_start = COALESCE(hour_meter_start, hour_meter)
WHERE started_at IS NULL OR hour_meter_start IS NULL;

CREATE UNIQUE INDEX IF NOT EXISTS uniq_open_session_per_equipment
  ON public.checklist_records (equipment_id)
  WHERE session_status = 'em_andamento' AND equipment_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_checklist_records_session_status
  ON public.checklist_records (session_status, started_at DESC);