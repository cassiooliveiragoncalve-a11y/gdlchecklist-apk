DELETE FROM public.checklist_records
WHERE id = '4bad61cd-6caa-4949-8adb-0d751403aceb'
  AND NOT EXISTS (
    SELECT 1 FROM public.checklist_answers ca
    WHERE ca.checklist_record_id = '4bad61cd-6caa-4949-8adb-0d751403aceb'
  );