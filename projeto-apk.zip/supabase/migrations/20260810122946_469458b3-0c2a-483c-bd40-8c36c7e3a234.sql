CREATE TABLE public.service_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  numero_os text NOT NULL UNIQUE,
  equipment_id uuid NOT NULL REFERENCES public.equipment(id) ON DELETE CASCADE,
  equipment_code text NOT NULL,
  equipment_model text,
  unit text,
  location text,
  usuario_abertura_id uuid,
  mecanico_responsavel text NOT NULL,
  tipo_manutencao text NOT NULL,
  descricao_ocorrencia text NOT NULL,
  status text NOT NULL DEFAULT 'aberta',
  data_hora_abertura timestamptz NOT NULL DEFAULT now(),
  data_hora_inicio_manutencao timestamptz,
  data_hora_fechamento timestamptz,
  tempo_indisponibilidade_minutos integer,
  servico_executado text,
  causa_identificada text,
  pecas_materiais text,
  observacoes text,
  motivo_cancelamento text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT service_orders_tipo_check CHECK (tipo_manutencao IN ('avaria','corretiva','pneus','preventiva')),
  CONSTRAINT service_orders_status_check CHECK (status IN ('aberta','em_manutencao','finalizada','cancelada')),
  CONSTRAINT service_orders_descricao_check CHECK (length(btrim(descricao_ocorrencia)) > 0)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.service_orders TO authenticated;
GRANT ALL ON public.service_orders TO service_role;

ALTER TABLE public.service_orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view service orders"
  ON public.service_orders FOR SELECT TO authenticated USING (true);

CREATE POLICY "Mechanics and managers can create service orders"
  ON public.service_orders FOR INSERT TO authenticated
  WITH CHECK (
    public.has_role(auth.uid(), 'mecanico') OR
    public.has_role(auth.uid(), 'gestor') OR
    public.has_role(auth.uid(), 'admin')
  );

CREATE POLICY "Mechanics and managers can update service orders"
  ON public.service_orders FOR UPDATE TO authenticated
  USING (
    public.has_role(auth.uid(), 'mecanico') OR
    public.has_role(auth.uid(), 'gestor') OR
    public.has_role(auth.uid(), 'admin')
  )
  WITH CHECK (
    public.has_role(auth.uid(), 'mecanico') OR
    public.has_role(auth.uid(), 'gestor') OR
    public.has_role(auth.uid(), 'admin')
  );

CREATE POLICY "Admins can delete service orders"
  ON public.service_orders FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE UNIQUE INDEX service_orders_one_open_per_equipment
  ON public.service_orders (equipment_id)
  WHERE status IN ('aberta','em_manutencao');

CREATE INDEX service_orders_status_idx ON public.service_orders (status);
CREATE INDEX service_orders_abertura_idx ON public.service_orders (data_hora_abertura DESC);
CREATE INDEX service_orders_equipment_idx ON public.service_orders (equipment_id);

CREATE SEQUENCE IF NOT EXISTS public.service_orders_number_seq;

CREATE OR REPLACE FUNCTION public.set_service_order_number()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.numero_os IS NULL OR btrim(NEW.numero_os) = '' THEN
    NEW.numero_os := 'OS-' || to_char(now(), 'YYYY') || '-' ||
      lpad(nextval('public.service_orders_number_seq')::text, 6, '0');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_service_orders_number
  BEFORE INSERT ON public.service_orders
  FOR EACH ROW EXECUTE FUNCTION public.set_service_order_number();

CREATE OR REPLACE FUNCTION public.service_order_compute_downtime()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IN ('finalizada','cancelada') THEN
    IF NEW.data_hora_fechamento IS NULL THEN
      NEW.data_hora_fechamento := now();
    END IF;
    NEW.tempo_indisponibilidade_minutos :=
      GREATEST(0, ROUND(EXTRACT(EPOCH FROM (NEW.data_hora_fechamento - NEW.data_hora_abertura)) / 60)::int);
  ELSE
    NEW.data_hora_fechamento := NULL;
    NEW.tempo_indisponibilidade_minutos := NULL;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_service_orders_downtime
  BEFORE INSERT OR UPDATE ON public.service_orders
  FOR EACH ROW EXECUTE FUNCTION public.service_order_compute_downtime();

CREATE OR REPLACE FUNCTION public.service_order_sync_equipment_status()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.status IN ('aberta','em_manutencao') THEN
    UPDATE public.equipment SET status = 'manutencao', updated_at = now() WHERE id = NEW.equipment_id;
  ELSIF NEW.status IN ('finalizada','cancelada') THEN
    IF NOT EXISTS (
      SELECT 1 FROM public.service_orders
      WHERE equipment_id = NEW.equipment_id
        AND id <> NEW.id
        AND status IN ('aberta','em_manutencao')
    ) THEN
      UPDATE public.equipment SET status = 'disponivel', updated_at = now() WHERE id = NEW.equipment_id;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_service_orders_equipment_status
  AFTER INSERT OR UPDATE OF status ON public.service_orders
  FOR EACH ROW EXECUTE FUNCTION public.service_order_sync_equipment_status();

CREATE TRIGGER update_service_orders_updated_at
  BEFORE UPDATE ON public.service_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER PUBLICATION supabase_realtime ADD TABLE public.service_orders;