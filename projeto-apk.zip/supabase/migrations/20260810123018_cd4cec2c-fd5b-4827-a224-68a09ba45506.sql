REVOKE EXECUTE ON FUNCTION public.set_service_order_number() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.service_order_compute_downtime() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.service_order_sync_equipment_status() FROM PUBLIC, anon, authenticated;