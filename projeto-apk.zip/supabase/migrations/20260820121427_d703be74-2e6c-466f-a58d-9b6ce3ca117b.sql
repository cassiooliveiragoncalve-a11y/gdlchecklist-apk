CREATE TABLE public.equipment_contracts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  equipment_id uuid NOT NULL UNIQUE REFERENCES public.equipment(id) ON DELETE CASCADE,
  monthly_franchise_hours numeric NOT NULL DEFAULT 220,
  cycle_start_day integer NOT NULL DEFAULT 1 CHECK (cycle_start_day BETWEEN 1 AND 28),
  extra_hour_rate numeric NOT NULL DEFAULT 0,
  equipment_value numeric,
  notes text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.equipment_contracts TO authenticated;
GRANT ALL ON public.equipment_contracts TO service_role;

ALTER TABLE public.equipment_contracts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated can view contracts"
  ON public.equipment_contracts FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins and managers can insert contracts"
  ON public.equipment_contracts FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'gestor'));

CREATE POLICY "Admins and managers can update contracts"
  ON public.equipment_contracts FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'gestor'))
  WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'gestor'));

CREATE POLICY "Admins can delete contracts"
  ON public.equipment_contracts FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_equipment_contracts_updated_at
  BEFORE UPDATE ON public.equipment_contracts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();