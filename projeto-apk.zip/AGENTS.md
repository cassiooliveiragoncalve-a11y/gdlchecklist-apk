# Architecture rules

- Keep EquipmentViewer isolated from data hooks and accept images keyed by view; local preview files stay in browser memory to avoid database or storage writes.
- Decode each source set before enabling viewer navigation and retain stable transparent image layers; this prevents load gaps and opaque backgrounds from interrupting crossfades.
- Keep four-view navigation and swipe direction in a pure helper shared by the viewer and its tests so circular ordering remains consistent.
- Share a presentation-only TireEquipmentViewer dialog between tire list and details, accepting existing tire context so opening 360° adds no data queries or writes.