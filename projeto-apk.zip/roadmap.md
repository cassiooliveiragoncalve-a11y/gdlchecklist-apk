# Reach Stacker viewer

- [x] Refactor 360° preload/crossfade, compact controls, keyboard/drag and viewport-sized dialogs; verified with 8 unit tests and authenticated desktop/mobile tire entry flow.

- [x] Add isolated four-view viewer and entry point in the tires module.
- [x] Test circular navigation, gestures and responsive presentation (5 unit tests and isolated browser verification; authenticated entry point not tested).
- [x] Load the four original Reach Stacker images permanently, unmodified, through CDN assets without database changes.

# Per-tire 360° view

- [x] Add access from each tire and its details using existing equipment/position data.
- [x] Smooth transitions, automatic rotation and transparent equipment images.
- [x] Verify navigation, rotation and per-tire access (authenticated browser flow, mobile layout, 5 navigation tests).