package br.com.gdllogistica.checklist;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
