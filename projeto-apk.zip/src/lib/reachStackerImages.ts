import front from '@/assets/reach-stacker/front-transparent.png';
import right from '@/assets/reach-stacker/right-transparent.png';
import rear from '@/assets/reach-stacker/rear-transparent.png';
import left from '@/assets/reach-stacker/left-transparent.png';
import type { EquipmentViewerImages } from './equipmentViewer';

export const reachStackerImages: EquipmentViewerImages = {
  front,
  right,
  rear,
  left,
};