import { auth, defineMcp } from "@lovable.dev/mcp-js";
import listEquipmentTool from "./tools/list-equipment";
import listChecklistsTool from "./tools/list-checklists";
import listServiceOrdersTool from "./tools/list-service-orders";
import listTiresTool from "./tools/list-tires";

const projectRef = import.meta.env.VITE_SUPABASE_PROJECT_ID ?? "project-ref-unset";

export default defineMcp({
  name: "gdlchecklist01",
  title: "gdlchecklist01",
  version: "0.1.0",
  instructions:
    "Ferramentas do GDL CheckList. Consulte equipamentos, checklists (sessões e horímetro), ordens de serviço e pneus. Todos os dados respeitam as permissões do usuário autenticado.",
  auth: auth.oauth.issuer({
    issuer: `https://${projectRef}.supabase.co/auth/v1`,
    acceptedAudiences: "authenticated",
  }),
  tools: [listEquipmentTool, listChecklistsTool, listServiceOrdersTool, listTiresTool],
});
