import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_equipment",
  title: "Listar equipamentos",
  description: "Lista equipamentos da frota com status, local, unidade de negócio e horímetro.",
  inputSchema: {
    status: z.string().optional().describe("Filtra por status (disponivel, operando, manutencao)."),
    search: z.string().optional().describe("Busca por código, modelo ou marca."),
    limit: z.number().int().min(1).max(200).optional().describe("Máximo de registros (padrão 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, search, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Não autenticado" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("equipment")
      .select("id, code, model, brand, status, location, business_unit, cost_center, sector, hour_meter, operator_name, last_check")
      .order("code", { ascending: true })
      .limit(limit ?? 50);
    if (status) query = query.eq("status", status);
    if (search) query = query.or(`code.ilike.%${search}%,model.ilike.%${search}%,brand.ilike.%${search}%`);

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    const equipments = (data ?? []).map((e) => ({
      id: e.id,
      code: e.code,
      model: e.model,
      brand: e.brand,
      status: e.status,
      location: e.location,
      businessUnit: e.business_unit,
      costCenter: e.cost_center,
      sector: e.sector,
      hourMeter: e.hour_meter,
      operatorName: e.operator_name,
      lastCheck: e.last_check,
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(equipments, null, 2) }],
      structuredContent: { equipments },
    };
  },
});
