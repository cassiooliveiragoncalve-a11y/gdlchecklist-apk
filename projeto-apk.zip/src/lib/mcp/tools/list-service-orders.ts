import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_service_orders",
  title: "Listar ordens de serviço",
  description: "Lista ordens de serviço de manutenção com status, oficina, mecânico e tempos.",
  inputSchema: {
    status: z.string().optional().describe("Status da OS (aberta, em_andamento, fechada, cancelada)."),
    equipmentCode: z.string().optional().describe("Código do equipamento."),
    since: z.string().optional().describe("Abertura a partir desta data ISO."),
    limit: z.number().int().min(1).max(200).optional().describe("Máximo de registros (padrão 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, equipmentCode, since, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Não autenticado" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("service_orders")
      .select("id, numero_os, equipment_code, equipment_model, status, tipo_manutencao, oficina, mecanico_responsavel, descricao_ocorrencia, servico_executado, location, unit, data_hora_abertura, data_hora_inicio_manutencao, data_hora_fechamento, tempo_indisponibilidade_minutos")
      .order("data_hora_abertura", { ascending: false })
      .limit(limit ?? 50);
    if (status) query = query.eq("status", status);
    if (equipmentCode) query = query.eq("equipment_code", equipmentCode);
    if (since) query = query.gte("data_hora_abertura", since);

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    const serviceOrders = (data ?? []).map((o) => ({
      id: o.id,
      numeroOs: o.numero_os,
      equipmentCode: o.equipment_code,
      equipmentModel: o.equipment_model,
      status: o.status,
      tipoManutencao: o.tipo_manutencao,
      oficina: o.oficina,
      mecanicoResponsavel: o.mecanico_responsavel,
      descricaoOcorrencia: o.descricao_ocorrencia,
      servicoExecutado: o.servico_executado,
      location: o.location,
      unit: o.unit,
      abertura: o.data_hora_abertura,
      inicioManutencao: o.data_hora_inicio_manutencao,
      fechamento: o.data_hora_fechamento,
      indisponibilidadeMinutos: o.tempo_indisponibilidade_minutos,
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(serviceOrders, null, 2) }],
      structuredContent: { serviceOrders },
    };
  },
});
