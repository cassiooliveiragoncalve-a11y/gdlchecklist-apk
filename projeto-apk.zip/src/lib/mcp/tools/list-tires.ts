import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_tires",
  title: "Listar pneus",
  description: "Lista pneus cadastrados com status, posição, reformadora e data de montagem.",
  inputSchema: {
    status: z.string().optional().describe("Status do pneu (ex.: em_uso, estoque, descartado)."),
    equipmentId: z.string().uuid().optional().describe("ID do equipamento onde o pneu está montado."),
    limit: z.number().int().min(1).max(200).optional().describe("Máximo de registros (padrão 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ status, equipmentId, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Não autenticado" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("tires")
      .select("id, code, model, status, position, equipment_id, initial_depth, initial_hour_meter, retreader, mounted_at")
      .order("code", { ascending: true })
      .limit(limit ?? 50);
    if (status) query = query.eq("status", status);
    if (equipmentId) query = query.eq("equipment_id", equipmentId);

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    const tires = (data ?? []).map((t) => ({
      id: t.id,
      code: t.code,
      model: t.model,
      status: t.status,
      position: t.position,
      equipmentId: t.equipment_id,
      initialDepth: t.initial_depth,
      initialHourMeter: t.initial_hour_meter,
      retreader: t.retreader,
      mountedAt: t.mounted_at,
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(tires, null, 2) }],
      structuredContent: { tires },
    };
  },
});
