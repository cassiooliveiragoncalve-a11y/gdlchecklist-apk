import { defineTool } from "@lovable.dev/mcp-js";
import { z } from "zod";
import { supabaseForUser } from "../supabase";

export default defineTool({
  name: "list_checklists",
  title: "Listar checklists",
  description: "Lista checklists registrados, com filtros por equipamento, status, sessão e período.",
  inputSchema: {
    equipmentCode: z.string().optional().describe("Código do equipamento."),
    status: z.string().optional().describe("Status do checklist (conforme, pendente, negado)."),
    sessionStatus: z.string().optional().describe("Status da sessão (em_andamento, finalizado)."),
    since: z.string().optional().describe("Data inicial ISO (ex.: 2026-09-01)."),
    limit: z.number().int().min(1).max(200).optional().describe("Máximo de registros (padrão 50)."),
  },
  annotations: { readOnlyHint: true, idempotentHint: true, openWorldHint: false },
  handler: async ({ equipmentCode, status, sessionStatus, since, limit }, ctx) => {
    if (!ctx.isAuthenticated()) {
      return { content: [{ type: "text", text: "Não autenticado" }], isError: true };
    }
    const supabase = supabaseForUser(ctx);
    let query = supabase
      .from("checklist_records")
      .select("id, equipment_code, equipment_model, operator_name, status, session_status, checklist_type, location, unit, timestamp, started_at, ended_at, hour_meter_start, hour_meter_end, worked_hours, conforme_items, nao_conforme_items, has_critical_issues")
      .order("timestamp", { ascending: false })
      .limit(limit ?? 50);
    if (equipmentCode) query = query.eq("equipment_code", equipmentCode);
    if (status) query = query.eq("status", status);
    if (sessionStatus) query = query.eq("session_status", sessionStatus);
    if (since) query = query.gte("timestamp", since);

    const { data, error } = await query;
    if (error) return { content: [{ type: "text", text: error.message }], isError: true };

    const checklists = (data ?? []).map((c) => ({
      id: c.id,
      equipmentCode: c.equipment_code,
      equipmentModel: c.equipment_model,
      operatorName: c.operator_name,
      status: c.status,
      sessionStatus: c.session_status,
      checklistType: c.checklist_type,
      location: c.location,
      unit: c.unit,
      timestamp: c.timestamp,
      startedAt: c.started_at,
      endedAt: c.ended_at,
      hourMeterStart: c.hour_meter_start,
      hourMeterEnd: c.hour_meter_end,
      workedHours: c.worked_hours,
      conformeItems: c.conforme_items,
      naoConformeItems: c.nao_conforme_items,
      hasCriticalIssues: c.has_critical_issues,
    }));
    return {
      content: [{ type: "text", text: JSON.stringify(checklists, null, 2) }],
      structuredContent: { checklists },
    };
  },
});
