import { supabase } from '@/integrations/supabase/client';

/** Status de equipamento que impedem a realização de checklist */
export const BLOCKED_EQUIPMENT_STATUSES = [
  'manutencao',
  'maintenance',
  'inactive',
  'indisponivel',
  'parado',
];

export const OPEN_OS_STATUSES = ['aberta', 'em_manutencao'];

export interface EquipmentAvailability {
  blocked: boolean;
  reason: 'indisponivel' | 'os_aberta' | null;
  title: string;
  description: string;
  equipmentCode?: string;
  osNumber?: string | null;
  osStatus?: string | null;
  osDescription?: string | null;
}

const AVAILABLE: EquipmentAvailability = {
  blocked: false,
  reason: null,
  title: 'Equipamento disponível',
  description: 'O equipamento está liberado para iniciar o checklist.',
};

const OS_STATUS_LABEL: Record<string, string> = {
  aberta: 'Aberta',
  em_manutencao: 'Em andamento',
};

/**
 * Consulta em tempo real o status do equipamento e as OS vinculadas.
 * Deve ser chamada imediatamente antes de criar o checklist (não confiar em dados em cache).
 */
export const checkEquipmentAvailability = async (
  equipmentId: string
): Promise<EquipmentAvailability> => {
  const [{ data: eq, error: eqError }, { data: orders, error: osError }] = await Promise.all([
    supabase.from('equipment').select('code,status,observations').eq('id', equipmentId).maybeSingle(),
    supabase
      .from('service_orders')
      .select('numero_os,status,descricao_ocorrencia,tipo_manutencao,data_hora_abertura')
      .eq('equipment_id', equipmentId)
      .in('status', OPEN_OS_STATUSES)
      .order('data_hora_abertura', { ascending: false })
      .limit(1),
  ]);

  if (eqError || osError) {
    // Em caso de falha de rede, não bloqueia no front — o backend (trigger) garante a regra
    return AVAILABLE;
  }

  const openOs = orders && orders.length > 0 ? orders[0] : null;
  const code = eq?.code || 'Equipamento';
  const status = (eq?.status || '').toLowerCase();

  if (BLOCKED_EQUIPMENT_STATUSES.includes(status)) {
    return {
      blocked: true,
      reason: 'indisponivel',
      title: '⚠️ Equipamento indisponível',
      description:
        `O equipamento ${code} não pode realizar checklist no momento porque está indisponível.` +
        (openOs ? `\nMotivo: ${openOs.descricao_ocorrencia}\nOS: #${openOs.numero_os}` : eq?.observations ? `\nMotivo: ${eq.observations}` : '') +
        `\nSelecione um equipamento disponível para continuar.`,
      equipmentCode: code,
      osNumber: openOs?.numero_os ?? null,
      osStatus: openOs ? OS_STATUS_LABEL[openOs.status] || openOs.status : null,
      osDescription: openOs?.descricao_ocorrencia ?? null,
    };
  }

  if (openOs) {
    return {
      blocked: true,
      reason: 'os_aberta',
      title: '⚠️ Equipamento com OS aberta',
      description:
        `O equipamento ${code} possui uma OS aberta e não pode iniciar um novo checklist.` +
        `\nOS: #${openOs.numero_os}` +
        `\nStatus: ${OS_STATUS_LABEL[openOs.status] || openOs.status}` +
        `\nDescrição: ${openOs.descricao_ocorrencia}` +
        `\nO checklist poderá ser iniciado somente após o encerramento da OS e a liberação do equipamento.`,
      equipmentCode: code,
      osNumber: openOs.numero_os,
      osStatus: OS_STATUS_LABEL[openOs.status] || openOs.status,
      osDescription: openOs.descricao_ocorrencia,
    };
  }

  return { ...AVAILABLE, equipmentCode: code };
};
