/**
 * Compressão e redimensionamento de imagens no cliente.
 * Reduz drasticamente o tamanho das fotos antes de enviar ao banco.
 */

export interface CompressOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number; // 0..1 (JPEG)
  mimeType?: string; // default 'image/jpeg'
}

const DEFAULTS: Required<CompressOptions> = {
  maxWidth: 1280,
  maxHeight: 1280,
  quality: 0.7,
  mimeType: "image/jpeg",
};

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}

function readFileAsDataURL(file: File | Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

/**
 * Comprime uma imagem retornando um dataURL (base64) já reduzido.
 * Mantém a proporção original, apenas encaixando dentro de max width/height.
 */
export async function compressImage(
  file: File | Blob,
  options: CompressOptions = {}
): Promise<string> {
  const opts = { ...DEFAULTS, ...options };

  // Se não for imagem, retorna como está
  if (file.type && !file.type.startsWith("image/")) {
    return readFileAsDataURL(file);
  }

  try {
    const original = await readFileAsDataURL(file);
    const img = await loadImage(original);

    let { width, height } = img;
    const ratio = Math.min(opts.maxWidth / width, opts.maxHeight / height, 1);
    width = Math.round(width * ratio);
    height = Math.round(height * ratio);

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d");
    if (!ctx) return original;

    ctx.drawImage(img, 0, 0, width, height);

    const compressed = canvas.toDataURL(opts.mimeType, opts.quality);

    // Só usa a versão comprimida se realmente ficou menor
    return compressed.length < original.length ? compressed : original;
  } catch (err) {
    console.warn("[compressImage] Falha ao comprimir, usando arquivo original:", err);
    return readFileAsDataURL(file);
  }
}
