/**
 * Franquia contratual mensal por equipamento.
 *
 * Fonte de horas: leituras de horímetro já registradas nos checklists
 * (public.checklist_records.hour_meter) — nenhuma rotina paralela de lançamento.
 *
 * Regra: horas do ciclo = último horímetro válido − primeiro horímetro válido do ciclo.
 * Nunca somar valores absolutos; leituras retroativas são sinalizadas como inconsistência.
 */
import { HourMeterReading } from '@/lib/operationalMetrics';
import { EquipmentContract } from '@/hooks/useEquipmentContracts';

export interface FranchiseCycle {
  start: Date;
  end: Date; // exclusivo
  label: string;
}

/** Ciclo contratual vigente (ou o ciclo que contém `ref`) para um dia de início */
export const getCycle = (cycleStartDay: number, ref: Date = new Date()): FranchiseCycle => {
  const day = Math.min(Math.max(cycleStartDay || 1, 1), 30);
  const start = new Date(ref.getFullYear(), ref.getMonth(), day);
  if (ref.getTime() < start.getTime()) {
    start.setMonth(start.getMonth() - 1);
  }
  const end = new Date(start.getFullYear(), start.getMonth() + 1, day);
  const fmt = (d: Date) => d.toLocaleDateString('pt-BR');
  // Ciclo mensal: do dia de início até o mesmo dia do mês seguinte (ex.: 08/08 a 08/09)
  return { start, end, label: `${fmt(start)} a ${fmt(end)}` };
};

export interface FranchiseUsage {
  cycle: FranchiseCycle;
  firstReading: number | null;
  lastReading: number | null;
  hoursUsed: number | null;
  franchiseHours: number;
  usedPct: number | null;
  excessHours: number;
  extraCost: number;
  inconsistent: boolean;
  readingsCount: number;
}

/**
 * Calcula o consumo da franquia no ciclo atual.
 * `readings` devem ser as leituras do equipamento (qualquer ordem).
 */
export const computeFranchiseUsage = (
  readings: HourMeterReading[],
  contract: EquipmentContract | null,
  ref: Date = new Date()
): FranchiseUsage | null => {
  if (!contract) return null;

  const cycle = getCycle(contract.cycle_start_day, ref);
  const inCycle = readings
    .filter((r) => {
      const t = new Date(r.timestamp).getTime();
      return Number.isFinite(t) && t >= cycle.start.getTime() && t < cycle.end.getTime() && r.hourMeter > 0;
    })
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  const franchiseHours = contract.monthly_franchise_hours || 0;

  if (inCycle.length === 0) {
    return {
      cycle,
      firstReading: null,
      lastReading: null,
      hoursUsed: null,
      franchiseHours,
      usedPct: null,
      excessHours: 0,
      extraCost: 0,
      inconsistent: false,
      readingsCount: 0,
    };
  }

  // Soma dos deltas válidos (mesma regra anti-outlier do módulo de horímetro):
  // ignora leituras repetidas/retroativas e saltos impossíveis (> 24 h por dia).
  // O horímetro inicial/atual também usa apenas leituras válidas — assim um erro
  // de digitação (ex.: 214888 no lugar de 2148) não vira "horímetro atual".
  let inconsistent = false;
  let hoursUsed = 0;
  const MS_DAY = 86_400_000;
  const first = inCycle[0].hourMeter;
  let last = first;
  let prev = inCycle[0];

  for (let i = 1; i < inCycle.length; i++) {
    const curr = inCycle[i];
    const delta = curr.hourMeter - prev.hourMeter;
    if (delta < 0) {
      inconsistent = true;
      continue; // leitura retroativa → descartada, mantém referência anterior
    }
    const days = Math.max(
      1,
      (new Date(curr.timestamp).getTime() - new Date(prev.timestamp).getTime()) / MS_DAY
    );
    if (delta > days * 24) {
      inconsistent = true; // salto impossível → provável erro de digitação
      continue;
    }
    hoursUsed += delta;
    last = curr.hourMeter;
    prev = curr;
  }



  const excessHours = franchiseHours > 0 ? Math.max(0, hoursUsed - franchiseHours) : 0;
  const extraCost = excessHours * (contract.extra_hour_rate || 0);

  return {
    cycle,
    firstReading: first,
    lastReading: last,
    hoursUsed,
    franchiseHours,
    usedPct: franchiseHours > 0 ? (hoursUsed / franchiseHours) * 100 : null,
    excessHours,
    extraCost,
    inconsistent,
    readingsCount: inCycle.length,
  };
};

export const formatBRL = (value: number | null | undefined) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
};

export const formatH = (value: number | null | undefined) => {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  return `${Math.round(value).toLocaleString('pt-BR')} h`;
};
