export const EQUIPMENT_VIEWS = [
  { id: 'front', label: 'Frontal', fullLabel: 'Vista frontal' },
  { id: 'right', label: 'Direita', fullLabel: 'Vista lateral direita' },
  { id: 'rear', label: 'Traseira', fullLabel: 'Vista traseira' },
  { id: 'left', label: 'Esquerda', fullLabel: 'Vista lateral esquerda' },
] as const;

export type EquipmentView = typeof EQUIPMENT_VIEWS[number]['id'];
export type EquipmentViewerImages = Partial<Record<EquipmentView, string>>;

export const EQUIPMENT_ROTATION_INTERVAL = 2500;

export async function preloadEquipmentImages(images: EquipmentViewerImages): Promise<EquipmentViewerImages> {
  const failures: EquipmentViewerImages = {};
  await Promise.all(EQUIPMENT_VIEWS.map(async ({ id }) => {
    const source = images[id];
    if (!source) return;
    const image = new Image();
    image.src = source;
    try {
      await image.decode();
    } catch {
      failures[id] = source;
    }
  }));
  return failures;
}

export function adjacentEquipmentView(view: EquipmentView, direction: 1 | -1): EquipmentView {
  const index = EQUIPMENT_VIEWS.findIndex((item) => item.id === view);
  return EQUIPMENT_VIEWS[(index + direction + EQUIPMENT_VIEWS.length) % EQUIPMENT_VIEWS.length].id;
}

export function equipmentSwipeDirection(deltaX: number, deltaY: number): 1 | -1 | null {
  if (Math.abs(deltaX) < 50 || Math.abs(deltaX) <= Math.abs(deltaY)) return null;
  return deltaX < 0 ? 1 : -1;
}