import React, { lazy } from 'react';

/**
 * Lazy loading de componentes pesados para melhor performance inicial
 * Carrega componentes apenas quando necessário
 */

/**
 * Wrapper que recarrega a página automaticamente quando um chunk dinâmico
 * falha ao carregar (acontece após deploys, quando o index.html cacheado
 * referencia hashes de assets antigos que não existem mais).
 */
function lazyWithRetry<T extends React.ComponentType<any>>(
  factory: () => Promise<{ default: T }>
) {
  return lazy(async () => {
    const reloadKey = 'lovable-chunk-reload';
    try {
      return await factory();
    } catch (error: any) {
      const message = String(error?.message || '');
      const isChunkError =
        message.includes('Failed to fetch dynamically imported module') ||
        message.includes('Importing a module script failed') ||
        message.includes('error loading dynamically imported module');

      if (isChunkError && typeof window !== 'undefined') {
        // Evita loop infinito de reload
        const alreadyReloaded = sessionStorage.getItem(reloadKey);
        if (!alreadyReloaded) {
          sessionStorage.setItem(reloadKey, '1');
          window.location.reload();
          // Retorna uma promise pendente para suspender o componente até o reload
          return new Promise(() => {}) as any;
        }
      }
      throw error;
    }
  });
}

// Limpa a flag de reload quando o app carrega com sucesso
if (typeof window !== 'undefined') {
  window.addEventListener('load', () => {
    sessionStorage.removeItem('lovable-chunk-reload');
  });
}

// Páginas principais
export const LazyUserManagement = lazyWithRetry(() => import('@/components/UserManagement'));
export const LazyEquipmentManagement = lazyWithRetry(() => import('@/components/EquipmentManagement'));
export const LazyChecklistHistory = lazyWithRetry(() => import('@/components/ChecklistHistory'));
export const LazyApprovalsPage = lazyWithRetry(() => import('@/components/ApprovalsPage'));
export const LazyChecklistForm = lazyWithRetry(() => import('@/components/ChecklistForm'));
export const LazyTireManagement = lazyWithRetry(() => import('@/components/TireManagement'));
export const LazyHourMeterControl = lazyWithRetry(() => import('@/components/HourMeterControl'));
export const LazyOperationalManagement = lazyWithRetry(() => import('@/components/OperationalManagement'));
export const LazyServiceOrders = lazyWithRetry(() => import('@/components/ServiceOrders'));


/**
 * Fallback padrão para lazy components
 */
export const LoadingFallback = () => (
  <div className="flex items-center justify-center min-h-[400px]">
    <div className="text-center space-y-4">
      <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto" />
      <p className="text-muted-foreground">Carregando...</p>
    </div>
  </div>
);
