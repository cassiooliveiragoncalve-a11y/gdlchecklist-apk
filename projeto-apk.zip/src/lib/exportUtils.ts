import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import * as XLSX from 'xlsx';
import gdlLogo from '@/assets/gdl-logo.png';

const today = () => new Date().toISOString().slice(0, 10);

// Cache do logo em dataURL para evitar refetch a cada export
let logoDataUrlCache: { dataUrl: string; w: number; h: number } | null = null;

const loadLogo = async (): Promise<{ dataUrl: string; w: number; h: number } | null> => {
  if (logoDataUrlCache) return logoDataUrlCache;
  try {
    const res = await fetch(gdlLogo);
    const blob = await res.blob();
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(fr.result as string);
      fr.onerror = reject;
      fr.readAsDataURL(blob);
    });
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const i = new Image();
      i.onload = () => resolve(i);
      i.onerror = reject;
      i.src = dataUrl;
    });
    logoDataUrlCache = { dataUrl, w: img.naturalWidth, h: img.naturalHeight };
    return logoDataUrlCache;
  } catch (e) {
    console.warn('[exportUtils] Falha ao carregar logo:', e);
    return null;
  }
};

const COMPANY_NAME = 'GDL Logística';
const BRAND_COLOR: [number, number, number] = [234, 88, 12]; // laranja GDL
const HEADER_BG: [number, number, number] = [30, 41, 59]; // slate-800
const HEADER_TXT: [number, number, number] = [255, 255, 255];

export interface PdfTableOptions {
  title: string;
  subtitle?: string;
  head: string[];
  body: (string | number | null)[][];
  fileName: string;
  orientation?: 'portrait' | 'landscape';
  /** Column index (0-based) whose values (0-100 numbers, or null) should be rendered as a horizontal life bar. */
  progressColumn?: number;
}

const lifeBarColor = (pct: number): [number, number, number] => {
  if (pct <= 20) return [239, 68, 68]; // red
  if (pct <= 50) return [234, 179, 8]; // yellow
  if (pct <= 75) return [16, 185, 129]; // emerald
  return [34, 197, 94]; // green
};


const drawHeader = (
  doc: jsPDF,
  title: string,
  subtitle: string | undefined,
  logo: { dataUrl: string; w: number; h: number } | null,
) => {
  const pageW = doc.internal.pageSize.getWidth();
  const HEADER_H = 70;

  // Faixa de fundo do cabeçalho
  doc.setFillColor(...HEADER_BG);
  doc.rect(0, 0, pageW, HEADER_H, 'F');
  // Faixa fina laranja na base do header
  doc.setFillColor(...BRAND_COLOR);
  doc.rect(0, HEADER_H, pageW, 3, 'F');

  // Logo à esquerda
  if (logo) {
    const maxH = 44;
    const ratio = logo.w / logo.h;
    const h = maxH;
    const w = h * ratio;
    try {
      doc.addImage(logo.dataUrl, 'PNG', 24, (HEADER_H - h) / 2, w, h);
    } catch (e) {
      console.warn('[exportUtils] Falha addImage:', e);
    }
  }

  // Título centralizado
  doc.setTextColor(...HEADER_TXT);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text(title, pageW / 2, subtitle ? 30 : 38, { align: 'center' });
  if (subtitle) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(220, 220, 220);
    doc.text(subtitle, pageW / 2, 48, { align: 'center' });
  }

  // Empresa e data à direita
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(...HEADER_TXT);
  doc.text(COMPANY_NAME, pageW - 24, 28, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(200, 200, 200);
  doc.text(
    `Emitido em ${new Date().toLocaleString('pt-BR')}`,
    pageW - 24,
    44,
    { align: 'right' },
  );

  doc.setTextColor(0, 0, 0);
};

const drawFooter = (doc: jsPDF) => {
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setDrawColor(...BRAND_COLOR);
    doc.setLineWidth(0.8);
    doc.line(24, pageH - 28, pageW - 24, pageH - 28);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text(
      `${COMPANY_NAME} · Documento gerado pelo sistema`,
      24,
      pageH - 14,
    );
    doc.text(`Página ${i} de ${pages}`, pageW - 24, pageH - 14, {
      align: 'right',
    });
  }
};

export const exportTablePdf = async ({
  title,
  subtitle,
  head,
  body,
  fileName,
  orientation = 'landscape',
  progressColumn,
}: PdfTableOptions) => {
  const doc = new jsPDF({ orientation, unit: 'pt', format: 'a4' });
  const logo = await loadLogo();
  drawHeader(doc, title, subtitle, logo);

  autoTable(doc, {
    startY: 90,
    head: [head],
    body: body.map((r) =>
      r.map((c, idx) => {
        if (idx === progressColumn) {
          // mantém valor numérico bruto para uso em didDrawCell; texto = rótulo legível
          return typeof c === 'number' ? `${Math.round(c)}%` : (c == null ? '—' : String(c));
        }
        return c == null ? '' : String(c);
      }),
    ),
    styles: { fontSize: 8, cellPadding: 5, lineColor: [226, 232, 240], lineWidth: 0.3 },
    headStyles: {
      fillColor: HEADER_BG,
      textColor: HEADER_TXT,
      fontStyle: 'bold',
      halign: 'left',
    },
    alternateRowStyles: { fillColor: [248, 250, 252] },
    margin: { left: 24, right: 24, top: 90, bottom: 40 },
    didDrawPage: (data) => {
      if (data.pageNumber > 1) {
        drawHeader(doc, title, subtitle, logo);
      }
    },
    didParseCell: (data) => {
      if (
        progressColumn != null &&
        data.section === 'body' &&
        data.column.index === progressColumn
      ) {
        // Esconde o texto padrão; desenhamos manualmente em didDrawCell
        data.cell.text = [];
        (data.cell as any).minWidth = 70;
      }
    },
    didDrawCell: (data) => {
      if (
        progressColumn == null ||
        data.section !== 'body' ||
        data.column.index !== progressColumn
      ) {
        return;
      }
      const raw = body[data.row.index]?.[progressColumn];
      const { x, y, width, height } = data.cell;
      if (typeof raw !== 'number') {
        doc.setFont('helvetica', 'italic');
        doc.setFontSize(7);
        doc.setTextColor(150, 150, 150);
        doc.text('—', x + width / 2, y + height / 2 + 2, { align: 'center' });
        doc.setTextColor(0, 0, 0);
        return;
      }
      const pct = Math.max(0, Math.min(100, raw));
      const padX = 4;
      const barH = 6;
      const barW = width - padX * 2;
      const barX = x + padX;
      const labelY = y + 9;
      const barY = y + height - barH - 4;

      // Rótulo %
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(7);
      doc.setTextColor(60, 60, 60);
      doc.text(`${Math.round(pct)}%`, barX, labelY);

      // Trilho
      doc.setFillColor(226, 232, 240);
      doc.roundedRect(barX, barY, barW, barH, 1.5, 1.5, 'F');
      // Preenchimento colorido
      const fill = lifeBarColor(pct);
      const fillW = (barW * pct) / 100;
      if (fillW > 0.5) {
        doc.setFillColor(...fill);
        doc.roundedRect(barX, barY, fillW, barH, 1.5, 1.5, 'F');
      }
      doc.setTextColor(0, 0, 0);
    },
  });

  drawFooter(doc);
  doc.save(`${fileName}_${today()}.pdf`);
};


export interface ExcelSheet {
  name: string;
  rows: Record<string, unknown>[];
}

export const exportExcel = (fileName: string, sheets: ExcelSheet[]) => {
  const wb = XLSX.utils.book_new();
  wb.Props = {
    Title: fileName,
    Author: COMPANY_NAME,
    CreatedDate: new Date(),
  };
  sheets.forEach((s) => {
    const ws = XLSX.utils.json_to_sheet(s.rows);
    // Auto-largura aproximada das colunas
    const keys = s.rows[0] ? Object.keys(s.rows[0]) : [];
    ws['!cols'] = keys.map((k) => {
      const maxLen = Math.max(
        k.length,
        ...s.rows.map((r) => String(r[k] ?? '').length),
      );
      return { wch: Math.min(40, Math.max(10, maxLen + 2)) };
    });
    XLSX.utils.book_append_sheet(wb, ws, s.name.slice(0, 31) || 'Sheet');
  });
  XLSX.writeFile(wb, `${fileName}_${today()}.xlsx`);
};
