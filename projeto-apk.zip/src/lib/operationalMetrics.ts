/**
 * Métricas de Gestão Operacional (disponibilidade / indisponibilidade / ociosidade)
 *
 * FONTES DE DADOS (100% reais, sem base paralela):
 * - public.equipment            → cadastro, centro de custo, unidade, tipo (marca+modelo), status
 * - public.service_orders       → OS: abertura, fechamento, tipo de manutenção, tempo de indisponibilidade
 * - public.checklist_records    → leituras de horímetro (hour_meter) para estimar utilização operacional
 */
import { Equipment } from '@/types/equipment';
import { MaintenanceType, ServiceOrder } from '@/types/serviceOrder';

export interface HourMeterReading {
  equipmentId: string | null;
  equipmentCode: string;
  hourMeter: number;
  timestamp: string;
}

export interface OperationalFilters {
  costCenter: string; // 'all' | valor
  businessUnit: string; // 'all' | valor
  year: string; // 'all' | 'YYYY'
  month: string; // 'all' | '0'..'11'
  maintenanceType: MaintenanceType | 'all';
}

export const MONTH_LABELS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

const MS_HOUR = 3600_000;

/** Tipo de equipamento derivado do cadastro (marca + modelo) */
export const equipmentType = (eq: Equipment) =>
  `${(eq.brand || '').trim()} ${(eq.model || '').trim()}`.trim() || 'Não informado';

export const equipmentCostCenter = (eq: Equipment) => (eq.costCenter || '').trim() || 'Sem centro de custo';
/** business_unit não é preenchido no cadastro atual → usa "unit" como unidade de negócio */
export const equipmentBusinessUnit = (eq: Equipment) =>
  (eq.businessUnit || '').trim() || (eq.unit || '').trim() || 'Sem unidade';

export interface Bucket {
  key: string;
  label: string;
  start: number;
  end: number;
}

/** Gera os buckets mensais do período analisado */
export const buildBuckets = (year: string, month: string, availableYears: number[]): Bucket[] => {
  const now = Date.now();
  const buckets: Bucket[] = [];

  const pushMonth = (y: number, m: number) => {
    const start = new Date(y, m, 1).getTime();
    const end = new Date(y, m + 1, 1).getTime();
    if (start > now) return;
    buckets.push({ key: `${y}-${m}`, label: `${MONTH_LABELS[m]}/${String(y).slice(2)}`, start, end: Math.min(end, now) });
  };

  if (year === 'all') {
    const years = availableYears.length ? availableYears : [new Date().getFullYear()];
    years.forEach((y) => {
      for (let m = 0; m < 12; m++) {
        if (month !== 'all' && Number(month) !== m) continue;
        pushMonth(y, m);
      }
    });
  } else {
    const y = Number(year);
    for (let m = 0; m < 12; m++) {
      if (month !== 'all' && Number(month) !== m) continue;
      pushMonth(y, m);
    }
  }
  return buckets;
};

export type PeriodMode = 'mensal' | 'hoje' | 'personalizado';

/** Bucket único do dia de hoje (00:00 → agora) */
export const buildTodayBuckets = (): Bucket[] => {
  const now = Date.now();
  const d = new Date();
  const start = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
  return [{ key: 'hoje', label: 'Hoje', start, end: Math.max(start + 1, now) }];
};

/**
 * Buckets para intervalo personalizado.
 * ≤ 45 dias → buckets diários; acima disso → buckets mensais.
 */
export const buildRangeBuckets = (from: string, to: string): Bucket[] => {
  if (!from || !to) return [];
  const now = Date.now();
  const [fy, fm, fd] = from.split('-').map(Number);
  const [ty, tm, td] = to.split('-').map(Number);
  const start = new Date(fy, (fm || 1) - 1, fd || 1).getTime();
  const endExclusive = Math.min(new Date(ty, (tm || 1) - 1, (td || 1) + 1).getTime(), now);
  if (!(endExclusive > start)) return [];

  const days = (endExclusive - start) / (24 * MS_HOUR);
  const buckets: Bucket[] = [];

  if (days <= 45) {
    let cursor = start;
    while (cursor < endExclusive) {
      const d = new Date(cursor);
      const next = Math.min(new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime(), endExclusive);
      buckets.push({
        key: `d-${cursor}`,
        label: d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
        start: cursor,
        end: next,
      });
      cursor = next;
    }
  } else {
    let cursor = start;
    while (cursor < endExclusive) {
      const d = new Date(cursor);
      const next = Math.min(new Date(d.getFullYear(), d.getMonth() + 1, 1).getTime(), endExclusive);
      buckets.push({
        key: `m-${d.getFullYear()}-${d.getMonth()}`,
        label: `${MONTH_LABELS[d.getMonth()]}/${String(d.getFullYear()).slice(2)}`,
        start: cursor,
        end: next,
      });
      cursor = next;
    }
  }
  return buckets;
};

/** Interseção em horas entre a OS e a janela do bucket */
const overlapHours = (os: ServiceOrder, start: number, end: number, now: number): number => {
  const osStart = new Date(os.data_hora_abertura).getTime();
  const osEnd = os.data_hora_fechamento ? new Date(os.data_hora_fechamento).getTime() : now;
  if (!osStart || Number.isNaN(osStart)) return 0;
  const from = Math.max(osStart, start);
  const to = Math.min(osEnd, end);
  return to > from ? (to - from) / MS_HOUR : 0;
};

/** Horas utilizadas (horímetro) dentro da janela, com filtro de outliers */
const usedHours = (readings: HourMeterReading[], start: number, end: number): number | null => {
  const inWindow = readings
    .filter((r) => {
      const t = new Date(r.timestamp).getTime();
      return t >= start && t < end && r.hourMeter > 0;
    })
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

  if (inWindow.length < 2) return null; // dados insuficientes → ociosidade desconhecida

  let total = 0;
  for (let i = 1; i < inWindow.length; i++) {
    const delta = inWindow[i].hourMeter - inWindow[i - 1].hourMeter;
    const days = Math.max(
      1,
      (new Date(inWindow[i].timestamp).getTime() - new Date(inWindow[i - 1].timestamp).getTime()) / (24 * MS_HOUR)
    );
    if (delta <= 0) continue; // leitura repetida ou retroativa
    if (delta > days * 24) continue; // salto impossível → descartado
    total += delta;
  }
  return total;
};

export interface EquipmentMetrics {
  equipment: Equipment;
  type: string;
  costCenter: string;
  businessUnit: string;
  totalHours: number;
  downtimeHours: number;
  availableHours: number;
  usedHours: number | null;
  idleHours: number | null;
  availabilityPct: number;
  unavailabilityPct: number;
  idlePct: number | null;
  osCount: number;
  byType: Record<MaintenanceType, { count: number; hours: number }>;
  mtbfHours: number | null;
  currentlyDown: boolean;
}

export interface MonthlyPoint {
  key: string;
  label: string;
  monthIndex: number;
  totalHours: number;
  downtimeHours: number;
  availableHours: number;
  idleHours: number | null;
  availabilityPct: number;
  unavailabilityPct: number;
  idlePct: number | null;
}

export interface OperationalResult {
  equipmentMetrics: EquipmentMetrics[];
  monthly: MonthlyPoint[];
  totals: {
    totalHours: number;
    downtimeHours: number;
    availableHours: number;
    idleHours: number | null;
    availabilityPct: number;
    unavailabilityPct: number;
    idlePct: number | null;
    equipmentCount: number;
    currentlyDown: number;
    openOrders: number;
    osCount: number;
    mtbfHours: number | null;
    plannedMaintenancePct: number | null;
    idleCoverage: number; // % de equipamentos com dados de horímetro suficientes
  };
  byMaintenanceType: Array<{ type: MaintenanceType; count: number; hours: number; pct: number }>;
  byCostCenter: Array<{
    name: string;
    equipments: number;
    availabilityPct: number;
    unavailabilityPct: number;
    downtimeHours: number;
    idleHours: number | null;
  }>;
  byEquipmentType: Array<{
    name: string;
    equipments: number;
    availabilityPct: number;
    unavailabilityPct: number;
    downtimeHours: number;
    idleHours: number | null;
  }>;
}

const emptyByType = (): Record<MaintenanceType, { count: number; hours: number }> => ({
  avaria: { count: 0, hours: 0 },
  corretiva: { count: 0, hours: 0 },
  pneus: { count: 0, hours: 0 },
  preventiva: { count: 0, hours: 0 },
});

const pct = (part: number, total: number) => (total > 0 ? (part / total) * 100 : 0);

export const computeOperationalMetrics = (
  equipments: Equipment[],
  serviceOrders: ServiceOrder[],
  readings: HourMeterReading[],
  filters: OperationalFilters,
  buckets: Bucket[]
): OperationalResult => {
  const now = Date.now();

  const filteredEquipments = equipments.filter((eq) => {
    if (filters.costCenter !== 'all' && equipmentCostCenter(eq) !== filters.costCenter) return false;
    if (filters.businessUnit !== 'all' && equipmentBusinessUnit(eq) !== filters.businessUnit) return false;
    return true;
  });

  const eqIds = new Set(filteredEquipments.map((e) => e.id));
  const validOrders = serviceOrders.filter(
    (os) => os.status !== 'cancelada' && eqIds.has(os.equipment_id) &&
      (filters.maintenanceType === 'all' || os.tipo_manutencao === filters.maintenanceType)
  );

  const ordersByEquipment = new Map<string, ServiceOrder[]>();
  validOrders.forEach((os) => {
    const list = ordersByEquipment.get(os.equipment_id) || [];
    list.push(os);
    ordersByEquipment.set(os.equipment_id, list);
  });

  const readingsByEquipment = new Map<string, HourMeterReading[]>();
  readings.forEach((r) => {
    const key = r.equipmentId || `code:${r.equipmentCode}`;
    const list = readingsByEquipment.get(key) || [];
    list.push(r);
    readingsByEquipment.set(key, list);
  });

  const windowStart = buckets.length ? buckets[0].start : now;
  const windowEnd = buckets.length ? buckets[buckets.length - 1].end : now;

  // ---------- Por equipamento ----------
  const equipmentMetrics: EquipmentMetrics[] = filteredEquipments.map((eq) => {
    const orders = ordersByEquipment.get(eq.id) || [];
    const eqReadings = readingsByEquipment.get(eq.id) || readingsByEquipment.get(`code:${eq.code}`) || [];

    let totalHours = 0;
    let downtimeHours = 0;
    let used: number | null = null;

    buckets.forEach((b) => {
      totalHours += (b.end - b.start) / MS_HOUR;
      orders.forEach((os) => {
        downtimeHours += overlapHours(os, b.start, b.end, now);
      });
      const u = usedHours(eqReadings, b.start, b.end);
      if (u !== null) used = (used || 0) + u;
    });

    downtimeHours = Math.min(downtimeHours, totalHours);
    const availableHours = Math.max(0, totalHours - downtimeHours);
    const idleHours = used === null ? null : Math.max(0, availableHours - used);

    const byType = emptyByType();
    let osCount = 0;
    orders.forEach((os) => {
      const opened = new Date(os.data_hora_abertura).getTime();
      if (opened < windowStart || opened >= windowEnd) return;
      osCount += 1;
      const t = os.tipo_manutencao;
      if (byType[t]) {
        byType[t].count += 1;
        byType[t].hours += buckets.reduce((s, b) => s + overlapHours(os, b.start, b.end, now), 0);
      }
    });

    const failures = byType.avaria.count + byType.corretiva.count;
    const mtbfHours = failures > 0 ? availableHours / failures : null;

    return {
      equipment: eq,
      type: equipmentType(eq),
      costCenter: equipmentCostCenter(eq),
      businessUnit: equipmentBusinessUnit(eq),
      totalHours,
      downtimeHours,
      availableHours,
      usedHours: used,
      idleHours,
      availabilityPct: pct(availableHours, totalHours),
      unavailabilityPct: pct(downtimeHours, totalHours),
      idlePct: idleHours === null ? null : pct(idleHours, totalHours),
      osCount,
      byType,
      mtbfHours,
      currentlyDown: orders.some((os) => os.status === 'aberta' || os.status === 'em_manutencao'),
    };
  });

  // ---------- Série mensal ----------
  const monthly: MonthlyPoint[] = buckets.map((b) => {
    let totalHours = 0;
    let downtimeHours = 0;
    let idle: number | null = null;

    filteredEquipments.forEach((eq) => {
      const orders = ordersByEquipment.get(eq.id) || [];
      const eqReadings = readingsByEquipment.get(eq.id) || readingsByEquipment.get(`code:${eq.code}`) || [];
      const bucketTotal = (b.end - b.start) / MS_HOUR;
      let down = 0;
      orders.forEach((os) => {
        down += overlapHours(os, b.start, b.end, now);
      });
      down = Math.min(down, bucketTotal);
      totalHours += bucketTotal;
      downtimeHours += down;
      const u = usedHours(eqReadings, b.start, b.end);
      if (u !== null) idle = (idle || 0) + Math.max(0, bucketTotal - down - u);
    });

    const availableHours = Math.max(0, totalHours - downtimeHours);
    return {
      key: b.key,
      label: b.label,
      monthIndex: new Date(b.start).getMonth(),
      totalHours,
      downtimeHours,
      availableHours,
      idleHours: idle,
      availabilityPct: pct(availableHours, totalHours),
      unavailabilityPct: pct(downtimeHours, totalHours),
      idlePct: idle === null ? null : pct(idle, totalHours),
    };
  });

  // ---------- Totais ----------
  const totalHours = equipmentMetrics.reduce((s, e) => s + e.totalHours, 0);
  const downtimeHours = equipmentMetrics.reduce((s, e) => s + e.downtimeHours, 0);
  const availableHours = Math.max(0, totalHours - downtimeHours);
  const withIdle = equipmentMetrics.filter((e) => e.idleHours !== null);
  const idleHours = withIdle.length ? withIdle.reduce((s, e) => s + (e.idleHours || 0), 0) : null;
  const osCount = equipmentMetrics.reduce((s, e) => s + e.osCount, 0);
  const failures = equipmentMetrics.reduce((s, e) => s + e.byType.avaria.count + e.byType.corretiva.count, 0);

  const typeAgg = emptyByType();
  equipmentMetrics.forEach((e) => {
    (Object.keys(typeAgg) as MaintenanceType[]).forEach((t) => {
      typeAgg[t].count += e.byType[t].count;
      typeAgg[t].hours += e.byType[t].hours;
    });
  });
  const maintenanceHours = (Object.values(typeAgg) as Array<{ hours: number }>).reduce((s, v) => s + v.hours, 0);

  const byMaintenanceType = (Object.keys(typeAgg) as MaintenanceType[]).map((t) => ({
    type: t,
    count: typeAgg[t].count,
    hours: typeAgg[t].hours,
    pct: pct(typeAgg[t].hours, maintenanceHours),
  }));

  const groupBy = (selector: (m: EquipmentMetrics) => string) => {
    const map = new Map<string, EquipmentMetrics[]>();
    equipmentMetrics.forEach((m) => {
      const k = selector(m);
      const list = map.get(k) || [];
      list.push(m);
      map.set(k, list);
    });
    return Array.from(map.entries()).map(([name, list]) => {
      const t = list.reduce((s, e) => s + e.totalHours, 0);
      const d = list.reduce((s, e) => s + e.downtimeHours, 0);
      const idleList = list.filter((e) => e.idleHours !== null);
      return {
        name,
        equipments: list.length,
        availabilityPct: pct(t - d, t),
        unavailabilityPct: pct(d, t),
        downtimeHours: d,
        idleHours: idleList.length ? idleList.reduce((s, e) => s + (e.idleHours || 0), 0) : null,
      };
    });
  };

  return {
    equipmentMetrics,
    monthly,
    totals: {
      totalHours,
      downtimeHours,
      availableHours,
      idleHours,
      availabilityPct: pct(availableHours, totalHours),
      unavailabilityPct: pct(downtimeHours, totalHours),
      idlePct: idleHours === null ? null : pct(idleHours, totalHours),
      equipmentCount: equipmentMetrics.length,
      currentlyDown: equipmentMetrics.filter((e) => e.currentlyDown).length,
      openOrders: validOrders.filter((os) => os.status === 'aberta' || os.status === 'em_manutencao').length,
      osCount,
      mtbfHours: failures > 0 ? availableHours / failures : null,
      plannedMaintenancePct: maintenanceHours > 0 ? pct(typeAgg.preventiva.hours, maintenanceHours) : null,
      idleCoverage: equipmentMetrics.length ? (withIdle.length / equipmentMetrics.length) * 100 : 0,
    },
    byMaintenanceType,
    byCostCenter: groupBy((m) => m.costCenter).sort((a, b) => a.availabilityPct - b.availabilityPct),
    byEquipmentType: groupBy((m) => m.type).sort((a, b) => a.availabilityPct - b.availabilityPct),
  };
};

export const formatHours = (h: number | null | undefined) => {
  if (h === null || h === undefined || Number.isNaN(h)) return '—';
  if (h >= 1000) return `${Math.round(h).toLocaleString('pt-BR')} h`;
  return `${h.toFixed(1).replace('.', ',')} h`;
};

export const formatPct = (p: number | null | undefined) => {
  if (p === null || p === undefined || Number.isNaN(p)) return '—';
  return `${p.toFixed(1).replace('.', ',')}%`;
};

export const formatMtbf = (hours: number | null) => {
  if (hours === null) return '—';
  if (hours >= 48) return `${(hours / 24).toFixed(1).replace('.', ',')} dias`;
  return formatHours(hours);
};
