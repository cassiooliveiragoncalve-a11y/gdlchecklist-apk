import jsPDF from 'jspdf';
import logoUrl from '@/assets/gdl-logo-oficial.png';
import {
  ServiceOrder,
  STATUS_LABELS,
  MAINTENANCE_TYPE_LABELS,
  formatDowntime,
  downtimeMinutes,
  isOpenStatus,
} from '@/types/serviceOrder';

const BLUE: [number, number, number] = [98, 127, 150];
const BLUE_LIGHT: [number, number, number] = [239, 243, 246];
const ORANGE: [number, number, number] = [243, 112, 38];
const TEXT: [number, number, number] = [40, 48, 56];
const MUTED: [number, number, number] = [120, 130, 140];

const STATUS_COLOR: Record<string, [number, number, number]> = {
  aberta: [220, 38, 38],
  em_manutencao: ORANGE,
  finalizada: [22, 163, 74],
  cancelada: [107, 114, 128],
};

const fmt = (v?: string | null) =>
  v
    ? new Date(v).toLocaleString('pt-BR', {
        day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
      })
    : '—';

const loadImage = async (src: string) => {
  const blob = await (await fetch(src)).blob();
  const dataUrl = await new Promise<string>((res, rej) => {
    const fr = new FileReader();
    fr.onload = () => res(fr.result as string);
    fr.onerror = rej;
    fr.readAsDataURL(blob);
  });
  const img = await new Promise<HTMLImageElement>((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = dataUrl;
  });
  return { dataUrl, w: img.naturalWidth, h: img.naturalHeight };
};

export const buildServiceOrderPdf = async (os: ServiceOrder) => {
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 15;
  const CW = W - M * 2;
  let y = 0;

  // Faixa superior
  doc.setFillColor(...ORANGE);
  doc.rect(0, 0, W, 3, 'F');

  try {
    const logo = await loadImage(logoUrl);
    const lh = 20;
    doc.addImage(logo.dataUrl, 'PNG', M, 9, (lh * logo.w) / logo.h, lh);
  } catch {
    /* sem logo */
  }

  doc.setTextColor(...BLUE);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.text('ORDEM DE SERVIÇO', W - M, 15, { align: 'right' });
  doc.setFontSize(12);
  doc.setTextColor(...ORANGE);
  doc.text(os.numero_os, W - M, 22, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(...MUTED);
  doc.text(`Emitido em ${new Date().toLocaleString('pt-BR')}`, W - M, 27, { align: 'right' });

  y = 34;
  doc.setDrawColor(...BLUE);
  doc.setLineWidth(0.6);
  doc.line(M, y, W - M, y);
  y += 6;

  // Status + tempo
  const sc = STATUS_COLOR[os.status] ?? BLUE;
  doc.setFillColor(...sc);
  doc.roundedRect(M, y, 45, 9, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.text(STATUS_LABELS[os.status].toUpperCase(), M + 22.5, y + 6, { align: 'center' });

  const open = isOpenStatus(os.status);
  const minutes = open ? downtimeMinutes(os) : os.tempo_indisponibilidade_minutos;
  doc.setFillColor(...BLUE_LIGHT);
  doc.roundedRect(M + 50, y, CW - 50, 9, 2, 2, 'F');
  doc.setTextColor(...MUTED);
  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.text(open ? 'INDISPONÍVEL HÁ' : 'TEMPO TOTAL DE INDISPONIBILIDADE', M + 54, y + 5.8);
  doc.setTextColor(...TEXT);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(formatDowntime(minutes), W - M - 4, y + 6.2, { align: 'right' });
  y += 16;

  const sectionTitle = (t: string) => {
    if (y > H - 40) { doc.addPage(); y = M; }
    doc.setFillColor(...BLUE);
    doc.rect(M, y, CW, 7, 'F');
    doc.setFillColor(...ORANGE);
    doc.rect(M, y, 2, 7, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.text(t.toUpperCase(), M + 5, y + 4.8);
    y += 10;
  };

  const grid = (items: [string, string][]) => {
    const colW = CW / 3;
    for (let i = 0; i < items.length; i += 3) {
      const row = items.slice(i, i + 3);
      let rowH = 0;
      row.forEach(([label, value], j) => {
        const x = M + j * colW + 2;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(7);
        doc.setTextColor(...MUTED);
        doc.text(label.toUpperCase(), x, y + 3);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9.5);
        doc.setTextColor(...TEXT);
        const lines = doc.splitTextToSize(value || '—', colW - 4);
        doc.text(lines, x, y + 8);
        rowH = Math.max(rowH, 6 + lines.length * 4.2);
      });
      y += rowH + 2;
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.2);
      doc.line(M, y - 1, W - M, y - 1);
    }
    y += 3;
  };

  const textBlock = (label: string, value?: string | null, minH = 0) => {
    const lines = doc.splitTextToSize(value?.trim() || '—', CW - 8);
    const h = Math.max(minH, lines.length * 4.5 + 10);
    if (y + h > H - 18) { doc.addPage(); y = M; }
    doc.setDrawColor(210, 218, 226);
    doc.setLineWidth(0.3);
    doc.roundedRect(M, y, CW, h, 1.5, 1.5, 'S');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(...BLUE);
    doc.text(label.toUpperCase(), M + 4, y + 5);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(...TEXT);
    doc.text(lines, M + 4, y + 10.5);
    y += h + 4;
  };

  sectionTitle('Dados do equipamento');
  grid([
    ['Equipamento', os.equipment_code],
    ['Modelo', os.equipment_model || '—'],
    ['Unidade de negócio', os.unit || '—'],
    ['Local', os.location || '—'],
    ['Oficina', os.oficina || '—'],
    ['Tipo de manutenção', MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]],
  ]);

  sectionTitle('Controle da OS');
  grid([
    ['Mecânico responsável', os.mecanico_responsavel],
    ['Abertura', fmt(os.data_hora_abertura)],
    ['Início manutenção', fmt(os.data_hora_inicio_manutencao)],
    ['Fechamento', fmt(os.data_hora_fechamento)],
    ['Status', STATUS_LABELS[os.status]],
    ['Indisponibilidade', formatDowntime(minutes)],
  ]);

  sectionTitle('Detalhamento');
  textBlock('Descrição da ocorrência', os.descricao_ocorrencia, 18);
  textBlock('Causa identificada', os.causa_identificada, 16);
  textBlock('Serviço executado', os.servico_executado, 22);
  textBlock('Peças / materiais utilizados', os.pecas_materiais, 16);
  textBlock('Observações', os.observacoes, 14);
  if (os.motivo_cancelamento) textBlock('Motivo do cancelamento', os.motivo_cancelamento);

  // Assinaturas
  if (y > H - 40) { doc.addPage(); y = M; }
  const sy = Math.max(y + 14, H - 26);
  const sw = (CW - 20) / 3;
  ['Mecânico responsável', 'Supervisor / Gestor', 'Operação'].forEach((label, i) => {
    const x = M + i * (sw + 10);
    doc.setDrawColor(...TEXT);
    doc.setLineWidth(0.3);
    doc.line(x, sy, x + sw, sy);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(...MUTED);
    doc.text(label, x + sw / 2, sy + 4.5, { align: 'center' });
  });

  // Rodapé
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i);
    doc.setFillColor(...BLUE);
    doc.rect(0, H - 12, W, 12, 'F');
    doc.setFillColor(...ORANGE);
    doc.rect(0, H - 12, W, 1, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.text('GDL · Solução em movimento', M, H - 5);
    doc.text(`${os.numero_os} · Página ${i} de ${pages}`, W - M, H - 5, { align: 'right' });
  }

  return doc;
};

export const printServiceOrder = async (os: ServiceOrder) => {
  const win = window.open('', '_blank');
  const doc = await buildServiceOrderPdf(os);
  doc.autoPrint();
  const url = doc.output('bloburl') as unknown as string;
  if (win) {
    win.location.href = url;
  } else {
    doc.save(`${os.numero_os}.pdf`);
  }
};

export const downloadServiceOrderPdf = async (os: ServiceOrder) => {
  const doc = await buildServiceOrderPdf(os);
  doc.save(`${os.numero_os}.pdf`);
};
