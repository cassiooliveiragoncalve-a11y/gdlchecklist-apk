import { createRoot } from "react-dom/client";
import { registerSW } from "virtual:pwa-register";
import App from "./App.tsx";
import "./index.css";

const root = document.getElementById("root");

if (!root) {
  throw new Error("Elemento raiz da aplicação não encontrado");
}

const isPreview =
  window.location.hostname === "localhost" ||
  window.location.hostname.includes("-preview--") ||
  window.location.hostname.startsWith("id-preview--");

async function clearPreviewServiceWorker() {
  if (!isPreview) return;

  const hadController = Boolean(navigator.serviceWorker?.controller);

  if ("serviceWorker" in navigator) {
    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.map((registration) => registration.unregister()));
  }

  if ("caches" in window) {
    const cacheNames = await caches.keys();
    // O preview nunca deve reutilizar nenhum cache persistente. A versão
    // publicada continua usando normalmente o cache offline da PWA.
    await Promise.all(cacheNames.map((name) => caches.delete(name)));
  }

  // Um service worker continua controlando a aba até a próxima navegação.
  // Recarrega uma única vez para o preview passar a usar sempre os assets atuais.
  const reloadKey = "gdl-preview-cache-cleared";
  const buildTimestamp = "__BUILD_TIMESTAMP__";
  const lastBuild = sessionStorage.getItem("gdl-preview-last-build");
  const buildChanged = lastBuild && lastBuild !== buildTimestamp;
  sessionStorage.setItem("gdl-preview-last-build", buildTimestamp);

  if ((hadController || buildChanged) && !sessionStorage.getItem(reloadKey)) {
    sessionStorage.setItem(reloadKey, "1");
    window.location.reload();
    await new Promise(() => undefined);
  }
}

async function bootstrap() {
  await clearPreviewServiceWorker();

  const isNative = !!(window as any).Capacitor?.isNativePlatform?.();
  if (!isPreview && !isNative) {
    let refreshing = false;
    const updateSW = registerSW({
      immediate: true,
      onNeedRefresh() {
        void updateSW(true);
      },
      onRegisteredSW(_swUrl, registration) {
        if (!registration) return;
        window.setInterval(() => void registration.update(), 5 * 60 * 1000);
      },
    });

    navigator.serviceWorker?.addEventListener("controllerchange", () => {
      if (refreshing) return;
      refreshing = true;
      window.location.reload();
    });
  }

  createRoot(root).render(<App />);
}

void bootstrap();
