import { useState, useEffect, useRef, useMemo } from "react";
import { useReactToPrint } from 'react-to-print';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useSupabaseAuth";
import { useChecklistDetails } from "@/hooks/useChecklistDetails";
import { useChecklistHistoryPaginated, PAGE_SIZE } from "@/hooks/useChecklistHistoryPaginated";
import { supabase } from "@/integrations/supabase/client";
import { ReportExportDialog, ReportFilterDef } from "@/components/reports/ReportExportDialog";
import { PhotoGrid } from "@/components/ui/photo-viewer";
import {
  Clock,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Eye,
  Calendar,
  FileText,
  User,
  Truck,
  Camera,
  PenTool,
  Trash2,
  Printer,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

import { ChecklistRecord, ChecklistAnswer } from '@/types/equipment';
import { getChecklistItemById } from '@/lib/checklistItems';
import { checklistTypeLabels, ChecklistType } from '@/lib/liftingAccessoryChecklists';

// Helper to transform answers for display
const transformAnswersForDisplay = (answers: ChecklistAnswer[], photos?: Record<string, string[]>) => {
  return answers.map(answer => {
    const item = getChecklistItemById(answer.itemId);
    return {
      question: item?.description || answer.itemId,
      answer: answer.value === 'sim' ? 'Sim' : answer.value === 'nao' ? 'Não' : 'N/A',
      conformidade: answer.value === 'sim' ? 'conforme' : answer.value === 'nao' ? 'nao_conforme' : 'nao_aplica',
      observation: answer.observation,
      photos: photos?.[answer.itemId] || []
    };
  });
};

interface ChecklistHistoryProps {
  // Mantido por compatibilidade com Index.tsx — não é mais utilizado.
  records?: ChecklistRecord[];
  isLoading?: boolean;
  userProfile?: string;
  currentUser?: { name: string; matricula?: string };
}

const ChecklistHistory = ({}: ChecklistHistoryProps) => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { loadChecklistDetails, loading: detailsLoading } = useChecklistDetails();
  const printRef = useRef<HTMLDivElement>(null);

  const [searchInput, setSearchInput] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [typeFilter, setTypeFilter] = useState("todos");
  const [monthFilter, setMonthFilter] = useState("todos");
  const [yearFilter, setYearFilter] = useState("todos");
  const [page, setPage] = useState(1);
  const [selectedRecord, setSelectedRecord] = useState<ChecklistRecord | null>(null);
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [checklistToDelete, setChecklistToDelete] = useState<ChecklistRecord | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isMechanic, setIsMechanic] = useState(false);

  // Debounce da busca (400ms) para não bater no banco a cada tecla
  useEffect(() => {
    const t = setTimeout(() => {
      setSearchTerm(searchInput.trim());
      setPage(1);
    }, 400);
    return () => clearTimeout(t);
  }, [searchInput]);

  // Reseta paginação sempre que qualquer filtro muda
  useEffect(() => {
    setPage(1);
  }, [statusFilter, typeFilter, monthFilter, yearFilter]);

  // Consulta paginada (50 registros por vez, filtros aplicados no servidor)
  const operatorName = user?.profile === 'operador' ? user.name : undefined;
  const { data: pageData, isLoading, isFetching } = useChecklistHistoryPaginated(
    page,
    {
      search: searchTerm,
      status: statusFilter,
      checklistType: typeFilter,
      year: yearFilter,
      month: monthFilter,
      operatorName,
    },
    !!user,
  );

  const filteredRecords = (pageData?.records as ChecklistRecord[]) || [];
  const totalRecords = pageData?.total || 0;
  const totalPages = pageData?.totalPages || 1;

  // Carregar detalhes quando o dialog for aberto
  useEffect(() => {
    const loadDetails = async () => {
      if (isDetailDialogOpen && selectedRecord && !selectedRecord.checklistAnswers?.length) {
        const details = await loadChecklistDetails(selectedRecord.id);
        if (details) {
          setSelectedRecord(prev => prev ? { ...prev, ...details } : null);
        }
      }
    };
    loadDetails();
  }, [isDetailDialogOpen, selectedRecord?.id]);

  // Check if user is admin or mechanic
  useEffect(() => {
    if (user) {
      supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle()
        .then(({ data }) => setIsAdmin(!!data));

      supabase
        .from('profiles')
        .select('profile')
        .eq('id', user.id)
        .maybeSingle()
        .then(({ data }) => {
          setIsMechanic(data?.profile === 'mecanico' || data?.profile === 'gestor' || data?.profile === 'admin');
        });
    }
  }, [user]);

  // Anos disponíveis: últimos 5 anos (estático — evita depender do dataset carregado)
  const availableYears = useMemo(() => {
    const now = new Date().getFullYear();
    return Array.from({ length: 5 }, (_, i) => String(now - i));
  }, []);

  // Meses do ano selecionado (ou do ano atual quando 'todos')
  const availableMonths = useMemo(() => {
    const y = yearFilter !== 'todos' ? parseInt(yearFilter, 10) : new Date().getFullYear();
    return Array.from({ length: 12 }, (_, i) => `${y}-${String(i + 1).padStart(2, '0')}`);
  }, [yearFilter]);

  const getMonthName = (monthKey: string) => {
    const [year, month] = monthKey.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1);
    return date.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'conforme':
        return <CheckCircle className="w-5 h-5 text-safety-green" />;
      case 'pendente':
        return <Clock className="w-5 h-5 text-safety-orange" />;
      case 'negado':
        return <XCircle className="w-5 h-5 text-safety-red" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'conforme':
        return <Badge className="bg-safety-green text-white">Aprovado</Badge>;
      case 'pendente':
        return <Badge className="bg-safety-orange text-white">Pendente</Badge>;
      case 'negado':
        return <Badge className="bg-safety-red text-white">Negado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const formatDateTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const dateStr = date.toLocaleDateString('pt-BR');
    const timeStr = date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    return { dateStr, timeStr };
  };

  const handleDeleteClick = (record: ChecklistRecord) => {
    setChecklistToDelete(record);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!checklistToDelete) return;

    try {
      const { error } = await supabase
        .from('checklist_records')
        .delete()
        .eq('id', checklistToDelete.id);

      if (error) throw error;

      toast({
        title: "Checklist deletado",
        description: `O checklist do equipamento ${checklistToDelete.equipmentCode} foi removido com sucesso.`,
      });

      setDeleteDialogOpen(false);
      setChecklistToDelete(null);
      window.location.reload();
    } catch (error) {
      console.error('Erro ao deletar checklist:', error);
      toast({
        title: "Erro ao deletar",
        description: "Não foi possível deletar o checklist.",
        variant: "destructive",
      });
    }
  };

  const handleDownloadPDF = useReactToPrint({
    contentRef: printRef,
    documentTitle: `Checklist_${selectedRecord?.equipmentCode}_${new Date(selectedRecord?.timestamp || '').toLocaleDateString('pt-BR').replace(/\//g, '-')}`,
    onAfterPrint: () => {
      toast({
        title: "PDF gerado com sucesso",
        description: "O documento foi gerado e está pronto para salvar.",
      });
    },
  });

  // ---- Relatório com filtros próprios (busca direto no banco, máx. 2000 registros) ----
  const checklistReportFilters: ReportFilterDef[] = useMemo(() => {
    const years = Array.from({ length: 5 }, (_, i) => String(new Date().getFullYear() - i));
    return [
      {
        key: 'status',
        label: 'Status',
        type: 'select',
        options: [
          { value: 'todos', label: 'Todos' },
          { value: 'conforme', label: 'Aprovado' },
          { value: 'pendente', label: 'Pendente' },
          { value: 'negado', label: 'Negado' },
        ],
      },
      {
        key: 'tipo',
        label: 'Tipo de checklist',
        type: 'select',
        options: [
          { value: 'todos', label: 'Todos' },
          ...Object.entries(checklistTypeLabels).map(([value, label]) => ({ value, label: String(label) })),
        ],
      },
      {
        key: 'ano',
        label: 'Ano',
        type: 'select',
        options: [{ value: 'todos', label: 'Todos' }, ...years.map((y) => ({ value: y, label: y }))],
      },
      { key: 'de', label: 'De', type: 'date' },
      { key: 'ate', label: 'Até', type: 'date' },
      { key: 'equipamento', label: 'Equipamento (código)', type: 'text', placeholder: 'Ex.: EMP-742' },
      { key: 'operador', label: 'Operador', type: 'text', placeholder: 'Nome do operador' },
    ];
  }, []);

  const buildChecklistReport = async (v: Record<string, string>) => {
    let q: any = supabase
      .from('checklist_records')
      .select('equipment_code,equipment_model,operator_name,operator_id,timestamp,status,total_items,conforme_items,nao_conforme_items,location,unit,hour_meter,checklist_type,session_status,started_at,ended_at,worked_hours')
      .order('timestamp', { ascending: false })
      .limit(2000);

    if (v.status !== 'todos') q = q.eq('status', v.status);
    if (v.tipo !== 'todos') q = q.eq('checklist_type', v.tipo);
    if (v.de) q = q.gte('timestamp', new Date(`${v.de}T00:00:00`).toISOString());
    if (v.ate) q = q.lte('timestamp', new Date(`${v.ate}T23:59:59`).toISOString());
    if (!v.de && !v.ate && v.ano !== 'todos') {
      const y = parseInt(v.ano, 10);
      q = q.gte('timestamp', new Date(y, 0, 1).toISOString()).lt('timestamp', new Date(y + 1, 0, 1).toISOString());
    }
    if (v.equipamento?.trim()) q = q.ilike('equipment_code', `%${v.equipamento.trim()}%`);
    if (operatorName) q = q.eq('operator_name', operatorName);
    else if (v.operador?.trim()) q = q.ilike('operator_name', `%${v.operador.trim()}%`);

    const { data, error } = await q;
    if (error) throw error;
    const list = (data || []) as any[];

    const statusLabel = (s: string) =>
      s === 'conforme' ? 'Aprovado' : s === 'pendente' ? 'Pendente' : s === 'negado' ? 'Negado' : s;
    const dt = (d: string | null) => (d ? new Date(d).toLocaleString('pt-BR') : '');

    const head = ['Data', 'Equipamento', 'Modelo', 'Operador', 'Status', 'Itens', 'Conformes', 'Não conformes', 'Horímetro', 'Local'];
    const body = list.map((r) => [
      dt(r.timestamp),
      r.equipment_code,
      r.equipment_model || '',
      r.operator_name,
      statusLabel(r.status),
      r.total_items ?? '',
      r.conforme_items ?? '',
      r.nao_conforme_items ?? '',
      r.hour_meter ?? '',
      r.location || '',
    ]);

    const rows = list.map((r) => ({
      Data: dt(r.timestamp),
      Equipamento: r.equipment_code,
      Modelo: r.equipment_model || '',
      Operador: r.operator_name,
      Matrícula: r.operator_id || '',
      Status: statusLabel(r.status),
      Tipo: r.checklist_type || '',
      'Total de itens': r.total_items ?? '',
      Conformes: r.conforme_items ?? '',
      'Não conformes': r.nao_conforme_items ?? '',
      Horímetro: r.hour_meter ?? '',
      Local: r.location || '',
      Unidade: r.unit || '',
      Sessão: r.session_status || '',
      Início: dt(r.started_at),
      Encerramento: dt(r.ended_at),
      'Horas trabalhadas': r.worked_hours ?? '',
    }));

    return {
      head,
      body,
      sheets: [{ name: 'Checklists', rows }],
      subtitle: `${list.length} checklist(s)`,
    };
  };


  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Histórico de Checklists</h2>
          <p className="text-gray-600">Consulta e gestão de inspeções realizadas</p>
        </div>
        <ReportExportDialog
          title="Relatório de Checklists"
          description="Filtre os checklists antes de exportar em PDF ou Excel."
          fileName="checklists"
          filters={checklistReportFilters}
          buildData={buildChecklistReport}
        />
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <Input
                placeholder="Buscar por equipamento ou operador..."
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                className="pl-10"
              />
            </div>
            
            {/* Status Filter */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Status</SelectItem>
                <SelectItem value="conforme">Aprovado</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="negado">Negado</SelectItem>
              </SelectContent>
            </Select>

            {/* Type Filter */}
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos Tipos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Tipos</SelectItem>
                <SelectItem value="empilhadeira">Empilhadeiras</SelectItem>
                <SelectItem value="cinta_icamento">Cintas</SelectItem>
                <SelectItem value="manilha">Manilhas</SelectItem>
                <SelectItem value="gancho">Ganchos</SelectItem>
                <SelectItem value="corrente_icamento">Correntes</SelectItem>
              </SelectContent>
            </Select>

            {/* Year Filter */}
            <Select value={yearFilter} onValueChange={setYearFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos os Anos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Anos</SelectItem>
                {availableYears.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Month Filter */}
            <Select value={monthFilter} onValueChange={setMonthFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos os Meses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os Meses</SelectItem>
                {availableMonths.map(month => (
                  <SelectItem key={month} value={month}>
                    {getMonthName(month)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Results count */}
          <div className="flex items-center gap-2 mt-4 pt-4 border-t">
            <Filter className="w-4 h-4 text-gray-600" />
            <span className="text-sm text-gray-600">
              Página {page} de {totalPages} — mostrando {filteredRecords.length} de {totalRecords} registros
              {isFetching && !isLoading && ' • atualizando…'}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {isLoading && (
        <div className="text-center py-12">
          <div className="w-12 h-12 border-4 border-industrial-blue border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600 font-medium">Carregando histórico de checklists...</p>
        </div>
      )}

      {/* Records List */}
      {!isLoading && (
        <div className="space-y-4">
          {filteredRecords.length > 0 ? (
            filteredRecords.map((record) => {
            const { dateStr, timeStr } = formatDateTime(record.timestamp);
            
            return (
              <Card key={record.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4 flex-1">
                      {getStatusIcon(record.status)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg text-gray-900">
                            {record.checklistType && record.checklistType !== 'empilhadeira' 
                              ? checklistTypeLabels[record.checklistType as ChecklistType]
                              : `${record.equipmentCode} - ${record.equipmentModel}`}
                          </h3>
                          {getStatusBadge(record.status)}
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600 mb-3">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4" />
                            <span>Operador: {record.operatorName}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4" />
                            <span>{dateStr} às {timeStr}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-safety-green font-medium">
                            ✓ {record.conformeItems} conformes
                          </span>
                          {record.naoConformeItems > 0 && (
                            <span className="text-safety-red font-medium">
                              ✗ {record.naoConformeItems} não conformes
                            </span>
                          )}
                          <span className="text-gray-600">
                            Total: {record.totalItems} itens
                          </span>
                        </div>

                        {/* Show rejection reason if negated */}
                        {record.status === 'negado' && record.rejections && record.rejections.length > 0 && (
                          <div className="mt-2 p-2 bg-safety-red-light rounded border-l-4 border-safety-red">
                            <p className="text-sm text-safety-red font-medium">
                              Motivo da negação: {record.rejections[record.rejections.length - 1].reason}
                            </p>
                          </div>
                        )}

                        {/* Show approval comment if approved */}
                        {record.status === 'conforme' && record.approvals && record.approvals.length > 0 && (
                          <div className="mt-2 p-2 bg-safety-green-light rounded border-l-4 border-safety-green">
                            <p className="text-sm text-safety-green font-medium">
                              Aprovado por: {record.approvals[record.approvals.length - 1].mechanicName}
                            </p>
                            {record.approvals[record.approvals.length - 1].comment && (
                              <p className="text-sm text-gray-600">
                                {record.approvals[record.approvals.length - 1].comment}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedRecord(record);
                          setIsDetailDialogOpen(true);
                        }}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        Detalhes
                      </Button>
                      {isAdmin && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteClick(record)}
                          className="text-safety-red hover:text-safety-red hover:bg-safety-red/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
         ) : (
           <Card>
             <CardContent className="p-12 text-center">
               <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                 <FileText className="w-8 h-8 text-gray-400" />
               </div>
               <h3 className="text-lg font-medium text-gray-900 mb-2">
                 Nenhum registro encontrado
               </h3>
               <p className="text-gray-600">
                 {searchTerm || statusFilter !== "todos" || monthFilter !== "todos" || yearFilter !== "todos"
                   ? 'Nenhum resultado encontrado para os filtros aplicados.'
                   : 'Nenhum checklist foi realizado ainda.'}
               </p>
             </CardContent>
           </Card>
          )}
        </div>
      )}

      {/* Pagination */}
      {!isLoading && totalPages > 1 && (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <p className="text-sm text-gray-600">
            Exibindo {(page - 1) * PAGE_SIZE + 1}
            –{Math.min(page * PAGE_SIZE, totalRecords)} de {totalRecords} registros
          </p>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1 || isFetching}
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Anterior
            </Button>
            <span className="text-sm font-medium text-gray-700 px-2">
              Página {page} de {totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages || isFetching}
            >
              Próxima
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      )}


      {/* Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="max-w-5xl h-[90vh] flex flex-col p-0">
          <DialogHeader className="flex-shrink-0 px-6 pt-6 pb-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5" />
                <DialogTitle>Detalhes do Checklist</DialogTitle>
              </div>
              {isMechanic && (
                <Button
                  onClick={handleDownloadPDF}
                  variant="outline"
                  size="sm"
                >
                  <Printer className="w-4 h-4 mr-2" />
                  Imprimir/PDF
                </Button>
              )}
            </div>
            <DialogDescription>
              {selectedRecord && `${selectedRecord.equipmentCode} - ${selectedRecord.equipmentModel}`}
            </DialogDescription>
          </DialogHeader>
          
          {selectedRecord && (
            <div className="flex-1 overflow-y-auto px-6 pb-6">
              <div className="print-content" ref={printRef}>
              {/* Print Header - Only visible when printing */}
              <div className="print-only mb-6 pb-4 border-b-2 border-gray-300">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">
                  Relatório de Checklist de Segurança
                </h1>
                <p className="text-gray-600">
                  Documento gerado em: {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}
                </p>
              </div>

              {/* Equipment Details Section */}
              <div className="mb-4 p-4 bg-gray-50 rounded-lg border-l-4 border-industrial-blue print:bg-gray-100 mt-4">
                <h3 className="font-bold text-gray-900 mb-3 flex items-center gap-2">
                  <Truck className="w-5 h-5" />
                  Dados do Equipamento
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Código:</span>
                    <p className="text-gray-900 font-semibold">{selectedRecord.equipmentCode}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Modelo:</span>
                    <p className="text-gray-900 font-semibold">{selectedRecord.equipmentModel}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Horímetro:</span>
                    <p className="text-gray-900">{selectedRecord.hourMeter ?? 'Não informado'} {selectedRecord.hourMeter ? 'horas' : ''}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Local:</span>
                    <p className="text-gray-900">{selectedRecord.location || 'Não informado'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Unidade:</span>
                    <p className="text-gray-900">{selectedRecord.unit || 'Não informado'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Série:</span>
                    <p className="text-gray-900">{selectedRecord.equipmentSeries || 'Não informado'}</p>
                  </div>
                  <div>
                    <span className="text-sm font-medium text-gray-600">Número:</span>
                    <p className="text-gray-900">{selectedRecord.equipmentNumber || 'Não informado'}</p>
                  </div>
                  {selectedRecord.equipmentModel_type && (
                    <div>
                      <span className="text-sm font-medium text-gray-600">Tipo:</span>
                      <p className="text-gray-900">{selectedRecord.equipmentModel_type}</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Operator Info Header */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg mb-4 print:bg-blue-100">
                <div>
                  <span className="text-sm font-medium text-gray-600">Operador:</span>
                  <p className="text-gray-900 font-semibold">{selectedRecord.operatorName}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">ID Operador:</span>
                  <p className="text-gray-900">{selectedRecord.operatorId}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Data/Hora:</span>
                  <p className="text-gray-900">
                    {formatDateTime(selectedRecord.timestamp).dateStr} às {formatDateTime(selectedRecord.timestamp).timeStr}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Status:</span>
                  <div className="mt-1">
                    {getStatusBadge(selectedRecord.status)}
                  </div>
                </div>
                
                {selectedRecord.checklistType && selectedRecord.checklistType !== 'empilhadeira' ? (
                  <>
                    <div className="col-span-full">
                      <span className="text-sm font-medium text-gray-600">Tipo de Checklist:</span>
                      <p className="text-gray-900 font-semibold">
                        {checklistTypeLabels[selectedRecord.checklistType as ChecklistType] || selectedRecord.checklistType}
                      </p>
                    </div>
                    {selectedRecord.operationDescription && (
                      <div className="col-span-full">
                        <span className="text-sm font-medium text-gray-600">Descrição da Operação:</span>
                        <p className="text-gray-900">{selectedRecord.operationDescription}</p>
                      </div>
                    )}
                    {selectedRecord.loadDescription && (
                      <div className="col-span-full">
                        <span className="text-sm font-medium text-gray-600">Carga:</span>
                        <p className="text-gray-900">{selectedRecord.loadDescription}</p>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="col-span-full">
                    <span className="text-sm font-medium text-gray-600">Tipo de Checklist:</span>
                    <p className="text-gray-900 font-semibold">Equipamento Móvel</p>
                  </div>
                )}
              </div>

              {/* Summary Stats */}
              <div className="grid grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg mb-4 print:bg-blue-100">
                <div className="text-center">
                  <p className="text-2xl font-bold text-safety-green">{selectedRecord.conformeItems}</p>
                  <p className="text-sm text-gray-600">Conformes</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-safety-red">{selectedRecord.naoConformeItems}</p>
                  <p className="text-sm text-gray-600">Não Conformes</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-gray-700">{selectedRecord.totalItems}</p>
                  <p className="text-sm text-gray-600">Total de Itens</p>
                </div>
              </div>

              {/* Answers */}
              {selectedRecord.checklistAnswers && selectedRecord.checklistAnswers.length > 0 && (
                <div className="mb-6">
                  <h4 className="font-medium text-gray-900 mb-4 flex items-center gap-2 sticky top-0 bg-white py-2 z-10 print:static">
                    <FileText className="w-5 h-5" />
                    Respostas do Checklist:
                  </h4>
                  <div className="space-y-3">
                    {transformAnswersForDisplay(selectedRecord.checklistAnswers, selectedRecord.photos).map((answer, index) => {
                      const hasPhotos = answer.photos && answer.photos.length > 0;
                      return (
                        <div 
                          key={index} 
                          className={`border rounded-lg p-3 bg-white hover:shadow-sm transition-shadow print-answer-item ${hasPhotos ? 'has-photos border-amber-400 border-2' : ''}`}
                        >
                          <div className="space-y-2">
                            <div className="flex items-start justify-between gap-2">
                              <h5 className="font-semibold text-gray-900 text-sm flex-1">
                                {index + 1}. {answer.question}
                              </h5>
                              {hasPhotos && (
                                <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-800 text-xs font-bold px-2 py-1 rounded print-photo-indicator">
                                  <Camera className="w-3 h-3" />
                                  {answer.photos!.length} foto{answer.photos!.length > 1 ? 's' : ''}
                                </span>
                              )}
                            </div>
                            
                            <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                              <div className="flex-1">
                                <span className="text-xs text-gray-500">Resposta:</span>
                                <p className="text-gray-900 font-medium">{answer.answer}</p>
                              </div>
                               <Badge 
                                 variant={answer.conformidade === 'conforme' ? 'default' : 'destructive'}
                                 className={`${
                                   answer.conformidade === 'conforme' 
                                     ? 'bg-safety-green text-white print-badge-conforme' 
                                     : answer.conformidade === 'nao_conforme'
                                       ? 'bg-safety-red text-white print-badge-nao-conforme'
                                       : 'bg-gray-500 text-white'
                                 } shrink-0`}
                               >
                                 {answer.conformidade === 'conforme' 
                                   ? 'Conforme' 
                                   : answer.conformidade === 'nao_conforme'
                                     ? 'Não Conforme'
                                     : 'N/A'}
                               </Badge>
                            </div>

                            {hasPhotos && (
                              <div className="border-t-2 border-amber-300 pt-3 mt-3 bg-amber-50 -mx-3 px-3 pb-3 rounded-b-lg print-photo-section">
                                <h6 className="text-sm font-bold text-amber-800 mb-3 flex items-center gap-2">
                                  <Camera className="w-4 h-4" />
                                  📷 FOTOS ANEXADAS ({answer.photos!.length}):
                                </h6>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 print-photo-grid">
                                  {answer.photos!.map((photo, photoIndex) => (
                                    <div key={photoIndex} className="print-photo-item border-2 border-gray-300 rounded-lg overflow-hidden shadow-md bg-white">
                                      <img 
                                        src={photo} 
                                        alt={`Foto ${photoIndex + 1} - ${answer.question}`}
                                        className="w-full h-32 md:h-40 object-cover print:h-auto print:max-h-48"
                                        loading="lazy"
                                      />
                                      <div className="text-center text-xs py-1 bg-gray-100 font-medium text-gray-700">
                                        Foto {photoIndex + 1}
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {answer.observation && (
                              <div className="border-t pt-2 mt-2">
                                <span className="text-xs font-medium text-gray-700">Observação:</span>
                                <p className="text-sm text-gray-600 mt-1">{answer.observation}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Signature section */}
              {selectedRecord.signature && (
                <div className="mt-6 pt-4 border-t">
                  <h4 className="font-medium text-gray-900 mb-3 flex items-center gap-2">
                    <PenTool className="w-5 h-5" />
                    Assinatura Digital:
                  </h4>
                  <div className="border rounded-lg p-4 bg-gray-50 flex justify-center">
                    <img 
                      src={selectedRecord.signature} 
                      alt="Assinatura do operador"
                      className="max-h-32 max-w-full object-contain"
                    />
                  </div>
                </div>
              )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja deletar este checklist do equipamento <strong>{checklistToDelete?.equipmentCode}</strong>?
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDeleteConfirm}
              className="bg-safety-red hover:bg-safety-red/90"
            >
              Deletar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

    </div>
  );
};

export default ChecklistHistory;
