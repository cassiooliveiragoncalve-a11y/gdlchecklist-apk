import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { PlayCircle, StopCircle, Clock } from 'lucide-react';
import { useChecklists } from '@/hooks/useChecklists';
import { useAuth } from '@/hooks/useSupabaseAuth';
import { ChecklistRecord } from '@/types/equipment';

const fmt = (n: number, d = 1) =>
  n.toLocaleString('pt-BR', { minimumFractionDigits: d, maximumFractionDigits: d });

interface Props {
  /** Quando true, mostra apenas as sessões do operador logado */
  onlyMine?: boolean;
}

export const ActiveChecklistSessions = ({ onlyMine = false }: Props) => {
  const { checklistRecords, closeChecklistSession } = useChecklists();
  const { user } = useAuth();
  const [target, setTarget] = useState<ChecklistRecord | null>(null);
  const [endValue, setEndValue] = useState('');
  const [justification, setJustification] = useState('');
  const [saving, setSaving] = useState(false);

  const sessions = useMemo(() => {
    let list = (checklistRecords as ChecklistRecord[]).filter(
      (r) => r.sessionStatus === 'em_andamento',
    );
    if (onlyMine && user) list = list.filter((r) => r.operatorName === user.name);
    return list.sort(
      (a, b) =>
        new Date(b.startedAt || b.timestamp).getTime() -
        new Date(a.startedAt || a.timestamp).getTime(),
    );
  }, [checklistRecords, onlyMine, user]);

  const start = target ? Number(target.hourMeterStart ?? target.hourMeter ?? 0) : 0;
  const endNum = parseFloat((endValue || '').replace(',', '.'));
  const worked = isFinite(endNum) ? endNum - start : NaN;
  const isBelow = isFinite(endNum) && endNum < start;

  const handleClose = async () => {
    if (!target || !isFinite(endNum)) return;
    setSaving(true);
    const ok = await closeChecklistSession(target.id, endNum, justification);
    setSaving(false);
    if (ok) {
      setTarget(null);
      setEndValue('');
      setJustification('');
    }
  };

  if (sessions.length === 0) return null;

  return (
    <>
      <Card className="border-primary/40">
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <PlayCircle className="w-4 h-4 text-primary" />
            Checklists em andamento ({sessions.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {sessions.map((s) => (
            <div
              key={s.id}
              className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-lg border bg-card"
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{s.equipmentCode}</span>
                  <Badge variant="secondary">Em andamento</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {s.operatorName} · Início:{' '}
                  {new Date(s.startedAt || s.timestamp).toLocaleString('pt-BR')} · Horímetro
                  inicial: {fmt(Number(s.hourMeterStart ?? s.hourMeter ?? 0))} h
                </p>
              </div>
              <Button
                size="sm"
                onClick={() => {
                  setTarget(s);
                  setEndValue('');
                  setJustification('');
                }}
              >
                <StopCircle className="w-4 h-4 mr-1" />
                Encerrar Checklist
              </Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <Dialog open={!!target} onOpenChange={(o) => !o && setTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Encerrar checklist — {target?.equipmentCode}</DialogTitle>
            <DialogDescription>
              Informe o horímetro final para calcular as horas trabalhadas.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Horímetro inicial: <span className="font-medium text-foreground">{fmt(start)} h</span>
            </div>
            <div className="space-y-2">
              <Label htmlFor="hm-end">Horímetro final *</Label>
              <Input
                id="hm-end"
                type="number"
                step="0.1"
                value={endValue}
                onChange={(e) => setEndValue(e.target.value)}
                placeholder="Ex: 1258,7"
              />
            </div>
            {isFinite(endNum) && !isBelow && (
              <p className="text-sm">
                Horas trabalhadas:{' '}
                <span className="font-bold text-primary">{fmt(Math.max(0, worked))} h</span>
              </p>
            )}
            {isBelow && (
              <div className="space-y-2">
                <p className="text-sm text-destructive">
                  O horímetro final não pode ser menor que o horímetro inicial.
                </p>
                <Label htmlFor="hm-just">Justificativa (correção/troca de horímetro)</Label>
                <Textarea
                  id="hm-just"
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  placeholder="Descreva o motivo para análise posterior..."
                  className="min-h-[60px]"
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTarget(null)}>
              Cancelar
            </Button>
            <Button
              onClick={handleClose}
              disabled={
                saving || !isFinite(endNum) || (isBelow && !justification.trim())
              }
            >
              {saving ? 'Encerrando...' : 'Encerrar e registrar horas'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ActiveChecklistSessions;
