import { useMemo, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, FilterX } from 'lucide-react';
import {
  ServiceOrder,
  STATUS_CLASSES,
  STATUS_LABELS,
  MAINTENANCE_TYPE_LABELS,
  MaintenanceType,
  ServiceOrderStatus,
  formatDowntime,
  downtimeMinutes,
  isOpenStatus,
} from '@/types/serviceOrder';
import { useNow } from '@/hooks/useNow';

interface Props {
  orders: ServiceOrder[];
  onSelect: (os: ServiceOrder) => void;
}

const PAGE_SIZE = 25;

export const ServiceOrderHistory = ({ orders, onSelect }: Props) => {
  const now = useNow(60000);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState<'todos' | ServiceOrderStatus | 'abertas' | 'fechadas'>('todos');
  const [tipo, setTipo] = useState<'todos' | MaintenanceType>('todos');
  const [unidade, setUnidade] = useState('todas');
  const [equipamento, setEquipamento] = useState('todos');
  const [mecanico, setMecanico] = useState('todos');
  const [inicio, setInicio] = useState('');
  const [fim, setFim] = useState('');
  const [page, setPage] = useState(0);

  const units = useMemo(
    () => Array.from(new Set(orders.map((o) => o.unit).filter(Boolean) as string[])).sort(),
    [orders]
  );
  const equipmentCodes = useMemo(
    () => Array.from(new Set(orders.map((o) => o.equipment_code))).sort(),
    [orders]
  );
  const mechanics = useMemo(
    () => Array.from(new Set(orders.map((o) => o.mecanico_responsavel))).sort(),
    [orders]
  );

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    const startTs = inicio ? new Date(`${inicio}T00:00:00`).getTime() : null;
    const endTs = fim ? new Date(`${fim}T23:59:59`).getTime() : null;

    return orders.filter((o) => {
      const ts = new Date(o.data_hora_abertura).getTime();
      if (startTs && ts < startTs) return false;
      if (endTs && ts > endTs) return false;
      if (tipo !== 'todos' && o.tipo_manutencao !== tipo) return false;
      if (unidade !== 'todas' && o.unit !== unidade) return false;
      if (equipamento !== 'todos' && o.equipment_code !== equipamento) return false;
      if (mecanico !== 'todos' && o.mecanico_responsavel !== mecanico) return false;
      if (status === 'abertas' && !isOpenStatus(o.status)) return false;
      if (status === 'fechadas' && isOpenStatus(o.status)) return false;
      if (status !== 'todos' && status !== 'abertas' && status !== 'fechadas' && o.status !== status) return false;
      if (term) {
        const hay = `${o.numero_os} ${o.equipment_code} ${o.mecanico_responsavel} ${o.descricao_ocorrencia} ${o.servico_executado || ''} ${o.causa_identificada || ''}`.toLowerCase();
        if (!hay.includes(term)) return false;
      }
      return true;
    });
  }, [orders, search, status, tipo, unidade, equipamento, mecanico, inicio, fim]);

  const pageItems = filtered.slice(page * PAGE_SIZE, page * PAGE_SIZE + PAGE_SIZE);
  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));

  const clear = () => {
    setSearch('');
    setStatus('todos');
    setTipo('todos');
    setUnidade('todas');
    setEquipamento('todos');
    setMecanico('todos');
    setInicio('');
    setFim('');
    setPage(0);
  };

  return (
    <div className="space-y-3">
      <Card>
        <CardContent className="p-3 sm:p-4 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              className="pl-9 h-11"
              placeholder="Buscar por Nº OS, equipamento, mecânico ou descrição"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(0);
              }}
            />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Status</Label>
              <Select value={status} onValueChange={(v) => { setStatus(v as any); setPage(0); }}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  <SelectItem value="abertas">Somente abertas</SelectItem>
                  <SelectItem value="fechadas">Somente fechadas</SelectItem>
                  <SelectItem value="aberta">Aberta</SelectItem>
                  <SelectItem value="em_manutencao">Em manutenção</SelectItem>
                  <SelectItem value="finalizada">Finalizada</SelectItem>
                  <SelectItem value="cancelada">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Tipo</Label>
              <Select value={tipo} onValueChange={(v) => { setTipo(v as any); setPage(0); }}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  {(Object.keys(MAINTENANCE_TYPE_LABELS) as MaintenanceType[]).map((t) => (
                    <SelectItem key={t} value={t}>{MAINTENANCE_TYPE_LABELS[t]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Unidade</Label>
              <Select value={unidade} onValueChange={(v) => { setUnidade(v); setPage(0); }}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas</SelectItem>
                  {units.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Equipamento</Label>
              <Select value={equipamento} onValueChange={(v) => { setEquipamento(v); setPage(0); }}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="todos">Todos</SelectItem>
                  {equipmentCodes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Mecânico</Label>
              <Select value={mecanico} onValueChange={(v) => { setMecanico(v); setPage(0); }}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="todos">Todos</SelectItem>
                  {mechanics.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">De</Label>
              <Input type="date" className="h-10" value={inicio} onChange={(e) => { setInicio(e.target.value); setPage(0); }} />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Até</Label>
              <Input type="date" className="h-10" value={fim} onChange={(e) => { setFim(e.target.value); setPage(0); }} />
            </div>

            <div className="flex items-end">
              <Button variant="outline" className="h-10 w-full" onClick={clear}>
                <FilterX className="w-4 h-4 mr-2" />
                Limpar
              </Button>
            </div>
          </div>

          <p className="text-xs text-muted-foreground">{filtered.length} ordem(ns) de serviço encontrada(s)</p>
        </CardContent>
      </Card>

      {/* Lista mobile */}
      <div className="space-y-2 lg:hidden">
        {pageItems.map((os) => (
          <Card key={os.id} className="cursor-pointer active:scale-[0.99] transition" onClick={() => onSelect(os)}>
            <CardContent className="p-3 space-y-1.5">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-sm">{os.numero_os}</span>
                <Badge className={STATUS_CLASSES[os.status]}>{STATUS_LABELS[os.status]}</Badge>
              </div>
              <p className="text-sm font-medium">{os.equipment_code} · {MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]}</p>
              <p className="text-xs text-muted-foreground line-clamp-2">{os.descricao_ocorrencia}</p>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{os.mecanico_responsavel}</span>
                <span className={isOpenStatus(os.status) ? 'text-safety-red font-semibold' : ''}>
                  {formatDowntime(isOpenStatus(os.status) ? downtimeMinutes(os, now) : os.tempo_indisponibilidade_minutos)}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabela desktop */}
      <Card className="hidden lg:block">
        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/60">
              <tr className="text-left">
                <th className="p-3 font-medium">Nº OS</th>
                <th className="p-3 font-medium">Equipamento</th>
                <th className="p-3 font-medium">Tipo</th>
                <th className="p-3 font-medium">Status</th>
                <th className="p-3 font-medium">Mecânico</th>
                <th className="p-3 font-medium">Abertura</th>
                <th className="p-3 font-medium">Fechamento</th>
                <th className="p-3 font-medium">Indisponibilidade</th>
              </tr>
            </thead>
            <tbody>
              {pageItems.map((os) => (
                <tr key={os.id} className="border-t hover:bg-muted/40 cursor-pointer" onClick={() => onSelect(os)}>
                  <td className="p-3 font-medium">{os.numero_os}</td>
                  <td className="p-3">{os.equipment_code}</td>
                  <td className="p-3">{MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]}</td>
                  <td className="p-3"><Badge className={STATUS_CLASSES[os.status]}>{STATUS_LABELS[os.status]}</Badge></td>
                  <td className="p-3">{os.mecanico_responsavel}</td>
                  <td className="p-3">{new Date(os.data_hora_abertura).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="p-3">{os.data_hora_fechamento ? new Date(os.data_hora_fechamento).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '-'}</td>
                  <td className={`p-3 ${isOpenStatus(os.status) ? 'text-safety-red font-semibold' : ''}`}>
                    {formatDowntime(isOpenStatus(os.status) ? downtimeMinutes(os, now) : os.tempo_indisponibilidade_minutos)}
                  </td>
                </tr>
              ))}
              {pageItems.length === 0 && (
                <tr><td colSpan={8} className="p-8 text-center text-muted-foreground">Nenhuma OS encontrada</td></tr>
              )}
            </tbody>
          </table>
        </CardContent>
      </Card>

      {filtered.length > PAGE_SIZE && (
        <div className="flex items-center justify-between">
          <Button variant="outline" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Anterior</Button>
          <span className="text-xs text-muted-foreground">Página {page + 1} de {totalPages}</span>
          <Button variant="outline" disabled={page + 1 >= totalPages} onClick={() => setPage((p) => p + 1)}>Próxima</Button>
        </div>
      )}
    </div>
  );
};
