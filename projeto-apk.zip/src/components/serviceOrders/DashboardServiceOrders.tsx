import { useServiceOrders } from '@/hooks/useServiceOrders';
import { useEquipment } from '@/hooks/useEquipment';
import { ServiceOrderIndicators } from '@/components/serviceOrders/ServiceOrderIndicators';

/**
 * Seção de indicadores de Ordens de Serviço embutida no dashboard existente.
 * Renderizada apenas para mecânicos, gestores e admins.
 */
export const DashboardServiceOrders = () => {
  const { serviceOrders } = useServiceOrders();
  const { equipments } = useEquipment();

  return <ServiceOrderIndicators orders={serviceOrders} totalEquipments={equipments.length} />;
};
