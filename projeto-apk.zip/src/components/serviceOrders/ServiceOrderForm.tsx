import { useMemo, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Search, Wrench } from 'lucide-react';
import { Equipment } from '@/types/equipment';
import { MAINTENANCE_TYPE_LABELS, MaintenanceType, ServiceOrder } from '@/types/serviceOrder';
import { CreateServiceOrderInput } from '@/hooks/useServiceOrders';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  equipments: Equipment[];
  mechanicName: string;
  findOpenByEquipment: (equipmentId: string) => ServiceOrder | null;
  onCreate: (input: CreateServiceOrderInput) => Promise<ServiceOrder | null>;
  onViewExisting?: (os: ServiceOrder) => void;
}

export const ServiceOrderForm = ({
  open,
  onOpenChange,
  equipments,
  mechanicName,
  findOpenByEquipment,
  onCreate,
  onViewExisting,
}: Props) => {
  const [search, setSearch] = useState('');
  const [equipmentId, setEquipmentId] = useState('');
  const [oficina, setOficina] = useState('');
  const [tipo, setTipo] = useState<MaintenanceType | ''>('');
  const [descricao, setDescricao] = useState('');
  const [saving, setSaving] = useState(false);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    const list = term
      ? equipments.filter((e) =>
          [e.code, e.model, e.brand, e.equipmentNumber, e.unit, e.location]
            .filter(Boolean)
            .some((v) => String(v).toLowerCase().includes(term))
        )
      : equipments;
    return list.slice(0, 100);
  }, [equipments, search]);

  const selected = equipments.find((e) => e.id === equipmentId) || null;




  const existingOs = equipmentId ? findOpenByEquipment(equipmentId) : null;

  const reset = () => {
    setSearch('');
    setEquipmentId('');
    setOficina('');
    setTipo('');
    setDescricao('');
  };

  const handleSubmit = async () => {
    if (!selected || !tipo || !descricao.trim() || !oficina.trim()) return;
    setSaving(true);
    const created = await onCreate({
      equipment_id: selected.id,
      equipment_code: selected.code,
      equipment_model: `${selected.brand || ''} ${selected.model || ''}`.trim() || null,
      unit: selected.unit || null,
      location: selected.location || null,
      oficina: oficina.trim(),
      tipo_manutencao: tipo,
      descricao_ocorrencia: descricao,
    });
    setSaving(false);
    if (created) {
      reset();
      onOpenChange(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        if (!v) reset();
        onOpenChange(v);
      }}
    >
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-safety-orange" />
            Abrir Ordem de Serviço
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="text-xs text-muted-foreground bg-muted rounded-lg p-2">
            Mecânico responsável: <span className="font-semibold text-foreground">{mechanicName}</span> · Abertura
            registrada automaticamente
          </div>

          <div className="space-y-2">
            <Label>Equipamento *</Label>
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar por código, modelo, unidade..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 h-11"
              />
            </div>
            <Select value={equipmentId} onValueChange={setEquipmentId}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Selecione o equipamento" />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {filtered.map((e) => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.code} — {e.brand} {e.model}
                    {e.unit ? ` · ${e.unit}` : ''}
                  </SelectItem>
                ))}
                {filtered.length === 0 && (
                  <div className="p-3 text-sm text-muted-foreground">Nenhum equipamento encontrado</div>
                )}
              </SelectContent>
            </Select>
          </div>

          {selected && (
            <div className="rounded-lg border p-3 text-xs space-y-1 bg-muted/40">
              <div className="flex flex-wrap gap-x-4 gap-y-1">
                <span><span className="text-muted-foreground">Código:</span> <b>{selected.code}</b></span>
                <span><span className="text-muted-foreground">Modelo:</span> {selected.brand} {selected.model}</span>
                {selected.equipmentNumber && (
                  <span><span className="text-muted-foreground">Nº/Série:</span> {selected.equipmentNumber}</span>
                )}
                {selected.unit && <span><span className="text-muted-foreground">Unidade:</span> {selected.unit}</span>}
                {selected.location && <span><span className="text-muted-foreground">Local:</span> {selected.location}</span>}
              </div>
            </div>
          )}

          {existingOs && (
            <div className="rounded-lg border border-safety-red bg-safety-red-light p-3 space-y-2">
              <div className="flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-safety-red mt-0.5 flex-shrink-0" />
                <p className="text-sm font-medium text-safety-red">
                  Este equipamento já possui uma Ordem de Serviço em aberto.
                </p>
              </div>
              <div className="flex items-center justify-between gap-2">
                <Badge variant="outline">{existingOs.numero_os}</Badge>
                {onViewExisting && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      onOpenChange(false);
                      onViewExisting(existingOs);
                    }}
                  >
                    Ver detalhes
                  </Button>
                )}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Tipo de Manutenção *</Label>
            <Select value={tipo} onValueChange={(v) => setTipo(v as MaintenanceType)}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Selecione o tipo" />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(MAINTENANCE_TYPE_LABELS) as MaintenanceType[]).map((t) => (
                  <SelectItem key={t} value={t}>
                    {MAINTENANCE_TYPE_LABELS[t]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Oficina *</Label>
            <Select value={oficina} onValueChange={setOficina}>
              <SelectTrigger className="h-11">
                <SelectValue placeholder="Selecione a oficina" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Oficina 01">Oficina 01</SelectItem>
                <SelectItem value="Oficina 02">Oficina 02</SelectItem>
              </SelectContent>
            </Select>
          </div>


          <div className="space-y-2">
            <Label>Descrição da ocorrência / serviço *</Label>
            <Textarea
              rows={4}
              placeholder="Ex.: Equipamento apresentou vazamento de óleo hidráulico durante a operação."
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="outline" className="h-11 flex-1" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button
            className="h-11 flex-1 bg-safety-orange hover:bg-safety-orange/90 text-white"
            disabled={!selected || !tipo || !descricao.trim() || !oficina.trim() || !!existingOs || saving}
            onClick={handleSubmit}
          >
            {saving ? 'Abrindo...' : 'Abrir OS'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
