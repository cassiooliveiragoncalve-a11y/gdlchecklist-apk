import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
  LineChart, Line,
} from 'recharts';
import { Activity, CheckCircle2, Gauge, Timer, TrendingUp, Wrench } from 'lucide-react';
import {
  ServiceOrder,
  MAINTENANCE_TYPE_LABELS,
  MaintenanceType,
  formatDowntime,
  downtimeMinutes,
  isOpenStatus,
} from '@/types/serviceOrder';
import { useNow } from '@/hooks/useNow';

interface Props {
  orders: ServiceOrder[];
  totalEquipments: number;
  compact?: boolean;
}

const PERIODS = [
  { value: '7', label: 'Últimos 7 dias' },
  { value: '30', label: 'Últimos 30 dias' },
  { value: '90', label: 'Últimos 90 dias' },
  { value: '180', label: 'Últimos 6 meses' },
  { value: '365', label: 'Últimos 12 meses' },
  { value: 'all', label: 'Todo o período' },
];

const TYPE_COLORS: Record<MaintenanceType, string> = {
  avaria: '#dc2626',
  corretiva: '#f97316',
  pneus: '#2563eb',
  preventiva: '#16a34a',
};

export const ServiceOrderIndicators = ({ orders, totalEquipments, compact = false }: Props) => {
  const now = useNow(60000);
  const [period, setPeriod] = useState('30');
  const [unidade, setUnidade] = useState('todas');
  const [equipamento, setEquipamento] = useState('todos');
  const [tipo, setTipo] = useState<'todos' | MaintenanceType>('todos');
  const [mecanico, setMecanico] = useState('todos');

  const units = useMemo(() => Array.from(new Set(orders.map((o) => o.unit).filter(Boolean) as string[])).sort(), [orders]);
  const codes = useMemo(() => Array.from(new Set(orders.map((o) => o.equipment_code))).sort(), [orders]);
  const mechanics = useMemo(() => Array.from(new Set(orders.map((o) => o.mecanico_responsavel))).sort(), [orders]);

  const periodStart = useMemo(() => {
    if (period === 'all') return null;
    const days = Number(period);
    return now - days * 24 * 60 * 60 * 1000;
  }, [period, now]);

  const filtered = useMemo(
    () =>
      orders.filter((o) => {
        const ts = new Date(o.data_hora_abertura).getTime();
        if (periodStart && ts < periodStart) return false;
        if (unidade !== 'todas' && o.unit !== unidade) return false;
        if (equipamento !== 'todos' && o.equipment_code !== equipamento) return false;
        if (tipo !== 'todos' && o.tipo_manutencao !== tipo) return false;
        if (mecanico !== 'todos' && o.mecanico_responsavel !== mecanico) return false;
        return true;
      }),
    [orders, periodStart, unidade, equipamento, tipo, mecanico]
  );

  const metrics = useMemo(() => {
    const abertas = filtered.filter((o) => isOpenStatus(o.status));
    const finalizadas = filtered.filter((o) => o.status === 'finalizada');
    const indisponiveis = new Set(abertas.map((o) => o.equipment_id)).size;

    const totalMin =
      finalizadas.reduce((s, o) => s + (o.tempo_indisponibilidade_minutos || 0), 0) +
      abertas.reduce((s, o) => s + downtimeMinutes(o, now), 0);

    const finalizadasMin = finalizadas.reduce((s, o) => s + (o.tempo_indisponibilidade_minutos || 0), 0);
    const mttr = finalizadas.length > 0 ? finalizadasMin / finalizadas.length : 0;

    // Disponibilidade da frota no período
    const days = period === 'all' ? 30 : Number(period);
    const fleet = Math.max(1, totalEquipments);
    const capacityMin = fleet * days * 24 * 60;
    const disponibilidade = capacityMin > 0 ? Math.max(0, 100 - (totalMin / capacityMin) * 100) : 100;

    return {
      abertas: abertas.length,
      finalizadas: finalizadas.length,
      indisponiveis,
      totalMin,
      mediaMin: filtered.length > 0 ? totalMin / filtered.length : 0,
      mttr,
      disponibilidade,
    };
  }, [filtered, now, period, totalEquipments]);

  const byType = useMemo(
    () =>
      (Object.keys(MAINTENANCE_TYPE_LABELS) as MaintenanceType[]).map((t) => ({
        name: MAINTENANCE_TYPE_LABELS[t],
        key: t,
        value: filtered.filter((o) => o.tipo_manutencao === t).length,
      })),
    [filtered]
  );

  const byEquipment = useMemo(() => {
    const map = new Map<string, number>();
    filtered.forEach((o) => map.set(o.equipment_code, (map.get(o.equipment_code) || 0) + 1));
    return Array.from(map.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [filtered]);

  const byMechanic = useMemo(() => {
    const map = new Map<string, { abertas: number; finalizadas: number }>();
    filtered.forEach((o) => {
      const cur = map.get(o.mecanico_responsavel) || { abertas: 0, finalizadas: 0 };
      if (o.status === 'finalizada') cur.finalizadas += 1;
      else if (isOpenStatus(o.status)) cur.abertas += 1;
      map.set(o.mecanico_responsavel, cur);
    });
    return Array.from(map.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.abertas + b.finalizadas - (a.abertas + a.finalizadas))
      .slice(0, 8);
  }, [filtered]);

  const failuresByEquipment = useMemo(() => {
    const map = new Map<string, number>();
    filtered.filter((o) => o.tipo_manutencao === 'avaria').forEach((o) => {
      map.set(o.equipment_code, (map.get(o.equipment_code) || 0) + 1);
    });
    return Array.from(map.entries())
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  }, [filtered]);

  const evolution = useMemo(() => {
    const map = new Map<string, number>();
    filtered.forEach((o) => {
      const d = new Date(o.data_hora_abertura);
      const key = `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`;
      map.set(key, (map.get(key) || 0) + 1);
    });
    return Array.from(map.entries())
      .map(([name, value]) => ({ name, value }))
      .slice(-30);
  }, [filtered]);

  const kpis = [
    { title: 'OS Abertas', value: String(metrics.abertas), icon: Wrench, color: 'text-safety-red' },
    { title: 'Equip. Indisponíveis', value: String(metrics.indisponiveis), icon: Timer, color: 'text-safety-orange' },
    { title: 'OS Finalizadas', value: String(metrics.finalizadas), icon: CheckCircle2, color: 'text-safety-green' },
    { title: 'Tempo Total Indisp.', value: formatDowntime(metrics.totalMin), icon: Activity, color: 'text-industrial-blue' },
    { title: 'Tempo Médio Indisp.', value: formatDowntime(metrics.mediaMin), icon: TrendingUp, color: 'text-industrial-blue' },
    { title: 'MTTR', value: formatDowntime(metrics.mttr), icon: Gauge, color: 'text-safety-orange' },
    { title: 'Disponibilidade da Frota', value: `${metrics.disponibilidade.toFixed(1)}%`, icon: Gauge, color: 'text-safety-green' },
  ];

  return (
    <div className="space-y-3">
      <Card>
        <CardHeader className="p-4 pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Wrench className="w-5 h-5 text-safety-orange" />
            Indicadores de Manutenção (OS)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-3 sm:p-4 pt-0 space-y-3">
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
            <div className="space-y-1">
              <Label className="text-xs">Período</Label>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Unidade</Label>
              <Select value={unidade} onValueChange={setUnidade}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todas">Todas</SelectItem>
                  {units.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Equipamento</Label>
              <Select value={equipamento} onValueChange={setEquipamento}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="todos">Todos</SelectItem>
                  {codes.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Tipo</Label>
              <Select value={tipo} onValueChange={(v) => setTipo(v as any)}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos</SelectItem>
                  {(Object.keys(MAINTENANCE_TYPE_LABELS) as MaintenanceType[]).map((t) => (
                    <SelectItem key={t} value={t}>{MAINTENANCE_TYPE_LABELS[t]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Mecânico</Label>
              <Select value={mecanico} onValueChange={setMecanico}>
                <SelectTrigger className="h-10"><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="todos">Todos</SelectItem>
                  {mechanics.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
            {kpis.map((k) => {
              const Icon = k.icon;
              return (
                <div key={k.title} className="border rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Icon className={`w-4 h-4 ${k.color}`} />
                    <p className="text-xs text-muted-foreground line-clamp-2">{k.title}</p>
                  </div>
                  <p className="text-lg font-bold text-foreground">{k.value}</p>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {!compact && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <Card>
            <CardHeader className="p-4 pb-0"><CardTitle className="text-sm">OS por Tipo</CardTitle></CardHeader>
            <CardContent className="p-2 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={byType} dataKey="value" nameKey="name" outerRadius={80} label>
                    {byType.map((d) => <Cell key={d.key} fill={TYPE_COLORS[d.key]} />)}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-4 pb-0"><CardTitle className="text-sm">OS por Equipamento (Top 8)</CardTitle></CardHeader>
            <CardContent className="p-2 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={byEquipment}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Bar dataKey="value" name="OS" fill="#f97316" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-4 pb-0"><CardTitle className="text-sm">OS por Mecânico</CardTitle></CardHeader>
            <CardContent className="p-2 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={byMechanic}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="abertas" name="Abertas" fill="#dc2626" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="finalizadas" name="Finalizadas" fill="#16a34a" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-4 pb-0"><CardTitle className="text-sm">Evolução das Manutenções</CardTitle></CardHeader>
            <CardContent className="p-2 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={evolution}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 10 }} />
                  <Tooltip />
                  <Line type="monotone" dataKey="value" name="OS" stroke="#2563eb" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="lg:col-span-2">
            <CardHeader className="p-4 pb-2"><CardTitle className="text-sm">Frequência de Avarias por Equipamento</CardTitle></CardHeader>
            <CardContent className="p-4 pt-0 space-y-2">
              {failuresByEquipment.length === 0 && (
                <p className="text-sm text-muted-foreground py-4 text-center">Nenhuma avaria registrada no período</p>
              )}
              {failuresByEquipment.map((f, i) => (
                <div key={f.name} className="flex items-center justify-between p-2.5 bg-muted/50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-safety-red-light text-safety-red text-xs font-bold flex items-center justify-center">
                      {i + 1}
                    </span>
                    <span className="text-sm font-medium">{f.name}</span>
                  </div>
                  <span className="text-sm font-bold text-safety-red">{f.value}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};
