import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { CheckCircle2, FileDown, PlayCircle, Printer, Timer, Trash2, XCircle } from 'lucide-react';
import { printServiceOrder, downloadServiceOrderPdf } from '@/lib/serviceOrderPdf';
import {
  ServiceOrder,
  STATUS_CLASSES,
  STATUS_LABELS,
  MAINTENANCE_TYPE_LABELS,
  formatDowntime,
  downtimeMinutes,
  isOpenStatus,
} from '@/types/serviceOrder';
import { useNow } from '@/hooks/useNow';

interface Props {
  os: ServiceOrder | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  canManage: boolean;
  canCancel: boolean;
  canReopen: boolean;
  canDelete?: boolean;
  onStart: (id: string) => Promise<boolean>;
  onFinalize: (
    id: string,
    input: { servico_executado: string; causa_identificada: string; pecas_materiais?: string; observacoes?: string }
  ) => Promise<boolean>;
  onCancel: (id: string, motivo: string) => Promise<boolean>;
  onReopen: (id: string) => Promise<boolean>;
  onDelete?: (id: string) => Promise<boolean>;
}


const fmt = (v?: string | null) =>
  v ? new Date(v).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-';

export const ServiceOrderDetails = ({
  os,
  open,
  onOpenChange,
  canManage,
  canCancel,
  canReopen,
  canDelete,
  onStart,
  onFinalize,
  onCancel,
  onReopen,
  onDelete,
}: Props) => {
  const now = useNow(30000);
  const [mode, setMode] = useState<'view' | 'finalize' | 'cancel'>('view');
  const [servico, setServico] = useState('');
  const [causa, setCausa] = useState('');
  const [pecas, setPecas] = useState('');
  const [obs, setObs] = useState('');
  const [motivo, setMotivo] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);


  if (!os) return null;

  const openNow = isOpenStatus(os.status);
  const minutes = openNow ? downtimeMinutes(os, now) : os.tempo_indisponibilidade_minutos;

  const close = () => {
    setMode('view');
    setServico('');
    setCausa('');
    setPecas('');
    setObs('');
    setMotivo('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? onOpenChange(v) : close())}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2 text-base">
            {os.numero_os}
            <Badge className={STATUS_CLASSES[os.status]}>{STATUS_LABELS[os.status]}</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className={`rounded-lg p-3 text-center ${openNow ? 'bg-safety-red-light' : 'bg-muted'}`}>
            <p className="text-xs font-medium text-muted-foreground flex items-center justify-center gap-1">
              <Timer className="w-3.5 h-3.5" />
              {openNow ? 'INDISPONÍVEL HÁ' : 'TEMPO TOTAL DE INDISPONIBILIDADE'}
            </p>
            <p className={`text-2xl font-bold ${openNow ? 'text-safety-red' : 'text-foreground'}`}>
              {formatDowntime(minutes)}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <div><p className="text-xs text-muted-foreground">Equipamento</p><p className="font-medium">{os.equipment_code}</p></div>
            <div><p className="text-xs text-muted-foreground">Modelo</p><p className="font-medium">{os.equipment_model || '-'}</p></div>
            <div><p className="text-xs text-muted-foreground">Tipo</p><p className="font-medium">{MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]}</p></div>
            <div><p className="text-xs text-muted-foreground">Mecânico</p><p className="font-medium">{os.mecanico_responsavel}</p></div>
            <div><p className="text-xs text-muted-foreground">Unidade</p><p className="font-medium">{os.unit || '-'}</p></div>
            <div><p className="text-xs text-muted-foreground">Local</p><p className="font-medium">{os.location || '-'}</p></div>
            <div><p className="text-xs text-muted-foreground">Oficina</p><p className="font-medium">{os.oficina || '-'}</p></div>
            <div><p className="text-xs text-muted-foreground">Abertura</p><p className="font-medium">{fmt(os.data_hora_abertura)}</p></div>
            <div><p className="text-xs text-muted-foreground">Fechamento</p><p className="font-medium">{fmt(os.data_hora_fechamento)}</p></div>
          </div>

          <Separator />

          <div className="space-y-2 text-sm">
            <div>
              <p className="text-xs text-muted-foreground">Descrição da ocorrência</p>
              <p className="whitespace-pre-wrap">{os.descricao_ocorrencia}</p>
            </div>
            {os.causa_identificada && (
              <div>
                <p className="text-xs text-muted-foreground">Causa identificada</p>
                <p className="whitespace-pre-wrap">{os.causa_identificada}</p>
              </div>
            )}
            {os.servico_executado && (
              <div>
                <p className="text-xs text-muted-foreground">Serviço executado</p>
                <p className="whitespace-pre-wrap">{os.servico_executado}</p>
              </div>
            )}
            {os.pecas_materiais && (
              <div>
                <p className="text-xs text-muted-foreground">Peças / materiais</p>
                <p className="whitespace-pre-wrap">{os.pecas_materiais}</p>
              </div>
            )}
            {os.observacoes && (
              <div>
                <p className="text-xs text-muted-foreground">Observações</p>
                <p className="whitespace-pre-wrap">{os.observacoes}</p>
              </div>
            )}
            {os.motivo_cancelamento && (
              <div>
                <p className="text-xs text-muted-foreground">Motivo do cancelamento</p>
                <p className="whitespace-pre-wrap">{os.motivo_cancelamento}</p>
              </div>
            )}
          </div>

          {mode === 'finalize' && (
            <div className="space-y-3 border-t pt-3">
              <div className="space-y-1">
                <Label>Serviço executado *</Label>
                <Textarea rows={3} value={servico} onChange={(e) => setServico(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Causa identificada *</Label>
                <Textarea rows={2} value={causa} onChange={(e) => setCausa(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Peças / materiais utilizados</Label>
                <Textarea rows={2} value={pecas} onChange={(e) => setPecas(e.target.value)} />
              </div>
              <div className="space-y-1">
                <Label>Observações</Label>
                <Textarea rows={2} value={obs} onChange={(e) => setObs(e.target.value)} />
              </div>
            </div>
          )}

          {mode === 'cancel' && (
            <div className="space-y-1 border-t pt-3">
              <Label>Motivo do cancelamento *</Label>
              <Textarea rows={3} value={motivo} onChange={(e) => setMotivo(e.target.value)} />
            </div>
          )}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          {mode === 'view' && (
            <>
              <Button variant="outline" className="h-11 w-full sm:w-auto" onClick={() => printServiceOrder(os)}>
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
              <Button variant="outline" className="h-11 w-full sm:w-auto" onClick={() => downloadServiceOrderPdf(os)}>
                <FileDown className="w-4 h-4 mr-2" />
                PDF
              </Button>
              {canManage && os.status === 'aberta' && (
                <Button variant="outline" className="h-11 w-full sm:w-auto" onClick={() => onStart(os.id)}>
                  <PlayCircle className="w-4 h-4 mr-2" />
                  Iniciar manutenção
                </Button>
              )}
              {canManage && openNow && (
                <Button
                  className="h-11 w-full sm:flex-1 bg-safety-green hover:bg-safety-green/90 text-white"
                  onClick={() => setMode('finalize')}
                >
                  <CheckCircle2 className="w-4 h-4 mr-2" />
                  Finalizar OS
                </Button>
              )}
              {canCancel && openNow && (
                <Button
                  variant="outline"
                  className="h-11 w-full sm:w-auto text-safety-red border-safety-red"
                  onClick={() => setMode('cancel')}
                >
                  <XCircle className="w-4 h-4 mr-2" />
                  Cancelar OS
                </Button>
              )}
              {canReopen && !openNow && (
                <Button variant="outline" className="h-11 w-full sm:w-auto" onClick={() => onReopen(os.id)}>
                  Reabrir OS (admin)
                </Button>
              )}
              {canDelete && onDelete && (
                <Button
                  variant="destructive"
                  className="h-11 w-full sm:w-auto"
                  disabled={saving}
                  onClick={() => setConfirmDelete(true)}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Excluir OS
                </Button>
              )}
            </>
          )}

          {mode === 'finalize' && (
            <>
              <Button variant="outline" className="h-11 flex-1" onClick={() => setMode('view')}>
                Voltar
              </Button>
              <Button
                className="h-11 flex-1 bg-safety-green hover:bg-safety-green/90 text-white"
                disabled={!servico.trim() || !causa.trim() || saving}
                onClick={async () => {
                  setSaving(true);
                  const ok = await onFinalize(os.id, {
                    servico_executado: servico,
                    causa_identificada: causa,
                    pecas_materiais: pecas,
                    observacoes: obs,
                  });
                  setSaving(false);
                  if (ok) close();
                }}
              >
                Confirmar finalização
              </Button>
            </>
          )}

          {mode === 'cancel' && (
            <>
              <Button variant="outline" className="h-11 flex-1" onClick={() => setMode('view')}>
                Voltar
              </Button>
              <Button
                variant="destructive"
                className="h-11 flex-1"
                disabled={!motivo.trim() || saving}
                onClick={async () => {
                  setSaving(true);
                  const ok = await onCancel(os.id, motivo);
                  setSaving(false);
                  if (ok) close();
                }}
              >
                Confirmar cancelamento
              </Button>
            </>
          )}
        </DialogFooter>

        <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Excluir {os.numero_os}?</AlertDialogTitle>
              <AlertDialogDescription>
                Esta ação é permanente e removerá a Ordem de Serviço do histórico e dos indicadores.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Voltar</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={async () => {
                  if (!onDelete) return;
                  setSaving(true);
                  const ok = await onDelete(os.id);
                  setSaving(false);
                  setConfirmDelete(false);
                  if (ok) close();
                }}
              >
                Excluir definitivamente
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
};
