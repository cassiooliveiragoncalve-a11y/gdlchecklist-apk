import { useMemo, useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { FileDown, FileSpreadsheet, FileText, Loader2 } from 'lucide-react';
import { exportTablePdf, exportExcel, ExcelSheet } from '@/lib/exportUtils';
import { useToast } from '@/hooks/use-toast';

export type ReportFilterDef =
  | {
      key: string;
      label: string;
      type: 'select';
      options: { value: string; label: string }[];
      defaultValue?: string;
    }
  | { key: string; label: string; type: 'date'; defaultValue?: string }
  | { key: string; label: string; type: 'text'; placeholder?: string; defaultValue?: string }
  | { key: string; label: string; type: 'number'; placeholder?: string; defaultValue?: string };

export type ReportFilterValues = Record<string, string>;

export interface ReportData {
  /** Cabeçalho da tabela do PDF */
  head: string[];
  /** Linhas do PDF */
  body: (string | number | null)[][];
  /** Abas do Excel */
  sheets: ExcelSheet[];
  /** Linha de contexto impressa no cabeçalho do PDF */
  subtitle?: string;
  /** Índice (0-based) da coluna renderizada como barra de vida no PDF */
  progressColumn?: number;
}

interface Props {
  title: string;
  description?: string;
  fileName: string;
  filters: ReportFilterDef[];
  buildData: (values: ReportFilterValues) => ReportData | Promise<ReportData>;
  orientation?: 'portrait' | 'landscape';
  buttonLabel?: string;
  buttonSize?: 'default' | 'sm' | 'lg';
  buttonClassName?: string;
}

const initialValues = (filters: ReportFilterDef[]): ReportFilterValues => {
  const v: ReportFilterValues = {};
  filters.forEach((f) => {
    v[f.key] = f.defaultValue ?? (f.type === 'select' ? f.options[0]?.value ?? '' : '');
  });
  return v;
};

export const ReportExportDialog = ({
  title,
  description,
  fileName,
  filters,
  buildData,
  orientation = 'landscape',
  buttonLabel = 'Gerar Relatório',
  buttonSize = 'default',
  buttonClassName,
}: Props) => {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [values, setValues] = useState<ReportFilterValues>(() => initialValues(filters));
  const [busy, setBusy] = useState<'pdf' | 'excel' | null>(null);

  const defaults = useMemo(() => initialValues(filters), [filters]);

  const setValue = (key: string, value: string) =>
    setValues((prev) => ({ ...prev, [key]: value }));

  const run = async (kind: 'pdf' | 'excel') => {
    setBusy(kind);
    try {
      const data = await buildData(values);
      const rowCount = kind === 'pdf'
        ? data.body.length
        : data.sheets.reduce((s, sh) => s + sh.rows.length, 0);

      if (rowCount === 0) {
        toast({
          title: 'Nenhum dado encontrado',
          description: 'Ajuste os filtros e tente novamente.',
          variant: 'destructive',
        });
        return;
      }

      if (kind === 'pdf') {
        await exportTablePdf({
          title,
          subtitle: data.subtitle,
          head: data.head,
          body: data.body,
          fileName,
          orientation,
          progressColumn: data.progressColumn,
        });
      } else {
        exportExcel(fileName, data.sheets);
      }

      toast({
        title: kind === 'pdf' ? 'PDF gerado' : 'Excel gerado',
        description: `${rowCount} registro(s) exportado(s).`,
      });
      setOpen(false);
    } catch (e: any) {
      toast({
        title: 'Erro ao gerar relatório',
        description: e?.message || 'Tente novamente.',
        variant: 'destructive',
      });
    } finally {
      setBusy(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size={buttonSize} className={buttonClassName}>
          <FileText className="w-4 h-4 mr-2" />
          {buttonLabel}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            {description || 'Selecione os filtros antes de exportar o relatório.'}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[55vh] overflow-y-auto pr-1">
          {filters.map((f) => (
            <div key={f.key} className="space-y-1">
              <Label className="text-xs">{f.label}</Label>
              {f.type === 'select' ? (
                <Select value={values[f.key]} onValueChange={(v) => setValue(f.key, v)}>
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {f.options.map((o) => (
                      <SelectItem key={o.value} value={o.value}>
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  className="h-10"
                  type={f.type === 'date' ? 'date' : f.type === 'number' ? 'number' : 'text'}
                  placeholder={'placeholder' in f ? f.placeholder : undefined}
                  value={values[f.key] ?? ''}
                  onChange={(e) => setValue(f.key, e.target.value)}
                />
              )}
            </div>
          ))}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button
            variant="ghost"
            className="sm:mr-auto"
            onClick={() => setValues(defaults)}
            disabled={!!busy}
          >
            Limpar filtros
          </Button>
          <Button variant="outline" onClick={() => run('pdf')} disabled={!!busy}>
            {busy === 'pdf' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <FileDown className="w-4 h-4 mr-2" />
            )}
            Exportar PDF
          </Button>
          <Button onClick={() => run('excel')} disabled={!!busy}>
            {busy === 'excel' ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <FileSpreadsheet className="w-4 h-4 mr-2" />
            )}
            Exportar Excel
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ReportExportDialog;
