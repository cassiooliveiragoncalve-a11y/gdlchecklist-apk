import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Gauge, TrendingUp, Calendar, Activity, Search, Trophy, Clock } from 'lucide-react';
import { useChecklists } from '@/hooks/useChecklists';
import { ReportExportDialog, ReportFilterDef } from '@/components/reports/ReportExportDialog';
import { ChecklistRecord } from '@/types/equipment';
import { ActiveChecklistSessions } from '@/components/ActiveChecklistSessions';


interface Reading {
  date: Date;
  hourMeter: number;
  operatorName: string;
  recordId: string;
}

interface EquipmentStats {
  equipmentId: string | null;
  equipmentCode: string;
  equipmentModel: string;
  location: string;
  readings: Reading[];
  firstReading?: Reading;
  lastReading?: Reading;
  totalHours: number;
  totalDays: number;
  dailyAvg: number;
  weeklyAvg: number;
  monthlyAvg: number;
}

type PeriodKey = '7d' | '30d' | '90d' | '180d' | '365d' | 'all' | 'custom';

const PERIOD_OPTIONS: { value: PeriodKey; label: string; days?: number }[] = [
  { value: '7d', label: 'Últimos 7 dias', days: 7 },
  { value: '30d', label: 'Últimos 30 dias', days: 30 },
  { value: '90d', label: 'Últimos 90 dias', days: 90 },
  { value: '180d', label: 'Últimos 6 meses', days: 180 },
  { value: '365d', label: 'Último ano', days: 365 },
  { value: 'all', label: 'Todo o histórico' },
  { value: 'custom', label: 'Período personalizado' },
];

const formatNumber = (n: number, digits = 2) =>
  isFinite(n) && !isNaN(n)
    ? n.toLocaleString('pt-BR', { minimumFractionDigits: digits, maximumFractionDigits: digits })
    : '—';

const MAX_HOURS_PER_DAY = 24; // física: máquina não roda mais que isso por dia

const buildStats = (
  records: ChecklistRecord[],
  fromTs: number | null,
  toTs: number | null,
): EquipmentStats[] => {
  const byEquipment = new Map<string, ChecklistRecord[]>();
  records.forEach((r) => {
    const hm = Number(r.hourMeter);
    if (r.hourMeter == null || isNaN(hm) || hm <= 0) return;
    const ts = new Date(r.timestamp).getTime();
    if (isNaN(ts)) return;
    if (fromTs != null && ts < fromTs) return;
    if (toTs != null && ts > toTs) return;
    const key = r.equipmentCode || r.equipmentId || 'sem-codigo';
    if (!byEquipment.has(key)) byEquipment.set(key, []);
    byEquipment.get(key)!.push(r);
  });

  const MS_DAY = 1000 * 60 * 60 * 24;

  return Array.from(byEquipment.entries())
    .map(([code, recs]) => {
      const rawReadings: Reading[] = recs
        .map((r) => ({
          date: new Date(r.timestamp),
          hourMeter: Number(r.hourMeter),
          operatorName: r.operatorName,
          recordId: r.id,
        }))
        .filter((r) => !isNaN(r.date.getTime()) && r.hourMeter > 0)
        .sort((a, b) => a.date.getTime() - b.date.getTime());

      // ---- Filtro de outliers (erros de digitação no horímetro) ----
      // Estratégia: usar a mediana como referência e descartar leituras
      // que estejam fora de uma janela plausível (≥ 0,3× e ≤ 3× da mediana).
      // Isso elimina valores como 185518 ou 163 no meio de leituras ~1800.
      const sortedVals = rawReadings.map((r) => r.hourMeter).slice().sort((a, b) => a - b);
      const median =
        sortedVals.length > 0 ? sortedVals[Math.floor(sortedVals.length / 2)] : 0;
      const minBound = median > 0 ? median * 0.3 : 0;
      const maxBound = median > 0 ? median * 3 : Infinity;
      const readings = rawReadings.filter(
        (r) => r.hourMeter >= minBound && r.hourMeter <= maxBound,
      );

      const first = readings[0];
      const last = readings[readings.length - 1];

      // ---- Total de horas: soma de deltas plausíveis entre leituras consecutivas ----
      // Ignora retrocessos (delta < 0) e saltos absurdos (> 24h/dia).
      let totalHours = 0;
      let validDays = 0;
      for (let i = 1; i < readings.length; i++) {
        const dh = readings[i].hourMeter - readings[i - 1].hourMeter;
        const dd =
          (readings[i].date.getTime() - readings[i - 1].date.getTime()) / MS_DAY;
        if (dh > 0 && dd > 0 && dh / dd <= MAX_HOURS_PER_DAY) {
          totalHours += dh;
          validDays += dd;
        }
      }
      // Janela de período (para médias diária/semanal/mensal): preferimos
      // o intervalo real entre primeira e última leitura válidas; caímos
      // para validDays se não houver span.
      const spanDays =
        first && last
          ? Math.max(1, (last.date.getTime() - first.date.getTime()) / MS_DAY)
          : 0;
      const totalDays = spanDays > 0 ? spanDays : validDays;
      const dailyAvg = totalDays > 0 ? totalHours / totalDays : 0;

      const sample = recs[0];
      // pega o local mais recente preenchido entre os registros
      const latestWithLocation = recs
        .slice()
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
        .find((r) => r.location && r.location.trim().length > 0);
      return {
        equipmentId: sample.equipmentId ?? null,
        equipmentCode: code,
        equipmentModel: sample.equipmentModel,
        location: latestWithLocation?.location || sample.location || '—',
        readings,
        firstReading: first,
        lastReading: last,
        totalHours,
        totalDays,
        dailyAvg,
        weeklyAvg: dailyAvg * 7,
        monthlyAvg: dailyAvg * 30,
      };
    })
    .filter((s) => s.readings.length > 0);
};


type SortKey = 'totalHours' | 'dailyAvg' | 'readings' | 'lastReading';

const HourMeterControl = () => {
  const { checklistRecords, isLoading } = useChecklists();
  const [search, setSearch] = useState('');
  const [selectedCode, setSelectedCode] = useState<string>('all');
  const [period, setPeriod] = useState<PeriodKey>('30d');
  const [customFrom, setCustomFrom] = useState<string>('');
  const [customTo, setCustomTo] = useState<string>('');
  const [sortKey, setSortKey] = useState<SortKey>('totalHours');

  const { fromTs, toTs, periodLabel, periodDays } = useMemo(() => {
    const now = Date.now();
    const MS_DAY = 1000 * 60 * 60 * 24;
    if (period === 'custom') {
      const f = customFrom ? new Date(customFrom + 'T00:00:00').getTime() : null;
      const t = customTo ? new Date(customTo + 'T23:59:59').getTime() : null;
      const days = f && t ? Math.max(1, (t - f) / MS_DAY) : 0;
      return {
        fromTs: f,
        toTs: t,
        periodLabel: f && t ? `${customFrom} → ${customTo}` : 'Período personalizado',
        periodDays: days,
      };
    }
    const opt = PERIOD_OPTIONS.find((o) => o.value === period);
    if (!opt || !opt.days) {
      return { fromTs: null, toTs: null, periodLabel: 'Todo o histórico', periodDays: 0 };
    }
    return {
      fromTs: now - opt.days * MS_DAY,
      toTs: now,
      periodLabel: opt.label,
      periodDays: opt.days,
    };
  }, [period, customFrom, customTo]);

  const stats = useMemo(
    () => buildStats(checklistRecords, fromTs, toTs),
    [checklistRecords, fromTs, toTs],
  );

  const filtered = useMemo(() => {
    let arr = stats;
    if (search.trim()) {
      const q = search.toLowerCase();
      arr = arr.filter(
        (s) =>
          s.equipmentCode.toLowerCase().includes(q) ||
          s.equipmentModel.toLowerCase().includes(q),
      );
    }
    return arr.slice().sort((a, b) => {
      if (sortKey === 'totalHours') return b.totalHours - a.totalHours;
      if (sortKey === 'dailyAvg') return b.dailyAvg - a.dailyAvg;
      if (sortKey === 'readings') return b.readings.length - a.readings.length;
      if (sortKey === 'lastReading')
        return (b.lastReading?.hourMeter ?? 0) - (a.lastReading?.hourMeter ?? 0);
      return 0;
    });
  }, [stats, search, sortKey]);

  const selected = selectedCode === 'all' ? null : stats.find((s) => s.equipmentCode === selectedCode);

  // KPIs globais (dentro do período)
  const totalEquipments = stats.length;
  const totalReadings = stats.reduce((sum, s) => sum + s.readings.length, 0);
  const totalHoursPeriod = stats.reduce((sum, s) => sum + s.totalHours, 0);
  const globalDailyAvg =
    stats.length > 0 ? stats.reduce((s, x) => s + x.dailyAvg, 0) / stats.length : 0;
  const topByHours = stats.slice().sort((a, b) => b.totalHours - a.totalHours)[0];
  const topByDaily = stats.slice().sort((a, b) => b.dailyAvg - a.dailyAvg)[0];

  // ---- Sessões operacionais (checklists encerrados) ----
  const sessionGroups = useMemo(() => {
    const q = search.trim().toLowerCase();
    const sessions = (checklistRecords as ChecklistRecord[])
      .filter((r) => {
        if (r.sessionStatus !== 'finalizado') return false;
        if (r.hourMeterEnd == null || r.hourMeterStart == null) return false;
        const ts = new Date(r.startedAt || r.timestamp).getTime();
        if (isNaN(ts)) return false;
        if (fromTs != null && ts < fromTs) return false;
        if (toTs != null && ts > toTs) return false;
        if (selectedCode !== 'all' && r.equipmentCode !== selectedCode) return false;
        if (q && !`${r.equipmentCode} ${r.operatorName}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort(
        (a, b) =>
          new Date(b.startedAt || b.timestamp).getTime() -
          new Date(a.startedAt || a.timestamp).getTime(),
      );

    const map = new Map<string, { key: string; date: string; equipmentCode: string; rows: ChecklistRecord[]; total: number }>();
    sessions.forEach((r) => {
      const d = new Date(r.startedAt || r.timestamp);
      const date = d.toLocaleDateString('pt-BR');
      const key = `${r.equipmentCode}|${date}`;
      if (!map.has(key)) map.set(key, { key, date, equipmentCode: r.equipmentCode, rows: [], total: 0 });
      const g = map.get(key)!;
      g.rows.push(r);
      g.total += Number(r.workedHours ?? Number(r.hourMeterEnd) - Number(r.hourMeterStart)) || 0;
    });
    return Array.from(map.values());
  }, [checklistRecords, fromTs, toTs, selectedCode, search]);

  // ---- Relatório com filtros próprios ----
  const reportFilters: ReportFilterDef[] = useMemo(() => {
    const codes = Array.from(new Set(checklistRecords.map((r) => r.equipmentCode).filter(Boolean))).sort();
    return [
      {
        key: 'periodo',
        label: 'Período',
        type: 'select',
        defaultValue: '30d',
        options: PERIOD_OPTIONS.filter((o) => o.value !== 'custom').map((o) => ({
          value: o.value,
          label: o.label,
        })),
      },
      { key: 'de', label: 'De (opcional)', type: 'date' },
      { key: 'ate', label: 'Até (opcional)', type: 'date' },
      {
        key: 'equipamento',
        label: 'Equipamento',
        type: 'select',
        options: [{ value: 'todos', label: 'Todos' }, ...codes.map((c) => ({ value: c, label: c }))],
      },
      { key: 'minLeituras', label: 'Mínimo de leituras', type: 'number', placeholder: '1' },
      {
        key: 'ordenar',
        label: 'Ordenar por',
        type: 'select',
        options: [
          { value: 'totalHours', label: 'Horas no período' },
          { value: 'dailyAvg', label: 'Média diária' },
          { value: 'readings', label: 'Nº de leituras' },
          { value: 'equipmentCode', label: 'Código do equipamento' },
        ],
      },
    ];
  }, [checklistRecords]);

  const buildHourMeterReport = (v: Record<string, string>) => {
    const MS_DAY = 1000 * 60 * 60 * 24;
    let from: number | null = null;
    let to: number | null = null;
    let label = 'Todo o histórico';

    if (v.de || v.ate) {
      from = v.de ? new Date(`${v.de}T00:00:00`).getTime() : null;
      to = v.ate ? new Date(`${v.ate}T23:59:59`).getTime() : null;
      label = `${v.de || 'início'} → ${v.ate || 'hoje'}`;
    } else {
      const opt = PERIOD_OPTIONS.find((o) => o.value === v.periodo);
      if (opt?.days) {
        from = Date.now() - opt.days * MS_DAY;
        to = Date.now();
      }
      label = opt?.label || label;
    }

    const minReads = v.minLeituras !== '' ? Number(v.minLeituras) : 0;
    let list = buildStats(checklistRecords, from, to).filter((s) => {
      if (v.equipamento !== 'todos' && s.equipmentCode !== v.equipamento) return false;
      if (minReads && s.readings.length < minReads) return false;
      return true;
    });

    list = list.slice().sort((a, b) => {
      if (v.ordenar === 'dailyAvg') return b.dailyAvg - a.dailyAvg;
      if (v.ordenar === 'readings') return b.readings.length - a.readings.length;
      if (v.ordenar === 'equipmentCode') return a.equipmentCode.localeCompare(b.equipmentCode);
      return b.totalHours - a.totalHours;
    });

    const head = ['Equipamento', 'Modelo', 'Local', 'Leituras', 'Último horímetro (h)', 'Horas no período', 'Diária', 'Semanal', 'Mensal'];
    const body = list.map((s) => [
      s.equipmentCode,
      s.equipmentModel,
      s.location,
      s.readings.length,
      (s.lastReading?.hourMeter ?? 0).toFixed(1),
      s.totalHours.toFixed(1),
      s.dailyAvg.toFixed(2),
      s.weeklyAvg.toFixed(2),
      s.monthlyAvg.toFixed(2),
    ]);

    const resumo = list.map((s) => ({
      Equipamento: s.equipmentCode,
      Modelo: s.equipmentModel,
      Local: s.location,
      Leituras: s.readings.length,
      'Último horímetro (h)': Number((s.lastReading?.hourMeter ?? 0).toFixed(1)),
      'Horas no período': Number(s.totalHours.toFixed(1)),
      'Média diária (h)': Number(s.dailyAvg.toFixed(2)),
      'Média semanal (h)': Number(s.weeklyAvg.toFixed(2)),
      'Média mensal (h)': Number(s.monthlyAvg.toFixed(2)),
    }));

    const leituras = list.flatMap((s) =>
      s.readings.map((r) => ({
        Equipamento: s.equipmentCode,
        Modelo: s.equipmentModel,
        Local: s.location,
        Data: r.date.toLocaleString('pt-BR'),
        Operador: r.operatorName,
        'Horímetro (h)': Number(r.hourMeter.toFixed(1)),
      })),
    );

    return {
      head,
      body,
      sheets: [
        { name: 'Resumo', rows: resumo },
        { name: 'Leituras', rows: leituras },
      ],
      subtitle: `Período: ${label} · ${list.length} equipamento(s)`,
    };
  };


  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Gauge className="w-7 h-7 text-primary" />
            Controle de Horímetro
          </h1>
          <p className="text-sm text-muted-foreground">
            Análise de uso por período · <span className="font-medium">{periodLabel}</span>
            {periodDays > 0 && <span> ({Math.round(periodDays)} dias)</span>}
          </p>
        </div>
        <div className="flex gap-2">
          <ReportExportDialog
            title="Relatório de Horímetro"
            description="Defina o período e os equipamentos antes de exportar."
            fileName="horimetro"
            filters={reportFilters}
            buildData={buildHourMeterReport}
          />
        </div>
      </div>

      {/* Filtro de período */}
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="flex flex-wrap gap-2">
            {PERIOD_OPTIONS.map((opt) => (
              <Button
                key={opt.value}
                size="sm"
                variant={period === opt.value ? 'default' : 'outline'}
                onClick={() => setPeriod(opt.value)}
              >
                {opt.label}
              </Button>
            ))}
          </div>
          {period === 'custom' && (
            <div className="flex flex-wrap gap-3 items-end">
              <div>
                <label className="text-xs text-muted-foreground">De</label>
                <Input
                  type="date"
                  value={customFrom}
                  onChange={(e) => setCustomFrom(e.target.value)}
                  className="w-44"
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground">Até</label>
                <Input
                  type="date"
                  value={customTo}
                  onChange={(e) => setCustomTo(e.target.value)}
                  className="w-44"
                />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Equipamentos ativos</p>
                <p className="text-xl font-bold">{totalEquipments}</p>
                <p className="text-xs text-muted-foreground">{totalReadings} leituras</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Horas no período</p>
                <p className="text-xl font-bold">{formatNumber(totalHoursPeriod, 1)} h</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-emerald-500/10">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Média diária (frota)</p>
                <p className="text-xl font-bold">{formatNumber(globalDailyAvg)} h/dia</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-orange-500/40">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Trophy className="w-5 h-5 text-orange-600" />
              </div>
              <div className="min-w-0">
                <p className="text-xs text-muted-foreground">Máquina que mais rodou</p>
                <p className="text-sm font-bold truncate">
                  {topByHours?.equipmentCode || '—'}
                </p>
                <p className="text-xs text-muted-foreground">
                  {topByHours
                    ? `${formatNumber(topByHours.totalHours, 1)} h · ${formatNumber(topByHours.dailyAvg)} h/dia`
                    : ''}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top 5 ranking */}
      {filtered.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Trophy className="w-4 h-4 text-orange-600" />
              Ranking — top 5 do período
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {filtered
              .slice()
              .sort((a, b) => b.totalHours - a.totalHours)
              .slice(0, 5)
              .map((s, i) => (
                <div
                  key={s.equipmentCode}
                  className="p-3 rounded-lg border bg-card hover:bg-accent cursor-pointer transition"
                  onClick={() => setSelectedCode(s.equipmentCode)}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant={i === 0 ? 'default' : 'secondary'}>#{i + 1}</Badge>
                    <span className="text-xs text-muted-foreground truncate">
                      {s.equipmentModel}
                    </span>
                  </div>
                  <p className="font-bold truncate">{s.equipmentCode}</p>
                  <p className="text-sm text-primary font-semibold">
                    {formatNumber(s.totalHours, 1)} h
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {formatNumber(s.dailyAvg)} h/dia
                  </p>
                </div>
              ))}
          </CardContent>
        </Card>
      )}

      {/* Filtros de busca / ordenação */}
      <Card>
        <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por código ou modelo..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={sortKey} onValueChange={(v) => setSortKey(v as SortKey)}>
            <SelectTrigger className="sm:w-56">
              <SelectValue placeholder="Ordenar por" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="totalHours">Horas rodadas (período)</SelectItem>
              <SelectItem value="dailyAvg">Média diária</SelectItem>
              <SelectItem value="readings">Nº de leituras</SelectItem>
              <SelectItem value="lastReading">Último horímetro</SelectItem>
            </SelectContent>
          </Select>
          <Select value={selectedCode} onValueChange={setSelectedCode}>
            <SelectTrigger className="sm:w-64">
              <SelectValue placeholder="Detalhar equipamento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos (visão geral)</SelectItem>
              {stats.map((s) => (
                <SelectItem key={s.equipmentCode} value={s.equipmentCode}>
                  {s.equipmentCode} — {s.equipmentModel}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <ActiveChecklistSessions />

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Visão geral</TabsTrigger>
          <TabsTrigger value="sessions">Equipamento × Operador</TabsTrigger>
          <TabsTrigger value="detail" disabled={!selected}>
            Detalhamento
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sessions">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Utilização por operador — {periodLabel}
              </CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto space-y-6">
              {sessionGroups.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  Nenhum checklist encerrado com horímetro inicial e final neste período.
                </p>
              ) : (
                sessionGroups.map((g) => (
                  <div key={g.key} className="space-y-2">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <p className="font-semibold">
                        {g.equipmentCode} <span className="text-muted-foreground font-normal">· {g.date}</span>
                      </p>
                      <Badge variant="secondary">
                        Total do equipamento no dia: {formatNumber(g.total, 1)} h
                      </Badge>
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Operador</TableHead>
                          <TableHead>Início</TableHead>
                          <TableHead>Final</TableHead>
                          <TableHead>Horímetro Inicial</TableHead>
                          <TableHead>Horímetro Final</TableHead>
                          <TableHead>Horas</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {g.rows.map((r) => {
                          const hours =
                            Number(r.workedHours ?? Number(r.hourMeterEnd) - Number(r.hourMeterStart)) || 0;
                          return (
                            <TableRow key={r.id}>
                              <TableCell className="font-medium">{r.operatorName}</TableCell>
                              <TableCell>
                                {new Date(r.startedAt || r.timestamp).toLocaleTimeString('pt-BR', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })}
                              </TableCell>
                              <TableCell>
                                {r.endedAt
                                  ? new Date(r.endedAt).toLocaleTimeString('pt-BR', {
                                      hour: '2-digit',
                                      minute: '2-digit',
                                    })
                                  : '—'}
                              </TableCell>
                              <TableCell>{formatNumber(Number(r.hourMeterStart), 1)}</TableCell>
                              <TableCell>{formatNumber(Number(r.hourMeterEnd), 1)}</TableCell>
                              <TableCell className="font-semibold text-primary">
                                {formatNumber(hours, 1)} h
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </TabsContent>


        <TabsContent value="overview">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                Médias por equipamento — {periodLabel}
              </CardTitle>
            </CardHeader>
            <CardContent className="overflow-x-auto">
              {isLoading ? (
                <p className="text-sm text-muted-foreground py-8 text-center">Carregando...</p>
              ) : filtered.length === 0 ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  Nenhum equipamento com horímetro informado neste período.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Equipamento</TableHead>
                      <TableHead>Leituras</TableHead>
                      <TableHead>Último horímetro</TableHead>
                      <TableHead>Horas no período</TableHead>
                      <TableHead>Diária</TableHead>
                      <TableHead>Semanal</TableHead>
                      <TableHead>Mensal</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((s) => (
                      <TableRow
                        key={s.equipmentCode}
                        className="cursor-pointer"
                        onClick={() => setSelectedCode(s.equipmentCode)}
                      >
                        <TableCell>
                          <div className="font-medium">{s.equipmentCode}</div>
                          <div className="text-xs text-muted-foreground">{s.equipmentModel}</div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{s.readings.length}</Badge>
                        </TableCell>
                        <TableCell>{formatNumber(s.lastReading?.hourMeter ?? 0, 1)} h</TableCell>
                        <TableCell className="font-semibold">
                          {formatNumber(s.totalHours, 1)} h
                        </TableCell>
                        <TableCell className="font-semibold text-primary">
                          {formatNumber(s.dailyAvg)} h
                        </TableCell>
                        <TableCell>{formatNumber(s.weeklyAvg)} h</TableCell>
                        <TableCell>{formatNumber(s.monthlyAvg)} h</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="detail">
          {selected && (
            <div className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">
                    {selected.equipmentCode} — {selected.equipmentModel}
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <p className="text-xs text-muted-foreground">Média diária</p>
                    <p className="text-lg font-bold">{formatNumber(selected.dailyAvg)} h</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Média semanal</p>
                    <p className="text-lg font-bold">{formatNumber(selected.weeklyAvg)} h</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Média mensal</p>
                    <p className="text-lg font-bold">{formatNumber(selected.monthlyAvg)} h</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Horas no período</p>
                    <p className="text-lg font-bold">{formatNumber(selected.totalHours, 1)} h</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">Leituras do horímetro</CardTitle>
                </CardHeader>
                <CardContent className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Data</TableHead>
                        <TableHead>Operador</TableHead>
                        <TableHead>Horímetro (h)</TableHead>
                        <TableHead>Δ horas</TableHead>
                        <TableHead>Δ dias</TableHead>
                        <TableHead>Taxa (h/dia)</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selected.readings
                        .slice()
                        .reverse()
                        .map((r, idx, arr) => {
                          const prev = arr[idx + 1];
                          const dh = prev ? r.hourMeter - prev.hourMeter : 0;
                          const dd = prev
                            ? (r.date.getTime() - prev.date.getTime()) / (1000 * 60 * 60 * 24)
                            : 0;
                          const rate = dd > 0 ? dh / dd : 0;
                          return (
                            <TableRow key={r.recordId}>
                              <TableCell>{r.date.toLocaleString('pt-BR')}</TableCell>
                              <TableCell>{r.operatorName}</TableCell>
                              <TableCell className="font-medium">
                                {formatNumber(r.hourMeter, 1)}
                              </TableCell>
                              <TableCell>{prev ? formatNumber(dh, 1) : '—'}</TableCell>
                              <TableCell>{prev ? formatNumber(dd, 1) : '—'}</TableCell>
                              <TableCell
                                className={
                                  rate > 0 ? 'font-semibold text-primary' : 'text-muted-foreground'
                                }
                              >
                                {prev ? formatNumber(rate) : '—'}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HourMeterControl;
