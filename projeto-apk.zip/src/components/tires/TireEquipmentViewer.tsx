import { EquipmentViewer } from '@/components/EquipmentViewer';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { reachStackerImages } from '@/lib/reachStackerImages';

interface TireViewerContext {
  code: string;
  position?: string | null;
  equipment?: { code: string; model: string } | null;
}

export function TireEquipmentViewer({ tire, onClose }: { tire: TireViewerContext | null; onClose: () => void }) {
  return (
    <Dialog open={Boolean(tire)} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] max-w-4xl overflow-hidden p-4 sm:p-6" aria-describedby={undefined}>
        <DialogHeader>
          <DialogTitle className="break-words pr-8">Pneu {tire?.code} · Vista 360°</DialogTitle>
        </DialogHeader>
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm">
          <p><span className="text-muted-foreground">Equipamento: </span>{tire?.equipment ? `${tire.equipment.code} — ${tire.equipment.model}` : 'Sem equipamento vinculado'}</p>
          <p><span className="text-muted-foreground">Posição: </span>{tire?.position || 'Não informada'}</p>
        </div>
        {tire && <EquipmentViewer key={tire.code} images={reachStackerImages} equipmentName="Kalmar Reach Stacker" />}
      </DialogContent>
    </Dialog>
  );
}