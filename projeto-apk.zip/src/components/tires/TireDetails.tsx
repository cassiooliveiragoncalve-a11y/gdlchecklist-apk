import { useState } from 'react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Trash2, Ruler, Calendar, Truck, MapPin, Info, Rotate3d } from 'lucide-react';
import { TireEquipmentViewer } from './TireEquipmentViewer';
import { Tire, useTireMeasurements } from '@/hooks/useTires';
import { TireMeasurementForm } from './TireMeasurementForm';
import { TirePositionDiagram } from './TirePositionDiagram';
import { useAuth } from '@/hooks/useSupabaseAuth';

interface TireDetailsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  tire: Tire | null;
  isAdmin: boolean;
}

const getStatusBadge = (status: string) => {
  const badges: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    estoque: { label: 'Em Estoque', variant: 'secondary' },
    em_uso: { label: 'Em Uso', variant: 'default' },
    em_reforma: { label: 'Em Reforma', variant: 'outline' },
  };
  return badges[status] || { label: status, variant: 'outline' };
};

const getPositionLabel = (position: string) => {
  const labels: Record<string, string> = {
    'DD-E': 'Dianteira Direita Externo',
    'DD-I': 'Dianteira Direita Interno',
    'DE-E': 'Dianteira Esquerda Externo',
    'DE-I': 'Dianteira Esquerda Interna',
    'TD': 'Traseira Direita',
    'TE': 'Traseira Esquerda',
  };
  return labels[position] || position;
};

export const TireDetails = ({ open, onOpenChange, tire, isAdmin }: TireDetailsProps) => {
  const [showMeasurementForm, setShowMeasurementForm] = useState(false);
  const [showDiagram, setShowDiagram] = useState(false);
  const [showViewer, setShowViewer] = useState(false);
  const { user } = useAuth();
  const { measurements, isLoading, addMeasurement, deleteMeasurement } = useTireMeasurements(tire?.id || '');

  if (!tire) return null;

  const statusBadge = getStatusBadge(tire.status);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <span>Pneu: {tire.code}</span>
              <Badge variant={statusBadge.variant}>{statusBadge.label}</Badge>
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <Button variant="outline" className="gap-2" onClick={() => setShowViewer(true)}>
              <Rotate3d /> Vista 360° do equipamento
            </Button>
            {/* Informações Gerais */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Informações Gerais</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-muted-foreground">Código:</span>
                  <p className="font-medium">{tire.code}</p>
                </div>
                <div>
                  <span className="text-muted-foreground">Modelo:</span>
                  <p className="font-medium">{tire.model || '-'}</p>
                </div>
                {tire.created_at && (
                  <div>
                    <span className="text-muted-foreground">Cadastrado em:</span>
                    <p className="font-medium">
                      {format(new Date(tire.created_at), "dd/MM/yyyy", { locale: ptBR })}
                    </p>
                  </div>
                )}
                <div className="col-span-2">
                  <span className="text-muted-foreground">Reformadora (recapagem):</span>
                  <p className="font-medium">{tire.retreader || 'Pneu novo / não informada'}</p>
                </div>
              </CardContent>
            </Card>

            {/* Vinculação ao Equipamento */}
            {tire.status === 'em_uso' && (
              <Card>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-base flex items-center gap-2">
                      <Truck className="w-4 h-4" />
                      Equipamento Vinculado
                    </CardTitle>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowDiagram(true)}
                    >
                      <Info className="w-4 h-4 mr-1" />
                      Ver Diagrama
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Truck className="w-3 h-3" /> Equipamento:
                    </span>
                    <p className="font-medium">
                      {tire.equipment ? `${tire.equipment.code} - ${tire.equipment.model}` : '-'}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> Posição:
                    </span>
                    <p className="font-medium">
                      {tire.position ? `${tire.position} (${getPositionLabel(tire.position)})` : '-'}
                    </p>
                  </div>
                  <div>
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Ruler className="w-3 h-3" /> Profundidade Inicial:
                    </span>
                    <p className="font-medium">{tire.initial_depth ? `${tire.initial_depth} mm` : '-'}</p>
                  </div>
                  <div>
                    <span className="text-muted-foreground flex items-center gap-1">
                      <Calendar className="w-3 h-3" /> Horímetro Inicial:
                    </span>
                    <p className="font-medium">{tire.initial_hour_meter || '-'}</p>
                  </div>
                  {tire.mounted_at && (
                    <div className="col-span-2">
                      <span className="text-muted-foreground">Montado em:</span>
                      <p className="font-medium">
                        {format(new Date(tire.mounted_at), "dd/MM/yyyy 'às' HH:mm", { locale: ptBR })}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Histórico de Medições */}
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Ruler className="w-4 h-4" />
                    Histórico de Desgaste
                  </CardTitle>
                  {isAdmin && (
                    <Button size="sm" onClick={() => setShowMeasurementForm(true)}>
                      <Plus className="w-4 h-4 mr-1" />
                      Nova Medição
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <p className="text-muted-foreground text-center py-4">Carregando...</p>
                ) : measurements.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">
                    Nenhuma medição registrada.
                  </p>
                ) : (() => {
                  // measurements vêm do mais recente para o mais antigo
                  const sortedAsc = [...measurements].sort(
                    (a, b) => new Date(a.measured_at).getTime() - new Date(b.measured_at).getTime()
                  );
                  const baseDate = tire.mounted_at ? new Date(tire.mounted_at) : new Date(sortedAsc[0].measured_at);
                  const baseDepth = tire.initial_depth ?? sortedAsc[0].depth;
                  const last = sortedAsc[sortedAsc.length - 1];
                  const totalDays = Math.max(
                    1,
                    (new Date(last.measured_at).getTime() - baseDate.getTime()) / 86400000
                  );
                  const totalWear = baseDepth - last.depth;
                  const avgWear = totalWear / totalDays;

                  // mapa id -> desgaste mm/dia desde a medição anterior (ou base)
                  const wearMap = new Map<string, { delta: number; days: number; rate: number }>();
                  let prevDate = baseDate;
                  let prevDepth = baseDepth;
                  for (const m of sortedAsc) {
                    const days = Math.max(
                      0.01,
                      (new Date(m.measured_at).getTime() - prevDate.getTime()) / 86400000
                    );
                    const delta = prevDepth - m.depth;
                    wearMap.set(m.id, { delta, days, rate: delta / days });
                    prevDate = new Date(m.measured_at);
                    prevDepth = m.depth;
                  }

                  return (
                    <>
                      <div className="grid grid-cols-2 gap-3 mb-4 text-sm">
                        <div className="rounded-md border p-3 bg-muted/30">
                          <p className="text-muted-foreground">Desgaste médio</p>
                          <p className="font-semibold text-base">
                            {avgWear.toFixed(3)} mm/dia
                          </p>
                        </div>
                        <div className="rounded-md border p-3 bg-muted/30">
                          <p className="text-muted-foreground">Desgaste total</p>
                          <p className="font-semibold text-base">
                            {totalWear.toFixed(2)} mm em {Math.round(totalDays)} dia(s)
                          </p>
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Data</TableHead>
                              <TableHead>Profundidade</TableHead>
                              <TableHead>Desgaste (mm/dia)</TableHead>
                              <TableHead>Medido por</TableHead>
                              <TableHead>Observações</TableHead>
                              {isAdmin && <TableHead className="w-10"></TableHead>}
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {measurements.map((m) => {
                              const w = wearMap.get(m.id);
                              return (
                                <TableRow key={m.id}>
                                  <TableCell>
                                    {format(new Date(m.measured_at), "dd/MM/yyyy HH:mm", { locale: ptBR })}
                                  </TableCell>
                                  <TableCell className="font-medium">{m.depth} mm</TableCell>
                                  <TableCell>
                                    {w ? (
                                      <span className="text-sm">
                                        <span className="font-medium">{w.rate.toFixed(3)}</span>
                                        <span className="text-muted-foreground"> ({w.delta.toFixed(2)} mm / {w.days.toFixed(1)} d)</span>
                                      </span>
                                    ) : '-'}
                                  </TableCell>
                                  <TableCell>{m.measured_by || '-'}</TableCell>
                                  <TableCell className="max-w-[150px] truncate">{m.notes || '-'}</TableCell>
                                  {isAdmin && (
                                    <TableCell>
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        className="h-8 w-8 text-destructive"
                                        onClick={() => deleteMeasurement(m.id)}
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </TableCell>
                                  )}
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </>
                  );
                })()}
              </CardContent>
            </Card>
          </div>
        </DialogContent>
      </Dialog>

      <TireMeasurementForm
        open={showMeasurementForm}
        onOpenChange={setShowMeasurementForm}
        onSubmit={addMeasurement}
        tireId={tire.id}
        tireCode={tire.code}
        measuredBy={user?.name}
      />

      <TirePositionDiagram
        open={showDiagram}
        onOpenChange={setShowDiagram}
      />
      <TireEquipmentViewer tire={showViewer && open ? tire : null} onClose={() => setShowViewer(false)} />
    </>
  );
};
