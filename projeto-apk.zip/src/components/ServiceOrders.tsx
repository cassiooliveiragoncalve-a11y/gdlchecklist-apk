import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Wrench, AlertTriangle, Clock, Timer, PackageX } from 'lucide-react';
import { Equipment } from '@/types/equipment';
import { User } from '@/hooks/useSupabaseAuth';
import { useServiceOrders } from '@/hooks/useServiceOrders';
import { useNow } from '@/hooks/useNow';
import {
  ServiceOrder,
  ServiceOrderStatus,
  MaintenanceType,
  STATUS_CLASSES,
  STATUS_LABELS,
  MAINTENANCE_TYPE_LABELS,
  formatDowntime,
  downtimeMinutes,
  isOpenStatus,
} from '@/types/serviceOrder';
import { ReportExportDialog, ReportFilterDef } from '@/components/reports/ReportExportDialog';
import { ServiceOrderForm } from '@/components/serviceOrders/ServiceOrderForm';
import { ServiceOrderDetails } from '@/components/serviceOrders/ServiceOrderDetails';
import { ServiceOrderHistory } from '@/components/serviceOrders/ServiceOrderHistory';
import { ServiceOrderIndicators } from '@/components/serviceOrders/ServiceOrderIndicators';

interface Props {
  equipments: Equipment[];
  currentUser: User | null;
}

const ServiceOrders = ({ equipments, currentUser }: Props) => {
  const now = useNow(30000);
  const {
    serviceOrders,
    openOrders,
    isLoading,
    findOpenByEquipment,
    createServiceOrder,
    startMaintenance,
    finalizeServiceOrder,
    cancelServiceOrder,
    reopenServiceOrder,
    deleteServiceOrder,
  } = useServiceOrders();

  const [formOpen, setFormOpen] = useState(false);
  const [selected, setSelected] = useState<ServiceOrder | null>(null);

  const profile = currentUser?.profile;
  const canManage = profile === 'mecanico' || profile === 'gestor' || profile === 'admin';
  const canCancel = profile === 'gestor' || profile === 'admin';
  const canReopen = profile === 'admin';
  const canDelete = profile === 'admin';

  // Mantém o objeto selecionado sincronizado com o cache
  const selectedLive = useMemo(
    () => (selected ? serviceOrders.find((o) => o.id === selected.id) || selected : null),
    [selected, serviceOrders]
  );

  const stats = useMemo(() => {
    const emManutencao = serviceOrders.filter((o) => o.status === 'em_manutencao').length;
    const aguardando = serviceOrders.filter((o) => o.status === 'aberta').length;
    const indisponiveis = new Set(openOrders.map((o) => o.equipment_id)).size;
    return [
      { title: 'OS Abertas', value: openOrders.length, icon: Wrench, color: 'text-safety-red', bg: 'bg-safety-red-light' },
      { title: 'Equipamentos Indisponíveis', value: indisponiveis, icon: PackageX, color: 'text-safety-orange', bg: 'bg-safety-orange-light' },
      { title: 'Em Manutenção', value: emManutencao, icon: Timer, color: 'text-industrial-blue', bg: 'bg-industrial-blue-light' },
      { title: 'Aguardando Atendimento', value: aguardando, icon: Clock, color: 'text-safety-orange', bg: 'bg-safety-orange-light' },
    ];
  }, [serviceOrders, openOrders]);

  const openSorted = useMemo(
    () => [...openOrders].sort((a, b) => new Date(a.data_hora_abertura).getTime() - new Date(b.data_hora_abertura).getTime()),
    [openOrders]
  );

  const uniqueSorted = (values: (string | null | undefined)[]) =>
    Array.from(new Set(values.map((v) => v?.trim()).filter(Boolean) as string[])).sort();

  const osReportFilters: ReportFilterDef[] = useMemo(() => [
    {
      key: 'status',
      label: 'Status',
      type: 'select',
      options: [
        { value: 'todos', label: 'Todos' },
        { value: 'abertas', label: 'Somente abertas' },
        { value: 'fechadas', label: 'Somente fechadas' },
        ...(Object.keys(STATUS_LABELS) as ServiceOrderStatus[]).map((s) => ({
          value: s,
          label: STATUS_LABELS[s],
        })),
      ],
    },
    {
      key: 'tipo',
      label: 'Tipo de manutenção',
      type: 'select',
      options: [
        { value: 'todos', label: 'Todos' },
        ...(Object.keys(MAINTENANCE_TYPE_LABELS) as MaintenanceType[]).map((t) => ({
          value: t,
          label: MAINTENANCE_TYPE_LABELS[t],
        })),
      ],
    },
    {
      key: 'unidade',
      label: 'Unidade',
      type: 'select',
      options: [
        { value: 'todas', label: 'Todas' },
        ...uniqueSorted(serviceOrders.map((o) => o.unit)).map((u) => ({ value: u, label: u })),
      ],
    },
    {
      key: 'oficina',
      label: 'Oficina',
      type: 'select',
      options: [
        { value: 'todas', label: 'Todas' },
        ...uniqueSorted(serviceOrders.map((o) => o.oficina)).map((o) => ({ value: o, label: o })),
      ],
    },
    {
      key: 'equipamento',
      label: 'Equipamento',
      type: 'select',
      options: [
        { value: 'todos', label: 'Todos' },
        ...uniqueSorted(serviceOrders.map((o) => o.equipment_code)).map((c) => ({ value: c, label: c })),
      ],
    },
    {
      key: 'mecanico',
      label: 'Mecânico',
      type: 'select',
      options: [
        { value: 'todos', label: 'Todos' },
        ...uniqueSorted(serviceOrders.map((o) => o.mecanico_responsavel)).map((m) => ({ value: m, label: m })),
      ],
    },
    { key: 'de', label: 'Abertura de', type: 'date' },
    { key: 'ate', label: 'Abertura até', type: 'date' },
  ], [serviceOrders]);

  const buildOsReport = (v: Record<string, string>) => {
    const de = v.de ? new Date(`${v.de}T00:00:00`).getTime() : null;
    const ate = v.ate ? new Date(`${v.ate}T23:59:59`).getTime() : null;

    const list = serviceOrders.filter((o) => {
      const ts = new Date(o.data_hora_abertura).getTime();
      if (de != null && ts < de) return false;
      if (ate != null && ts > ate) return false;
      if (v.status === 'abertas' && !isOpenStatus(o.status)) return false;
      if (v.status === 'fechadas' && isOpenStatus(o.status)) return false;
      if (v.status !== 'todos' && v.status !== 'abertas' && v.status !== 'fechadas' && o.status !== v.status) return false;
      if (v.tipo !== 'todos' && o.tipo_manutencao !== v.tipo) return false;
      if (v.unidade !== 'todas' && (o.unit || '').trim() !== v.unidade) return false;
      if (v.oficina !== 'todas' && (o.oficina || '').trim() !== v.oficina) return false;
      if (v.equipamento !== 'todos' && o.equipment_code !== v.equipamento) return false;
      if (v.mecanico !== 'todos' && o.mecanico_responsavel !== v.mecanico) return false;
      return true;
    }).sort((a, b) => new Date(b.data_hora_abertura).getTime() - new Date(a.data_hora_abertura).getTime());

    const dt = (d: string | null) => (d ? new Date(d).toLocaleString('pt-BR') : '');
    const downtime = (o: ServiceOrder) =>
      formatDowntime(isOpenStatus(o.status) ? downtimeMinutes(o, now) : o.tempo_indisponibilidade_minutos);

    const head = ['Nº OS', 'Equipamento', 'Modelo', 'Tipo', 'Status', 'Oficina', 'Mecânico', 'Abertura', 'Fechamento', 'Indisponibilidade'];
    const body = list.map((o) => [
      o.numero_os,
      o.equipment_code,
      o.equipment_model || '',
      MAINTENANCE_TYPE_LABELS[o.tipo_manutencao],
      STATUS_LABELS[o.status],
      o.oficina || '',
      o.mecanico_responsavel,
      dt(o.data_hora_abertura),
      dt(o.data_hora_fechamento),
      downtime(o),
    ]);

    const rows = list.map((o) => ({
      'Nº OS': o.numero_os,
      Equipamento: o.equipment_code,
      Modelo: o.equipment_model || '',
      Unidade: o.unit || '',
      Local: o.location || '',
      Oficina: o.oficina || '',
      Tipo: MAINTENANCE_TYPE_LABELS[o.tipo_manutencao],
      Status: STATUS_LABELS[o.status],
      Mecânico: o.mecanico_responsavel,
      Abertura: dt(o.data_hora_abertura),
      'Início manutenção': dt(o.data_hora_inicio_manutencao),
      Fechamento: dt(o.data_hora_fechamento),
      'Indisponibilidade (min)': o.tempo_indisponibilidade_minutos ?? '',
      Indisponibilidade: downtime(o),
      Ocorrência: o.descricao_ocorrencia,
      'Serviço executado': o.servico_executado || '',
      Causa: o.causa_identificada || '',
      'Peças/Materiais': o.pecas_materiais || '',
      Observações: o.observacoes || '',
    }));

    return {
      head,
      body,
      sheets: [{ name: 'Ordens de Serviço', rows }],
      subtitle: `${list.length} ordem(ns) de serviço`,
    };
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h2 className="text-lg sm:text-xl lg:text-2xl font-bold text-foreground">Ordens de Serviço / Manutenção</h2>
          <p className="text-xs sm:text-sm text-muted-foreground">Abertura, acompanhamento e histórico de intervenções</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
          <ReportExportDialog
            title="Relatório de Ordens de Serviço"
            description="Filtre as OS antes de exportar em PDF ou Excel."
            fileName="ordens_de_servico"
            filters={osReportFilters}
            buildData={buildOsReport}
            buttonClassName="h-12 w-full sm:w-auto"
          />
          {canManage && (
            <Button
              className="h-12 w-full sm:w-auto bg-safety-orange hover:bg-safety-orange/90 text-white text-base font-semibold"
              onClick={() => setFormOpen(true)}
            >
              <Plus className="w-5 h-5 mr-2" />
              Abrir Ordem de Serviço
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3">
        {stats.map((s) => {
          const Icon = s.icon;
          return (
            <Card key={s.title}>
              <CardContent className="p-3 sm:p-4 flex flex-col gap-2">
                <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg ${s.bg} flex items-center justify-center`}>
                  <Icon className={`w-4 h-4 sm:w-5 sm:h-5 ${s.color}`} />
                </div>
                <div>
                  <p className="text-xs font-medium text-muted-foreground line-clamp-2 mb-1">{s.title}</p>
                  <p className="text-xl sm:text-2xl font-bold text-foreground">{s.value}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Tabs defaultValue="abertas">
        <TabsList className="w-full grid grid-cols-3 h-11">
          <TabsTrigger value="abertas">Abertas</TabsTrigger>
          <TabsTrigger value="historico">Histórico</TabsTrigger>
          <TabsTrigger value="indicadores">Indicadores</TabsTrigger>
        </TabsList>

        <TabsContent value="abertas" className="mt-3">
          <Card>
            <CardHeader className="p-4">
              <CardTitle className="flex items-center gap-2 text-base">
                <AlertTriangle className="w-5 h-5 text-safety-red" />
                Ordens de Serviço Abertas
                {openSorted.length > 0 && <Badge className="bg-safety-red text-white">{openSorted.length}</Badge>}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-3 sm:p-4 pt-0 space-y-2">
              {isLoading && <p className="text-sm text-muted-foreground py-6 text-center">Carregando...</p>}
              {!isLoading && openSorted.length === 0 && (
                <p className="text-sm text-muted-foreground py-8 text-center">Nenhuma OS em aberto no momento</p>
              )}
              {openSorted.map((os) => (
                <div
                  key={os.id}
                  className="border rounded-lg p-3 cursor-pointer hover:bg-muted/50 active:scale-[0.99] transition"
                  onClick={() => setSelected(os)}
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="font-semibold text-sm">{os.numero_os}</span>
                    <Badge className={STATUS_CLASSES[os.status]}>{STATUS_LABELS[os.status]}</Badge>
                  </div>
                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground mb-1">
                    <span className="font-medium text-foreground text-sm">{os.equipment_code}</span>
                    <span>{MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]}</span>
                    <span>{os.mecanico_responsavel}</span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{os.descricao_ocorrencia}</p>
                  <div className="flex items-center gap-1 text-safety-red font-bold text-sm">
                    <Timer className="w-4 h-4" />
                    Indisponível há {formatDowntime(downtimeMinutes(os, now))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="historico" className="mt-3">
          <ServiceOrderHistory orders={serviceOrders} onSelect={setSelected} />
        </TabsContent>

        <TabsContent value="indicadores" className="mt-3">
          <ServiceOrderIndicators orders={serviceOrders} totalEquipments={equipments.length} />
        </TabsContent>
      </Tabs>

      <ServiceOrderForm
        open={formOpen}
        onOpenChange={setFormOpen}
        equipments={equipments}
        mechanicName={currentUser?.name || ''}
        findOpenByEquipment={findOpenByEquipment}
        onCreate={createServiceOrder}
        onViewExisting={(os) => setSelected(os)}
      />

      <ServiceOrderDetails
        os={selectedLive}
        open={!!selectedLive}
        onOpenChange={(v) => !v && setSelected(null)}
        canManage={canManage}
        canCancel={canCancel}
        canReopen={canReopen}
        canDelete={canDelete}
        onStart={startMaintenance}
        onFinalize={finalizeServiceOrder}
        onCancel={cancelServiceOrder}
        onReopen={reopenServiceOrder}
        onDelete={deleteServiceOrder}
      />

    </div>
  );
};

export default ServiceOrders;
