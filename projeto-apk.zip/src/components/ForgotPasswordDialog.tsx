import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ForgotPasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type Step = 'identify' | 'validate' | 'done';

export const ForgotPasswordDialog: React.FC<ForgotPasswordDialogProps> = ({ open, onOpenChange }) => {
  const [step, setStep] = useState<Step>('identify');
  const [identifier, setIdentifier] = useState('');
  const [matricula, setMatricula] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const reset = () => {
    setStep('identify');
    setIdentifier('');
    setMatricula('');
    setNewPassword('');
    setConfirmPassword('');
    setError('');
    setLoading(false);
  };

  const handleClose = (o: boolean) => {
    if (!o) reset();
    onOpenChange(o);
  };

  const handleIdentify = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!identifier.trim()) {
      setError('Informe seu usuário ou nome completo');
      return;
    }
    setLoading(true);
    try {
      // Apenas avança - validação real ocorre no passo 2 (não revela se usuário existe)
      const { error: fnError } = await supabase.functions.invoke('reset-password-with-matricula', {
        body: { step: 'find', identifier: identifier.trim() }
      });
      if (fnError) throw fnError;
      setStep('validate');
    } catch (err: any) {
      console.error(err);
      setError('Não foi possível processar a solicitação. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!matricula.trim()) {
      setError('Informe sua matrícula');
      return;
    }
    if (newPassword.length < 6) {
      setError('A nova senha deve ter no mínimo 6 caracteres');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('As senhas não coincidem');
      return;
    }
    setLoading(true);
    try {
      const { data, error: fnError } = await supabase.functions.invoke('reset-password-with-matricula', {
        body: {
          step: 'reset',
          identifier: identifier.trim(),
          matricula: matricula.trim(),
          newPassword,
        }
      });
      if (fnError || (data && (data as any).error)) {
        setError('Dados informados não conferem');
        setLoading(false);
        return;
      }
      setStep('done');
      toast({
        title: 'Senha atualizada',
        description: 'Sua senha foi redefinida com sucesso.',
      });
    } catch (err: any) {
      console.error(err);
      setError('Dados informados não conferem');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Recuperar senha</DialogTitle>
          <DialogDescription>
            {step === 'identify' && 'Informe seu usuário ou nome completo para iniciar.'}
            {step === 'validate' && 'Confirme sua matrícula e cadastre uma nova senha.'}
            {step === 'done' && 'Senha alterada com sucesso.'}
          </DialogDescription>
        </DialogHeader>

        {step === 'identify' && (
          <form onSubmit={handleIdentify} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fp-identifier">Usuário ou nome completo</Label>
              <Input
                id="fp-identifier"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="ex: joao.silva ou João da Silva"
                disabled={loading}
                maxLength={100}
              />
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => handleClose(false)} disabled={loading}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Continuando...</> : 'Continuar'}
              </Button>
            </DialogFooter>
          </form>
        )}

        {step === 'validate' && (
          <form onSubmit={handleReset} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="fp-matricula">Matrícula cadastrada</Label>
              <Input
                id="fp-matricula"
                value={matricula}
                onChange={(e) => setMatricula(e.target.value)}
                placeholder="Digite sua matrícula"
                disabled={loading}
                maxLength={20}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fp-new">Nova senha</Label>
              <Input
                id="fp-new"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Mínimo 6 caracteres"
                disabled={loading}
                maxLength={100}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fp-confirm">Confirmar nova senha</Label>
              <Input
                id="fp-confirm"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Digite a senha novamente"
                disabled={loading}
                maxLength={100}
              />
            </div>
            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setStep('identify')} disabled={loading}>
                Voltar
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Salvando...</> : 'Redefinir senha'}
              </Button>
            </DialogFooter>
          </form>
        )}

        {step === 'done' && (
          <div className="space-y-4">
            <Alert>
              <CheckCircle2 className="h-4 w-4" />
              <AlertDescription>
                Senha alterada com sucesso. Você já pode fazer login com a nova senha.
              </AlertDescription>
            </Alert>
            <DialogFooter>
              <Button onClick={() => handleClose(false)}>Fechar</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
