import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { useReducedMotion } from 'framer-motion';
import { ChevronLeft, ChevronRight, ImageIcon, Upload, Rotate3d, Pause, Play, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import {
  EQUIPMENT_VIEWS, EQUIPMENT_ROTATION_INTERVAL, adjacentEquipmentView, equipmentSwipeDirection,
  preloadEquipmentImages, type EquipmentView, type EquipmentViewerImages,
} from '@/lib/equipmentViewer';

export interface EquipmentViewerProps {
  images?: EquipmentViewerImages;
  equipmentName?: string;
  className?: string;
}

export function EquipmentViewer({ images = {}, equipmentName = 'Reach Stacker', className }: EquipmentViewerProps) {
  const [view, setView] = useState<EquipmentView>('front');
  const [localImages, setLocalImages] = useState<EquipmentViewerImages>({});
  const [failedImages, setFailedImages] = useState<EquipmentViewerImages>({});
  const [uploadError, setUploadError] = useState('');
  const [rotating, setRotating] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [readyKey, setReadyKey] = useState<string | null>(null);
  const urls = useRef<EquipmentViewerImages>({});
  const gesture = useRef<{ x: number; y: number; id: number } | null>(null);
  const reducedMotion = useReducedMotion();
  const current = EQUIPMENT_VIEWS.find((item) => item.id === view) ?? EQUIPMENT_VIEWS[0];
  const sources = EQUIPMENT_VIEWS.map(({ id }) => localImages[id] ?? images[id] ?? '');
  const sourceKey = JSON.stringify(sources);
  const ready = readyKey === sourceKey;

  useEffect(() => () => {
    Object.values(urls.current).forEach((url) => URL.revokeObjectURL(url));
  }, []);

  useEffect(() => {
    let cancelled = false;
    const values: string[] = JSON.parse(sourceKey);
    const pending: EquipmentViewerImages = {};
    EQUIPMENT_VIEWS.forEach(({ id }, index) => { if (values[index]) pending[id] = values[index]; });
    preloadEquipmentImages(pending).then((failures) => {
      if (cancelled) return;
      setFailedImages(failures);
      setReadyKey(sourceKey);
    });
    return () => { cancelled = true; };
  }, [sourceKey]);

  useEffect(() => {
    if (!rotating || !ready) return;
    const timer = window.setInterval(() => {
      if (!document.hidden) setView((previous) => adjacentEquipmentView(previous, 1));
    }, EQUIPMENT_ROTATION_INTERVAL);
    return () => window.clearInterval(timer);
  }, [rotating, ready]);

  function navigate(direction: 1 | -1) {
    setRotating(false);
    if (ready) setView((previous) => adjacentEquipmentView(previous, direction));
  }

  function finishGesture(event: PointerEvent<HTMLDivElement>) {
    const start = gesture.current;
    gesture.current = null;
    setDragging(false);
    if (!start || start.id !== event.pointerId) return;
    const direction = equipmentSwipeDirection(event.clientX - start.x, event.clientY - start.y);
    if (direction) navigate(direction);
  }

  function selectImage(target: EquipmentView, file?: File) {
    if (!file) return;
    setRotating(false);
    if (!['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/gif'].includes(file.type)) {
      setUploadError('Selecione uma imagem JPG, PNG, WebP, AVIF ou GIF.');
      return;
    }
    const oldUrl = urls.current[target];
    if (oldUrl) URL.revokeObjectURL(oldUrl);
    const url = URL.createObjectURL(file);
    urls.current[target] = url;
    setLocalImages((previous) => ({ ...previous, [target]: url }));
    setUploadError('');
  }

  return (
    <TooltipProvider delayDuration={200}>
      <section
        aria-label={`Visualização de ${equipmentName}`}
        className={cn('min-h-0 min-w-0 space-y-3', className)}
        onKeyDown={(event) => {
          if (event.target instanceof HTMLInputElement) return;
          if (event.key !== 'ArrowLeft' && event.key !== 'ArrowRight') return;
          event.preventDefault();
          navigate(event.key === 'ArrowLeft' ? -1 : 1);
        }}
      >
        <div className="flex items-center justify-between gap-3">
          <h3 className="min-w-0 break-words text-sm font-semibold">{equipmentName}</h3>
          <Popover onOpenChange={(open) => { if (open) setRotating(false); }}>
            <Tooltip>
              <TooltipTrigger asChild>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0" aria-label="Selecionar imagens locais"><Upload aria-hidden="true" /></Button>
                </PopoverTrigger>
              </TooltipTrigger>
              <TooltipContent>Selecionar imagens locais</TooltipContent>
            </Tooltip>
            <PopoverContent align="end" className="w-64 space-y-2">
              {EQUIPMENT_VIEWS.map((item) => (
                <Button key={item.id} variant="outline" asChild className="h-10 w-full cursor-pointer gap-2 text-xs has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-ring">
                  <label>
                    <Upload aria-hidden="true" />{localImages[item.id] ?? images[item.id] ? 'Trocar' : 'Selecionar'} {item.label.toLowerCase()}
                    <input type="file" accept="image/jpeg,image/png,image/webp,image/avif,image/gif" aria-label={`Selecionar imagem: ${item.fullLabel}`} className="sr-only" onChange={(event) => {
                      selectImage(item.id, event.target.files?.[0]);
                      event.target.value = '';
                    }} />
                  </label>
                </Button>
              ))}
              <p className="text-xs text-muted-foreground">Prévia local · As imagens não são enviadas nem salvas.</p>
              {uploadError && <p role="alert" className="text-sm text-destructive">{uploadError}</p>}
            </PopoverContent>
          </Popover>
        </div>

        <div className="flex min-h-0 justify-center">
          <div
            tabIndex={0}
            aria-label="Girar equipamento"
            aria-busy={!ready}
            data-equipment-stage
            className={cn('relative aspect-[16/10] w-full max-w-[calc((100dvh-20rem)*1.6)] touch-pan-y select-none overflow-hidden rounded-xl border bg-muted shadow-sm outline-none focus-visible:ring-2 focus-visible:ring-ring', dragging ? 'cursor-grabbing' : 'cursor-grab')}
            onPointerDown={(event) => {
              if (!event.isPrimary || event.button !== 0 || !ready || (event.target instanceof Element && event.target.closest('button'))) return;
              setRotating(false);
              setDragging(true);
              gesture.current = { x: event.clientX, y: event.clientY, id: event.pointerId };
              event.currentTarget.focus();
              event.currentTarget.setPointerCapture(event.pointerId);
            }}
            onPointerUp={finishGesture}
            onPointerCancel={() => { gesture.current = null; setDragging(false); }}
            onLostPointerCapture={() => { gesture.current = null; setDragging(false); }}
          >
            {EQUIPMENT_VIEWS.map((item) => {
              const source = localImages[item.id] ?? images[item.id];
              const failed = Boolean(source && failedImages[item.id] === source);
              const active = view === item.id;
              return (
                <div
                  key={item.id}
                  aria-hidden={!active || !ready}
                  data-equipment-view={item.id}
                  className={cn('pointer-events-none absolute inset-0 flex items-center justify-center p-4 transition-[opacity,transform] ease-in-out sm:p-6', reducedMotion ? 'duration-100' : 'duration-300', active && ready ? 'z-10 scale-100 opacity-100' : cn('z-0 opacity-0', !reducedMotion && 'scale-[0.98]'))}
                >
                  {source && !failed ? (
                    <img src={source} alt={`${equipmentName} — ${item.fullLabel}`} className="h-full w-full object-contain" draggable={false} onError={() => setFailedImages((previous) => ({ ...previous, [item.id]: source }))} />
                  ) : (
                    <div className="space-y-2 text-center text-muted-foreground"><ImageIcon className="mx-auto h-8 w-8" aria-hidden="true" /><p className="text-xs">{failed ? 'Não foi possível abrir esta imagem.' : `Imagem ${item.label.toLowerCase()} não selecionada`}</p></div>
                  )}
                  <div className="pointer-events-none absolute inset-0" data-equipment-overlay={item.id} />
                </div>
              );
            })}
            {!ready && <div className="absolute inset-0 z-20 flex items-center justify-center bg-muted" role="status" aria-label="Carregando imagens"><Loader2 className="h-6 w-6 animate-spin text-muted-foreground motion-reduce:animate-none" aria-hidden="true" /></div>}
            <span role="status" aria-live="polite" className="pointer-events-none absolute right-3 top-3 z-30 flex max-w-[calc(100%-1.5rem)] items-center gap-1.5 rounded-md border bg-background/80 px-2 py-1 text-xs text-muted-foreground"><Rotate3d className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />{current.fullLabel}</span>
            {([-1, 1] as const).map((direction) => (
              <Tooltip key={direction}>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="icon" disabled={!ready} aria-label={direction === -1 ? 'Vista anterior' : 'Vista seguinte'} onClick={() => navigate(direction)} className={cn('absolute top-1/2 z-30 h-10 w-10 -translate-y-1/2 rounded-full bg-background/70 text-foreground hover:bg-background', direction === -1 ? 'left-2 sm:left-3' : 'right-2 sm:right-3')}>
                    {direction === -1 ? <ChevronLeft aria-hidden="true" /> : <ChevronRight aria-hidden="true" />}
                  </Button>
                </TooltipTrigger>
                <TooltipContent>{direction === -1 ? 'Vista anterior' : 'Vista seguinte'}</TooltipContent>
              </Tooltip>
            ))}
          </div>
        </div>

        <div className="flex items-center justify-center gap-2">
          <Tabs value={view} onValueChange={(value) => { setRotating(false); setView(value as EquipmentView); }} activationMode="manual" className="min-w-0">
            <TabsList aria-label="Vistas do equipamento" className="grid h-10 grid-cols-4">
              {EQUIPMENT_VIEWS.map((item) => <TabsTrigger key={item.id} value={item.id} disabled={!ready} aria-label={item.fullLabel} className="min-w-0 px-2 text-xs data-[state=active]:bg-primary/10 data-[state=active]:text-primary sm:px-4 sm:text-sm">{item.label}</TabsTrigger>)}
            </TabsList>
          </Tabs>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant={rotating ? 'default' : 'outline'} size="icon" disabled={!ready} className="h-10 w-10 shrink-0" aria-label={rotating ? 'Pausar rotação' : 'Rotação automática'} aria-pressed={rotating} onClick={() => setRotating((value) => !value)}>{rotating ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />}</Button>
            </TooltipTrigger>
            <TooltipContent>{rotating ? 'Pausar rotação' : 'Rotação automática'}</TooltipContent>
          </Tooltip>
        </div>
      </section>
    </TooltipProvider>
  );
}
