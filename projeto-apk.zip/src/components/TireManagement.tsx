import { useMemo, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Info, Rotate3d } from 'lucide-react';
import { useTires, Tire, TireFormData } from '@/hooks/useTires';
import { useAuth } from '@/hooks/useSupabaseAuth';
import { TireStats } from './tires/TireStats';
import { TireList } from './tires/TireList';
import { TireForm } from './tires/TireForm';
import { TireDetails } from './tires/TireDetails';
import { TirePositionDiagram } from './tires/TirePositionDiagram';
import { ReportExportDialog, ReportFilterDef } from './reports/ReportExportDialog';
import { EquipmentViewer } from './EquipmentViewer';
import { reachStackerImages } from '@/lib/reachStackerImages';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';

const STATUS_LABEL: Record<Tire['status'], string> = {
  estoque: 'Em estoque',
  em_uso: 'Em uso',
  em_reforma: 'Em reforma',
};

const TireManagement = () => {
  const { user } = useAuth();
  const isAdmin = user?.profile === 'admin';
  
  const { tires, isLoading, stats, createTire, updateTire, deleteTire } = useTires();
  
  const [showForm, setShowForm] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [showDiagram, setShowDiagram] = useState(false);
  const [showViewer, setShowViewer] = useState(false);
  const [selectedTire, setSelectedTire] = useState<Tire | null>(null);

  const handleCreate = async (data: TireFormData) => {
    return await createTire(data);
  };

  const handleEdit = (tire: Tire) => {
    setSelectedTire(tire);
    setShowForm(true);
  };

  const handleUpdate = async (data: TireFormData) => {
    if (!selectedTire) return false;
    return await updateTire(selectedTire.id, data);
  };

  const handleView = (tire: Tire) => {
    setSelectedTire(tire);
    setShowDetails(true);
  };

  const handleCloseForm = (open: boolean) => {
    setShowForm(open);
    if (!open) setSelectedTire(null);
  };

  const handleCloseDetails = (open: boolean) => {
    setShowDetails(open);
    if (!open) setSelectedTire(null);
  };

  const lifePercent = (t: Tire) => {
    const depth = t.latest_depth ?? t.initial_depth;
    return t.initial_depth && t.initial_depth > 0 && depth != null
      ? Math.max(0, Math.min(100, (depth / t.initial_depth) * 100))
      : null;
  };

  const tireFilters: ReportFilterDef[] = useMemo(() => {
    const equipCodes = Array.from(
      new Set(tires.map((t) => t.equipment?.code).filter(Boolean) as string[]),
    ).sort();
    const retreaders = Array.from(
      new Set(tires.map((t) => t.retreader?.trim()).filter(Boolean) as string[]),
    ).sort();

    return [
      {
        key: 'status',
        label: 'Status',
        type: 'select',
        options: [
          { value: 'todos', label: 'Todos' },
          { value: 'estoque', label: 'Em estoque' },
          { value: 'em_uso', label: 'Em uso' },
          { value: 'em_reforma', label: 'Em reforma' },
        ],
      },
      {
        key: 'equipamento',
        label: 'Equipamento',
        type: 'select',
        options: [
          { value: 'todos', label: 'Todos' },
          { value: 'sem', label: 'Sem equipamento' },
          ...equipCodes.map((c) => ({ value: c, label: c })),
        ],
      },
      {
        key: 'recapadora',
        label: 'Recapadora',
        type: 'select',
        options: [
          { value: 'todas', label: 'Todas' },
          ...retreaders.map((r) => ({ value: r, label: r })),
        ],
      },
      { key: 'vidaMin', label: 'Vida útil mínima (%)', type: 'number', placeholder: '0' },
      { key: 'vidaMax', label: 'Vida útil máxima (%)', type: 'number', placeholder: '100' },
      { key: 'montadoDe', label: 'Montado de', type: 'date' },
      { key: 'montadoAte', label: 'Montado até', type: 'date' },
    ];
  }, [tires]);

  const buildTireReport = (v: Record<string, string>) => {
    const min = v.vidaMin !== '' ? Number(v.vidaMin) : null;
    const max = v.vidaMax !== '' ? Number(v.vidaMax) : null;
    const de = v.montadoDe ? new Date(`${v.montadoDe}T00:00:00`).getTime() : null;
    const ate = v.montadoAte ? new Date(`${v.montadoAte}T23:59:59`).getTime() : null;

    const list = tires.filter((t) => {
      if (v.status !== 'todos' && t.status !== v.status) return false;
      if (v.equipamento === 'sem' && t.equipment?.code) return false;
      if (v.equipamento !== 'todos' && v.equipamento !== 'sem' && t.equipment?.code !== v.equipamento)
        return false;
      if (v.recapadora !== 'todas' && (t.retreader?.trim() || '') !== v.recapadora) return false;

      const pct = lifePercent(t);
      if (min != null && (pct == null || pct < min)) return false;
      if (max != null && (pct == null || pct > max)) return false;

      const mts = t.mounted_at ? new Date(t.mounted_at).getTime() : null;
      if (de != null && (mts == null || mts < de)) return false;
      if (ate != null && (mts == null || mts > ate)) return false;
      return true;
    });

    const head = ['Código', 'Modelo', 'Status', 'Equipamento', 'Posição', 'Prof. inicial (mm)', 'Prof. atual (mm)', 'Vida útil', 'Horímetro inicial', 'Montado em', 'Recapadora'];
    const body = list.map((t) => [
      t.code,
      t.model ?? '',
      STATUS_LABEL[t.status],
      t.equipment?.code ?? '',
      t.position ?? '',
      t.initial_depth ?? '',
      t.latest_depth ?? '',
      lifePercent(t),
      t.initial_hour_meter ?? '',
      t.mounted_at ? new Date(t.mounted_at).toLocaleDateString('pt-BR') : '',
      t.retreader ?? '',
    ]);

    const rows = list.map((t) => {
      const pct = lifePercent(t);
      const rounded = pct == null ? null : Math.round(pct);
      return {
        Código: t.code,
        Modelo: t.model ?? '',
        Status: STATUS_LABEL[t.status],
        Equipamento: t.equipment?.code ?? '',
        'Modelo equipamento': t.equipment?.model ?? '',
        Posição: t.position ?? '',
        'Profundidade inicial (mm)': t.initial_depth ?? '',
        'Profundidade atual (mm)': t.latest_depth ?? '',
        'Desgaste (mm)':
          t.initial_depth != null && t.latest_depth != null
            ? Number((t.initial_depth - t.latest_depth).toFixed(2))
            : '',
        'Vida útil (%)': rounded ?? '',
        'Horímetro inicial': t.initial_hour_meter ?? '',
        'Montado em': t.mounted_at ? new Date(t.mounted_at).toLocaleDateString('pt-BR') : '',
        Recapadora: t.retreader ?? '',
      };
    });

    return {
      head,
      body,
      sheets: [{ name: 'Pneus', rows }],
      subtitle: `${list.length} pneu(s) · Status: ${v.status === 'todos' ? 'todos' : STATUS_LABEL[v.status as Tire['status']]}`,
      progressColumn: 7,
    };
  };



  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Controle de Pneus</h1>
          <p className="text-muted-foreground">Gerenciamento de pneus e controle de desgaste</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <ReportExportDialog
            title="Relatório de Pneus"
            description="Filtre os pneus antes de exportar em PDF ou Excel."
            fileName="pneus"
            filters={tireFilters}
            buildData={buildTireReport}
          />


          <Button variant="outline" onClick={() => setShowViewer(true)}>
            <Rotate3d className="w-4 h-4 mr-2" />
            Reach Stacker · 360°
          </Button>
          <Button variant="outline" onClick={() => setShowDiagram(true)}>
            <Info className="w-4 h-4 mr-2" />
            Diagrama de Posições
          </Button>
          {isAdmin && (
            <Button onClick={() => setShowForm(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Novo Pneu
            </Button>
          )}
        </div>
      </div>

      {/* Stats */}
      <TireStats stats={stats} />

      {/* List */}
      <TireList
        tires={tires}
        isLoading={isLoading}
        isAdmin={isAdmin}
        onEdit={handleEdit}
        onDelete={deleteTire}
        onView={handleView}
      />

      {/* Form Dialog */}
      <TireForm
        open={showForm}
        onOpenChange={handleCloseForm}
        onSubmit={selectedTire ? handleUpdate : handleCreate}
        tire={selectedTire}
      />

      {/* Details Dialog */}
      <TireDetails
        open={showDetails}
        onOpenChange={handleCloseDetails}
        tire={selectedTire}
        isAdmin={isAdmin}
      />

      {/* Position Diagram Dialog */}
      <Dialog open={showViewer} onOpenChange={setShowViewer}>
        <DialogContent className="max-h-[calc(100dvh-1rem)] w-[calc(100%-1rem)] max-w-4xl overflow-hidden p-4 sm:p-6" aria-describedby={undefined}>
          <DialogHeader>
            <DialogTitle className="pr-8">Visualização do equipamento</DialogTitle>
          </DialogHeader>
          <EquipmentViewer images={reachStackerImages} equipmentName="Kalmar Reach Stacker" />
        </DialogContent>
      </Dialog>
      <TirePositionDiagram
        open={showDiagram}
        onOpenChange={setShowDiagram}
      />
    </div>
  );
};

export default TireManagement;
