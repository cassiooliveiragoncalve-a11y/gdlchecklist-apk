import { useState } from 'react';
import { AlertTriangle, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { EquipmentContract, EquipmentContractInput } from '@/hooks/useEquipmentContracts';
import { FranchiseUsage, formatBRL, formatH } from '@/lib/franchiseMetrics';

interface Props {
  equipmentId: string;
  equipmentCode: string;
  contract: EquipmentContract | null;
  usage: FranchiseUsage | null;
  canEdit: boolean;
  onSave: (input: EquipmentContractInput) => Promise<unknown>;
}

const FranchiseCell = ({ equipmentId, equipmentCode, contract, usage, canEdit, onSave }: Props) => {
  const [open, setOpen] = useState(false);
  const [hours, setHours] = useState(String(contract?.monthly_franchise_hours ?? 220));
  const [day, setDay] = useState(String(contract?.cycle_start_day ?? 1));
  const [rate, setRate] = useState(String(contract?.extra_hour_rate ?? 0));
  const [value, setValue] = useState(contract?.equipment_value != null ? String(contract.equipment_value) : '');
  const [saving, setSaving] = useState(false);

  const syncFromContract = () => {
    setHours(String(contract?.monthly_franchise_hours ?? 220));
    setDay(String(contract?.cycle_start_day ?? 1));
    setRate(String(contract?.extra_hour_rate ?? 0));
    setValue(contract?.equipment_value != null ? String(contract.equipment_value) : '');
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await onSave({
        equipment_id: equipmentId,
        monthly_franchise_hours: Number(String(hours).replace(',', '.')) || 0,
        cycle_start_day: Math.min(Math.max(Number(day) || 1, 1), 30),
        extra_hour_rate: Number(String(rate).replace(',', '.')) || 0,
        equipment_value: value.trim() === '' ? null : Number(String(value).replace(',', '.')) || 0,
      });
      setOpen(false);
    } finally {
      setSaving(false);
    }
  };

  const pct = usage?.usedPct ?? null;
  const clamped = pct === null ? 0 : Math.min(100, Math.max(0, pct));
  const over = (usage?.excessHours || 0) > 0;
  const barColor = over ? 'bg-destructive' : clamped >= 85 ? 'bg-accent' : 'bg-safety-green';

  return (
    <div className="flex items-center gap-2 min-w-[190px]" onClick={(e) => e.stopPropagation()}>
      <div className="flex-1">
        {contract ? (
          <>
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div className={`h-full rounded-full ${barColor}`} style={{ width: `${clamped}%` }} />
            </div>
            <div className="text-[11px] mt-1 flex items-center gap-1 whitespace-nowrap">
              <span className={over ? 'text-destructive font-semibold' : ''}>
                {formatH(usage?.hoursUsed ?? 0)} / {formatH(contract.monthly_franchise_hours)}
              </span>
              {over && <span className="text-destructive">(+{formatH(usage?.excessHours)} · {formatBRL(usage?.extraCost)})</span>}
              {usage?.inconsistent && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <AlertTriangle className="w-3 h-3 text-accent" />
                    </TooltipTrigger>
                    <TooltipContent>
                      Leitura de horímetro menor que a anterior neste ciclo — verificar possível erro de preenchimento,
                      reset ou troca de horímetro.
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
          </>
        ) : (
          <span className="text-[11px] text-muted-foreground">Sem franquia configurada</span>
        )}
      </div>

      <Popover
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (o) syncFromContract();
        }}
      >
        <PopoverTrigger asChild>
          <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0">
            <Settings2 className="w-3.5 h-3.5" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 space-y-3" align="end">
          <div>
            <p className="text-sm font-semibold">Configuração da franquia</p>
            <p className="text-xs text-muted-foreground">{equipmentCode}</p>
            {usage && <p className="text-xs text-muted-foreground mt-1">Ciclo atual: {usage.cycle.label}</p>}
          </div>

          <div className="space-y-2">
            <div>
              <Label className="text-xs">Franquia mensal (h)</Label>
              <Input value={hours} onChange={(e) => setHours(e.target.value)} inputMode="decimal" disabled={!canEdit} />
            </div>
            <div>
              <Label className="text-xs">Dia de início do ciclo (1-30)</Label>
              <Input value={day} onChange={(e) => setDay(e.target.value)} inputMode="numeric" disabled={!canEdit} />
            </div>
            <div>
              <Label className="text-xs">Valor da hora extra (R$)</Label>
              <Input value={rate} onChange={(e) => setRate(e.target.value)} inputMode="decimal" disabled={!canEdit} />
            </div>
            <div>
              <Label className="text-xs">Valor do equipamento (R$)</Label>
              <Input value={value} onChange={(e) => setValue(e.target.value)} inputMode="decimal" disabled={!canEdit} />
            </div>
          </div>

          {usage && contract && (
            <div className="text-xs text-muted-foreground space-y-0.5">
              <p>Horímetro inicial do ciclo: {usage.firstReading ?? '—'}</p>
              <p>Horímetro atual: {usage.lastReading ?? '—'}</p>
              <p>Horas no ciclo: {formatH(usage.hoursUsed)}</p>
              {usage.excessHours > 0 && <p className="text-destructive">Excedente: +{formatH(usage.excessHours)} = {formatBRL(usage.extraCost)}</p>}
            </div>
          )}

          {canEdit ? (
            <Button className="w-full" size="sm" onClick={handleSave} disabled={saving}>
              {saving ? 'Salvando...' : 'Salvar'}
            </Button>
          ) : (
            <p className="text-xs text-muted-foreground">Somente administradores e gestores podem editar.</p>
          )}
        </PopoverContent>
      </Popover>
    </div>
  );
};

export default FranchiseCell;
