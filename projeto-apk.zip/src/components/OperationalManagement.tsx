import { useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import {
  Activity, AlertTriangle, ArrowUpDown, ClipboardCheck, Clock, Gauge, RotateCcw, ShieldCheck, Truck, Wrench,
} from 'lucide-react';
import {
  Bar, BarChart, CartesianGrid, Legend, Line, ComposedChart,
  ResponsiveContainer, Tooltip as RTooltip, XAxis, YAxis,
} from 'recharts';

import { useEquipment } from '@/hooks/useEquipment';
import { useServiceOrders } from '@/hooks/useServiceOrders';
import { useHourMeterReadings } from '@/hooks/useHourMeterReadings';
import { useEquipmentContracts } from '@/hooks/useEquipmentContracts';
import { useChecklists } from '@/hooks/useChecklists';
import { useAuth } from '@/hooks/useSupabaseAuth';
import FranchiseCell from '@/components/operational/FranchiseCell';
import ReportExportDialog, { ReportData, ReportFilterDef, ReportFilterValues } from '@/components/reports/ReportExportDialog';
import { computeFranchiseUsage, formatBRL } from '@/lib/franchiseMetrics';
import { MAINTENANCE_TYPE_LABELS, MaintenanceType, STATUS_LABELS } from '@/types/serviceOrder';
import {
  Bucket, EquipmentMetrics, MONTH_LABELS, OperationalFilters, PeriodMode, buildBuckets,
  buildRangeBuckets, buildTodayBuckets,
  computeOperationalMetrics, equipmentBusinessUnit, equipmentCostCenter,
  formatHours, formatMtbf, formatPct,
} from '@/lib/operationalMetrics';



type Unit = 'horas' | 'pct';
type SortKey = 'code' | 'availabilityPct' | 'unavailabilityPct' | 'idleHours' | 'mtbfHours';

const OperationalManagement = () => {
  const { equipments, isLoading: loadingEq } = useEquipment();
  const { serviceOrders, isLoading: loadingOs } = useServiceOrders();
  const { readings, isLoading: loadingHm } = useHourMeterReadings();
  const { checklistRecords, isLoading: loadingChecklists } = useChecklists();
  const { getContract, saveContract } = useEquipmentContracts();
  const { user } = useAuth();
  const canEditContract = user?.profile === 'admin' || user?.profile === 'gestor';

  // Leituras de horímetro agrupadas por equipamento (id ou código) — reuso dos checklists
  const readingsByEquipment = useMemo(() => {
    const map = new Map<string, typeof readings>();
    readings.forEach((r) => {
      const keys = [r.equipmentId, r.equipmentCode ? `code:${r.equipmentCode}` : null].filter(Boolean) as string[];
      keys.forEach((k) => {
        const list = map.get(k) || [];
        list.push(r);
        map.set(k, list);
      });
    });
    return map;
  }, [readings]);


  const currentYear = new Date().getFullYear();
  const [filters, setFilters] = useState<OperationalFilters>({
    costCenter: 'all',
    businessUnit: 'all',
    year: String(currentYear),
    month: 'all',
    maintenanceType: 'all',
  });
  const todayIso = new Date().toISOString().slice(0, 10);
  const [periodMode, setPeriodMode] = useState<PeriodMode>('mensal');
  const [rangeFrom, setRangeFrom] = useState(todayIso);
  const [rangeTo, setRangeTo] = useState(todayIso);
  const [unit, setUnit] = useState<Unit>('pct');
  const [sortKey, setSortKey] = useState<SortKey>('unavailabilityPct');
  const [sortAsc, setSortAsc] = useState(false);
  const [drill, setDrill] = useState<EquipmentMetrics | null>(null);

  const costCenters = useMemo(
    () => Array.from(new Set(equipments.map(equipmentCostCenter))).sort(),
    [equipments]
  );
  const businessUnits = useMemo(
    () => Array.from(new Set(equipments.map(equipmentBusinessUnit))).sort(),
    [equipments]
  );
  const availableYears = useMemo(() => {
    const years = new Set<number>([currentYear]);
    serviceOrders.forEach((os) => years.add(new Date(os.data_hora_abertura).getFullYear()));
    readings.forEach((r) => years.add(new Date(r.timestamp).getFullYear()));
    return Array.from(years).sort((a, b) => a - b);
  }, [serviceOrders, readings, currentYear]);

  const buckets: Bucket[] = useMemo(() => {
    if (periodMode === 'hoje') return buildTodayBuckets();
    if (periodMode === 'personalizado') return buildRangeBuckets(rangeFrom, rangeTo);
    return buildBuckets(filters.year, filters.month, availableYears);
  }, [periodMode, rangeFrom, rangeTo, filters.year, filters.month, availableYears]);

  const result = useMemo(
    () => computeOperationalMetrics(equipments, serviceOrders, readings, filters, buckets),
    [equipments, serviceOrders, readings, filters, buckets]
  );

  const { totals, monthly } = result;
  const isLoading = loadingEq || loadingOs || loadingHm || loadingChecklists;

  const windowStart = buckets.length ? buckets[0].start : Date.now();
  const windowEnd = buckets.length ? buckets[buckets.length - 1].end : Date.now();

  const filteredChecklistsCount = useMemo(() => {
    return checklistRecords.filter((record) => {
      const t = new Date(record.timestamp).getTime();
      if (t < windowStart || t >= windowEnd) return false;

      const eq = equipments.find(
        (e) => e.id === record.equipmentId || e.code === record.equipmentCode
      );
      if (!eq) return false;

      if (filters.costCenter !== 'all' && equipmentCostCenter(eq) !== filters.costCenter) return false;
      if (filters.businessUnit !== 'all' && equipmentBusinessUnit(eq) !== filters.businessUnit) return false;

      return true;
    }).length;
  }, [checklistRecords, windowStart, windowEnd, equipments, filters.costCenter, filters.businessUnit]);

  // Último checklist por equipamento dentro do período selecionado (id ou código)
  const lastChecklistByEquipment = useMemo(() => {
    const map = new Map<string, { timestamp: string; operatorName?: string }>();
    checklistRecords.forEach((record: any) => {
      const t = new Date(record.timestamp).getTime();
      if (Number.isNaN(t) || t < windowStart || t >= windowEnd) return;
      const keys = [record.equipmentId, record.equipmentCode ? `code:${record.equipmentCode}` : null]
        .filter(Boolean) as string[];
      keys.forEach((k) => {
        const prev = map.get(k);
        if (!prev || new Date(prev.timestamp).getTime() < t) {
          map.set(k, { timestamp: record.timestamp, operatorName: record.operatorName });
        }
      });
    });
    return map;
  }, [checklistRecords, windowStart, windowEnd]);

  // Ociosidade = Σ (horímetro final − horímetro inicial) dos checklists finalizados no período
  const sessionHoursByEquipment = useMemo(() => {
    const map = new Map<string, number>();
    checklistRecords.forEach((record: any) => {
      if (record.sessionStatus !== 'finalizado') return;
      const start = Number(record.hourMeterStart);
      const end = Number(record.hourMeterEnd);
      if (!Number.isFinite(start) || !Number.isFinite(end)) return;
      const delta = end - start;
      if (!(delta > 0)) return;
      const ref = record.endedAt || record.timestamp;
      const t = new Date(ref).getTime();
      if (Number.isNaN(t) || t < windowStart || t >= windowEnd) return;
      const keys = [record.equipmentId, record.equipmentCode ? `code:${record.equipmentCode}` : null]
        .filter(Boolean) as string[];
      keys.forEach((k) => map.set(k, (map.get(k) || 0) + delta));
    });
    return map;
  }, [checklistRecords, windowStart, windowEnd]);

  const idleForEquipment = (id: string, code: string): number | null => {
    const v = sessionHoursByEquipment.get(id) ?? sessionHoursByEquipment.get(`code:${code}`);
    return v === undefined ? null : v;
  };

  // Sessões operacionais (checklists encerrados) agrupadas por equipamento + dia
  const sessionGroups = useMemo(() => {
    const rows = (checklistRecords as any[])
      .filter((r) => {
        if (r.sessionStatus !== 'finalizado') return false;
        if (r.hourMeterStart == null || r.hourMeterEnd == null) return false;
        const t = new Date(r.startedAt || r.timestamp).getTime();
        if (Number.isNaN(t) || t < windowStart || t >= windowEnd) return false;
        const eq = equipments.find((e) => e.id === r.equipmentId || e.code === r.equipmentCode);
        if (!eq) return false;
        if (filters.costCenter !== 'all' && equipmentCostCenter(eq) !== filters.costCenter) return false;
        if (filters.businessUnit !== 'all' && equipmentBusinessUnit(eq) !== filters.businessUnit) return false;
        return true;
      })
      .sort(
        (a, b) =>
          new Date(b.startedAt || b.timestamp).getTime() - new Date(a.startedAt || a.timestamp).getTime()
      );

    const map = new Map<string, { key: string; date: string; equipmentCode: string; rows: any[]; total: number }>();
    rows.forEach((r) => {
      const date = new Date(r.startedAt || r.timestamp).toLocaleDateString('pt-BR');
      const key = `${r.equipmentCode}|${date}`;
      if (!map.has(key)) map.set(key, { key, date, equipmentCode: r.equipmentCode, rows: [], total: 0 });
      const g = map.get(key)!;
      g.rows.push(r);
      g.total += Number(r.workedHours ?? Number(r.hourMeterEnd) - Number(r.hourMeterStart)) || 0;
    });
    return Array.from(map.values());
  }, [checklistRecords, windowStart, windowEnd, equipments, filters.costCenter, filters.businessUnit]);



  const trendData = monthly.map((m) => ({
    label: m.label,
    monthIndex: m.monthIndex,
    Disponibilidade: unit === 'pct' ? Number(m.availabilityPct.toFixed(1)) : Number(m.availableHours.toFixed(1)),
    Indisponibilidade: unit === 'pct' ? Number(m.unavailabilityPct.toFixed(1)) : Number(m.downtimeHours.toFixed(1)),
    'Tempo Ocioso': m.idleHours === null ? null : unit === 'pct' ? Number((m.idlePct || 0).toFixed(1)) : Number(m.idleHours.toFixed(1)),
  }));

  const ranking = useMemo(() => {
    const list = [...result.equipmentMetrics];
    list.sort((a, b) => {
      const get = (m: EquipmentMetrics) => {
        switch (sortKey) {
          case 'code': return m.equipment.code;
          case 'idleHours': return idleForEquipment(m.equipment.id, m.equipment.code) ?? -1;
          case 'mtbfHours': return m.mtbfHours ?? -1;
          default: return (m as any)[sortKey] as number;
        }
      };
      const va = get(a);
      const vb = get(b);
      if (typeof va === 'string' || typeof vb === 'string') {
        return sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
      }
      return sortAsc ? (va as number) - (vb as number) : (vb as number) - (va as number);
    });
    return list;
  }, [result.equipmentMetrics, sortKey, sortAsc, sessionHoursByEquipment]);

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) setSortAsc((v) => !v);
    else {
      setSortKey(key);
      setSortAsc(false);
    }
  };

  const clearFilters = () => {
    setPeriodMode('mensal');
    setRangeFrom(todayIso);
    setRangeTo(todayIso);
    setFilters({ costCenter: 'all', businessUnit: 'all', year: String(currentYear), month: 'all', maintenanceType: 'all' });
  };

  const valueForUnit = (hours: number, percent: number | null) =>
    unit === 'pct' ? formatPct(percent) : formatHours(hours);

  const cards = [
    { title: 'Equipamentos', tooltip: 'Quantidade total de equipamentos considerados nos filtros atuais', value: String(totals.equipmentCount), icon: Truck, color: 'text-primary', bg: 'bg-primary/10' },
    { title: 'Checklists Feitos', tooltip: 'Quantidade total de checklists realizados no período selecionado', value: String(filteredChecklistsCount), icon: ClipboardCheck, color: 'text-primary', bg: 'bg-primary/10' },
    { title: 'Disponibilidade', tooltip: 'Máquina à disposição do operador', value: valueForUnit(totals.availableHours, totals.availabilityPct), icon: ShieldCheck, color: 'text-safety-green', bg: 'bg-safety-green/10' },
    { title: 'Indisponibilidade', tooltip: 'equipamento parado por falha, manutenção ou outro motivo (considerando os filtros atuais)', value: valueForUnit(totals.downtimeHours, totals.unavailabilityPct), icon: AlertTriangle, color: 'text-destructive', bg: 'bg-destructive/10' },
    { title: 'Horas Trabalhadas', tooltip: 'Horímetro inicial - horímetro final (excluindo a indisponibilidade)', value: totals.idleHours === null ? '—' : valueForUnit(totals.idleHours, totals.idlePct), icon: Clock, color: 'text-safety-orange', bg: 'bg-safety-orange/10' },
    { title: 'Equipamentos Parados', tooltip: 'Equipamentos indisponíveis e ordens de serviço em aberto', value: '', icon: Activity, color: 'text-destructive', bg: 'bg-destructive/10', multi: true, values: [{ label: 'Equipamentos indisponíveis', value: String(totals.currentlyDown) }] },
    { title: 'TMP', tooltip: 'Tempo total de manutenção no período', value: formatHours(totals.downtimeHours), icon: Gauge, color: 'text-primary', bg: 'bg-primary/10' },
    { title: 'TMF', tooltip: 'Tempo médio entre falhas (corretiva ou avaria)', value: formatMtbf(totals.mtbfHours), icon: ShieldCheck, color: 'text-industrial-blue', bg: 'bg-primary/10' },
  ];

  const reportFilters: ReportFilterDef[] = [
    {
      key: 'businessUnit',
      label: 'Unidade de Negócio',
      type: 'select',
      options: [{ value: 'all', label: 'Todas' }, ...businessUnits.map((u) => ({ value: u, label: u }))],
    },
    {
      key: 'costCenter',
      label: 'Centro de Custo',
      type: 'select',
      options: [{ value: 'all', label: 'Todos' }, ...costCenters.map((c) => ({ value: c, label: c }))],
    },
    {
      key: 'checklist',
      label: 'Checklist no período',
      type: 'select',
      options: [
        { value: 'all', label: 'Todos' },
        { value: 'feito', label: 'Feito' },
        { value: 'nao', label: 'Não feito' },
      ],
    },
    {
      key: 'sort',
      label: 'Ordenar por',
      type: 'select',
      options: [
        { value: 'unavailabilityPct', label: 'Indisponibilidade' },
        { value: 'availabilityPct', label: 'Disponibilidade' },
        { value: 'idleHours', label: 'Horas trabalhadas' },
        { value: 'code', label: 'Código' },
      ],
    },
  ];

  const periodLabelText = () =>
    periodMode === 'hoje'
      ? `Hoje (${new Date().toLocaleDateString('pt-BR')})`
      : periodMode === 'personalizado'
        ? `${new Date(rangeFrom).toLocaleDateString('pt-BR')} a ${new Date(rangeTo).toLocaleDateString('pt-BR')}`
        : `${filters.month === 'all' ? 'Ano todo' : MONTH_LABELS[Number(filters.month)]} / ${filters.year === 'all' ? 'Todos' : filters.year}`;

  const buildReportData = (v: ReportFilterValues): ReportData => {
    const periodLabel = periodLabelText();

    const list = result.equipmentMetrics.filter((m) => {
      if (v.businessUnit !== 'all' && m.businessUnit !== v.businessUnit) return false;
      if (v.costCenter !== 'all' && m.costCenter !== v.costCenter) return false;
      const done = !!(
        lastChecklistByEquipment.get(m.equipment.id) ||
        lastChecklistByEquipment.get(`code:${m.equipment.code}`)
      );
      if (v.checklist === 'feito' && !done) return false;
      if (v.checklist === 'nao' && done) return false;
      return true;
    });

    list.sort((a, b) => {
      if (v.sort === 'code') return a.equipment.code.localeCompare(b.equipment.code);
      if (v.sort === 'idleHours') {
        return (idleForEquipment(b.equipment.id, b.equipment.code) ?? -1) -
          (idleForEquipment(a.equipment.id, a.equipment.code) ?? -1);
      }
      return (b as any)[v.sort] - (a as any)[v.sort];
    });

    const rows = list.map((m) => {
      const contract = getContract(m.equipment.id);
      const eqReadings =
        readingsByEquipment.get(m.equipment.id) || readingsByEquipment.get(`code:${m.equipment.code}`) || [];
      const usage = computeFranchiseUsage(eqReadings, contract);
      const lastCk =
        lastChecklistByEquipment.get(m.equipment.id) ||
        lastChecklistByEquipment.get(`code:${m.equipment.code}`);
      const worked = idleForEquipment(m.equipment.id, m.equipment.code);
      return {
        Equipamento: m.equipment.code,
        Disponibilidade: formatPct(m.availabilityPct),
        Indisponibilidade: formatPct(m.unavailabilityPct),
        'Horas Trabalhadas': worked === null ? '—' : formatHours(worked),
        TMF: formatMtbf(m.mtbfHours),
        Checklist: lastCk ? 'Feito' : 'Não feito',
        'Último Checklist': lastCk ? new Date(lastCk.timestamp).toLocaleDateString('pt-BR') : '—',
        Franquia: contract ? `${formatHours(usage?.hoursUsed ?? 0)} / ${formatHours(contract.monthly_franchise_hours)}` : '—',
        'Valor do Equipamento': contract?.equipment_value != null ? formatBRL(contract.equipment_value) : '—',
        Tipo: m.type,
        'Centro de Custo': m.costCenter,
        Unidade: m.businessUnit,
      };
    });

    const head = Object.keys(
      rows[0] ?? {
        Equipamento: '', Disponibilidade: '', Indisponibilidade: '', 'Horas Trabalhadas': '', TMF: '',
        Checklist: '', 'Último Checklist': '', Franquia: '', 'Valor do Equipamento': '', Tipo: '',
        'Centro de Custo': '', Unidade: '',
      },
    );

    return {
      head,
      body: rows.map((r) => head.map((h) => (r as any)[h])),
      sheets: [{ name: 'Gestão Operacional', rows }],
      subtitle: `Período: ${periodLabel} · ${rows.length} equipamento(s)`,
    };
  };

  // --- Relatório: Equipamento × Operador ---
  const operatorReportFilters: ReportFilterDef[] = [
    { key: 'equipment', label: 'Equipamento (código)', type: 'text', placeholder: 'Ex.: EMP-742' },
    { key: 'operator', label: 'Operador', type: 'text', placeholder: 'Nome do operador' },
    { key: 'minHours', label: 'Horas mínimas', type: 'number', placeholder: '0' },
  ];

  const buildOperatorReport = (v: ReportFilterValues): ReportData => {
    const eq = (v.equipment || '').trim().toLowerCase();
    const op = (v.operator || '').trim().toLowerCase();
    const minH = Number(String(v.minHours || '').replace(',', '.')) || 0;

    const rows = sessionGroups.flatMap((g) =>
      g.rows
        .map((r: any) => {
          const hours = Number(r.workedHours ?? Number(r.hourMeterEnd) - Number(r.hourMeterStart)) || 0;
          return {
            Equipamento: g.equipmentCode,
            Data: g.date,
            Operador: r.operatorName ?? '—',
            Início: new Date(r.startedAt || r.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            Final: r.endedAt ? new Date(r.endedAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '—',
            'Horímetro Inicial': Number(r.hourMeterStart).toFixed(1),
            'Horímetro Final': Number(r.hourMeterEnd).toFixed(1),
            Horas: Number(hours.toFixed(1)),
            'Total do Equipamento no Dia': Number(g.total.toFixed(1)),
          };
        })
        .filter((r) => {
          if (eq && !r.Equipamento.toLowerCase().includes(eq)) return false;
          if (op && !String(r.Operador).toLowerCase().includes(op)) return false;
          if (minH && r.Horas < minH) return false;
          return true;
        }),
    );

    const head = [
      'Equipamento', 'Data', 'Operador', 'Início', 'Final',
      'Horímetro Inicial', 'Horímetro Final', 'Horas', 'Total do Equipamento no Dia',
    ];

    return {
      head,
      body: rows.map((r) => head.map((h) => (r as any)[h])),
      sheets: [{ name: 'Equipamento x Operador', rows }],
      subtitle: `Período: ${periodLabelText()} · ${rows.length} sessão(ões)`,
    };
  };

  // --- Relatório: Tendência ---
  const buildTrendReport = (): ReportData => {
    const suffix = unit === 'pct' ? '%' : 'h';
    const rows = trendData.map((t) => ({
      Período: t.label,
      [`Disponibilidade (${suffix})`]: t.Disponibilidade,
      [`Indisponibilidade (${suffix})`]: t.Indisponibilidade,
      [`Horas Trabalhadas (${suffix})`]: t['Tempo Ocioso'] === null ? '—' : t['Tempo Ocioso'],
    }));
    const head = [
      'Período',
      `Disponibilidade (${suffix})`,
      `Indisponibilidade (${suffix})`,
      `Horas Trabalhadas (${suffix})`,
    ];
    return {
      head,
      body: rows.map((r) => head.map((h) => (r as any)[h])),
      sheets: [{ name: 'Tendencia', rows }],
      subtitle: `Período: ${periodLabelText()} · unidade: ${unit === 'pct' ? 'percentual' : 'horas'}`,
    };
  };

  return (
    <div className="space-y-5">
      {/* Cabeçalho */}
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground">GESTÃO OPERACIONAL</h1>
        <p className="text-muted-foreground text-sm">Disponibilidade e Performance de Equipamentos</p>
      </div>


      {/* Filtros */}
      <Card className="border-primary/20">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-3 items-end">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Unidade de Negócio</label>
              <Select value={filters.businessUnit} onValueChange={(v) => setFilters((f) => ({ ...f, businessUnit: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="all">Todas</SelectItem>
                  {businessUnits.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Centro de Custo</label>
              <Select value={filters.costCenter} onValueChange={(v) => setFilters((f) => ({ ...f, costCenter: v }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="all">Todos</SelectItem>
                  {costCenters.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Período</label>
              <Select value={periodMode} onValueChange={(v) => setPeriodMode(v as PeriodMode)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="mensal">Ano / Mês</SelectItem>
                  <SelectItem value="hoje">Hoje</SelectItem>
                  <SelectItem value="personalizado">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {periodMode === 'mensal' && (
              <>
                <div>
                  <label className="text-xs font-medium text-muted-foreground">Ano</label>
                  <Select value={filters.year} onValueChange={(v) => setFilters((f) => ({ ...f, year: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">Todos</SelectItem>
                      {availableYears.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground">Mês</label>
                  <Select value={filters.month} onValueChange={(v) => setFilters((f) => ({ ...f, month: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-background z-50">
                      <SelectItem value="all">Todos</SelectItem>
                      {MONTH_LABELS.map((m, i) => <SelectItem key={m} value={String(i)}>{m}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}

            {periodMode === 'personalizado' && (
              <>
                <div>
                  <label className="text-xs font-medium text-muted-foreground">De</label>
                  <Input type="date" value={rangeFrom} max={rangeTo || todayIso} onChange={(e) => setRangeFrom(e.target.value)} />
                </div>
                <div>
                  <label className="text-xs font-medium text-muted-foreground">Até</label>
                  <Input type="date" value={rangeTo} min={rangeFrom} max={todayIso} onChange={(e) => setRangeTo(e.target.value)} />
                </div>
              </>
            )}

            {periodMode === 'hoje' && (
              <div className="lg:col-span-2 flex items-end">
                <p className="text-xs text-muted-foreground">
                  Mostrando dados de hoje ({new Date().toLocaleDateString('pt-BR')}) até o momento.
                </p>
              </div>
            )}

            <div>
              <label className="text-xs font-medium text-muted-foreground">Unidade de Medida</label>
              <Tabs value={unit} onValueChange={(v) => setUnit(v as Unit)}>
                <TabsList className="w-full">
                  <TabsTrigger value="horas" className="flex-1">HORAS</TabsTrigger>
                  <TabsTrigger value="pct" className="flex-1">%</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            <Button variant="outline" onClick={clearFilters} className="gap-2">
              <RotateCcw className="w-4 h-4" /> Limpar filtros
            </Button>
          </div>

          {(filters.maintenanceType !== 'all' || (periodMode === 'mensal' && filters.month !== 'all')) && (
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <span className="text-xs text-muted-foreground">Filtros cruzados ativos:</span>
              {filters.maintenanceType !== 'all' && (
                <Badge variant="secondary" className="cursor-pointer" onClick={() => setFilters((f) => ({ ...f, maintenanceType: 'all' }))}>
                  {MAINTENANCE_TYPE_LABELS[filters.maintenanceType as MaintenanceType]} ✕
                </Badge>
              )}
              {periodMode === 'mensal' && filters.month !== 'all' && (
                <Badge variant="secondary" className="cursor-pointer" onClick={() => setFilters((f) => ({ ...f, month: 'all' }))}>
                  {MONTH_LABELS[Number(filters.month)]} ✕
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Cards */}
      <TooltipProvider delayDuration={200}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {cards.map((c) => (
            <Tooltip key={c.title}>
              <TooltipTrigger asChild>
                <Card className="cursor-help">
                  <CardContent className="p-4 flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg ${c.bg} flex items-center justify-center flex-shrink-0`}>
                      <c.icon className={`w-5 h-5 ${c.color}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-muted-foreground truncate">{c.title}</p>
                      {c.multi && c.values ? (
                        <div className="space-y-0.5 mt-0.5">
                          {c.values.map((v) => (
                            <p key={v.label} className="text-sm sm:text-base font-bold text-foreground leading-tight">
                              {v.value} <span className="text-[10px] sm:text-xs font-normal text-muted-foreground">{v.label}</span>
                            </p>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xl sm:text-2xl font-bold text-foreground">{c.value}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="max-w-xs text-xs">
                <p>{c.tooltip}</p>
              </TooltipContent>
            </Tooltip>
          ))}
        </div>
      </TooltipProvider>



      {/* Ranking */}
      <Card>
        <CardHeader className="pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-base">PERFORMANCE DOS EQUIPAMENTOS</CardTitle>
          <ReportExportDialog
            title="Relatório — Performance dos Equipamentos"
            description="Mantém os filtros do cabeçalho (período, unidade e centro de custo)."
            fileName="performance_equipamentos"
            filters={reportFilters}
            buildData={buildReportData}
            buttonSize="sm"
          />
        </CardHeader>
        <CardContent className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                {([
                  ['code', 'Equipamento'],
                  ['availabilityPct', 'Disp. %'],
                  ['unavailabilityPct', 'Indisp. %'],
                  ['idleHours', 'Δ Horas Trabalhadas'],
                  ['mtbfHours', 'TMF'],
                ] as Array<[SortKey, string]>).map(([key, label]) => (
                  <TableHead key={key} className="cursor-pointer whitespace-nowrap" onClick={() => toggleSort(key)}>
                    <span className="inline-flex items-center gap-1">{label} <ArrowUpDown className="w-3 h-3" /></span>
                  </TableHead>
                ))}
                <TableHead className="whitespace-nowrap">Checklist</TableHead>
                <TableHead className="whitespace-nowrap">Franquia</TableHead>
                <TableHead className="whitespace-nowrap">Valor do Equipamento</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>C. Custo</TableHead>
                <TableHead>Unidade</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ranking.slice(0, 100).map((m) => {
                const contract = getContract(m.equipment.id);
                const eqReadings =
                  readingsByEquipment.get(m.equipment.id) || readingsByEquipment.get(`code:${m.equipment.code}`) || [];
                const usage = computeFranchiseUsage(eqReadings, contract);
                const lastCk =
                  lastChecklistByEquipment.get(m.equipment.id) ||
                  lastChecklistByEquipment.get(`code:${m.equipment.code}`);
                return (
                <TableRow key={m.equipment.id} className="cursor-pointer" onClick={() => setDrill(m)}>
                  <TableCell className="font-medium whitespace-nowrap">{m.equipment.code}</TableCell>
                  <TableCell className="text-safety-green font-semibold">{formatPct(m.availabilityPct)}</TableCell>
                  <TableCell className="text-destructive">{formatPct(m.unavailabilityPct)}</TableCell>
                  <TableCell>{(() => { const v = idleForEquipment(m.equipment.id, m.equipment.code); return v === null ? '—' : formatHours(v); })()}</TableCell>
                  <TableCell>{formatMtbf(m.mtbfHours)}</TableCell>
                  <TableCell className="whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span className="inline-flex items-center gap-1.5 text-xs">
                            <span
                              className={`w-2.5 h-2.5 rounded-full ${lastCk ? 'bg-safety-green' : 'bg-destructive'}`}
                            />
                            {lastCk ? 'Feito' : 'Não feito'}
                          </span>
                        </TooltipTrigger>
                        <TooltipContent>
                          {lastCk ? (
                            <div className="text-xs space-y-0.5">
                              <p className="font-semibold">Checklist</p>
                              <p>Status: Feito</p>
                              <p>Último no período: {new Date(lastCk.timestamp).toLocaleDateString('pt-BR')}</p>
                              <p>Horário: {new Date(lastCk.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</p>
                              {lastCk.operatorName && <p>Responsável: {lastCk.operatorName}</p>}
                            </div>
                          ) : (
                            <div className="text-xs space-y-0.5">
                              <p className="font-semibold">Checklist</p>
                              <p>Status: Não feito</p>
                              <p>Nenhum checklist encontrado no período selecionado.</p>
                            </div>
                          )}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </TableCell>
                  <TableCell>
                    <FranchiseCell
                      equipmentId={m.equipment.id}
                      equipmentCode={m.equipment.code}
                      contract={contract}
                      usage={usage}
                      canEdit={canEditContract}
                      onSave={saveContract}
                    />
                  </TableCell>
                  <TableCell className="whitespace-nowrap text-xs">
                    {contract?.equipment_value != null ? formatBRL(contract.equipment_value) : '—'}
                  </TableCell>
                  <TableCell className="text-xs">{m.type}</TableCell>
                  <TableCell className="text-xs">{m.costCenter}</TableCell>
                  <TableCell className="text-xs">{m.businessUnit}</TableCell>
                </TableRow>
                );
              })}

            </TableBody>
          </Table>
          {!isLoading && ranking.length === 0 && (
            <p className="text-sm text-muted-foreground py-6 text-center">Nenhum equipamento para os filtros selecionados.</p>
          )}
        </CardContent>
      </Card>

      {/* Tendência */}
      <Card>
        <CardHeader className="pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-base">
            TENDÊNCIA DE DISPONIBILIDADE E UTILIZAÇÃO {unit === 'pct' ? '(%)' : '(horas)'}
          </CardTitle>
          <ReportExportDialog
            title="Relatório — Tendência de Disponibilidade e Utilização"
            description="Exporta os dados do gráfico conforme os filtros do cabeçalho."
            fileName="tendencia_disponibilidade"
            filters={[]}
            buildData={buildTrendReport}
            orientation="portrait"
            buttonSize="sm"
          />
        </CardHeader>
        <CardContent>
          {trendData.length === 0 ? (
            <p className="text-sm text-muted-foreground py-10 text-center">Sem período selecionado.</p>
          ) : (
            <ResponsiveContainer width="100%" height={320}>
              <ComposedChart data={trendData} onClick={(e: any) => {
                if (periodMode !== 'mensal') return;
                const idx = e?.activePayload?.[0]?.payload?.monthIndex;
                if (idx !== undefined) setFilters((f) => ({ ...f, month: String(idx) }));
              }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <RTooltip formatter={(v: any) => (v === null ? '—' : unit === 'pct' ? `${v}%` : `${v} h`)} />
                <Legend />
                <Bar dataKey="Disponibilidade" fill="#16a34a" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Indisponibilidade" fill="hsl(var(--destructive))" radius={[4, 4, 0, 0]} />
                <Line name="Horas Trabalhadas" type="monotone" dataKey="Tempo Ocioso" stroke="#f97316" strokeWidth={2} dot connectNulls />
              </ComposedChart>
            </ResponsiveContainer>
          )}
          <p className="text-xs text-muted-foreground mt-2">Clique em um mês para filtrar todos os indicadores.</p>
        </CardContent>
      </Card>


      {/* Equipamento × Operador */}
      <Card>
        <CardHeader className="pb-2 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Clock className="w-4 h-4" />
            EQUIPAMENTO × OPERADOR
          </CardTitle>
          <ReportExportDialog
            title="Relatório — Equipamento × Operador"
            description="Mantém os filtros do cabeçalho; refine por equipamento, operador ou horas."
            fileName="equipamento_x_operador"
            filters={operatorReportFilters}
            buildData={buildOperatorReport}
            buttonSize="sm"
          />
        </CardHeader>
        <CardContent className="overflow-x-auto space-y-6">
          {sessionGroups.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">
              Nenhum checklist encerrado com horímetro inicial e final neste período.
            </p>
          ) : (
            sessionGroups.map((g) => (
              <div key={g.key} className="space-y-2">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <p className="font-semibold">
                    {g.equipmentCode} <span className="text-muted-foreground font-normal">· {g.date}</span>
                  </p>
                  <Badge variant="secondary">
                    Total do equipamento no dia: {g.total.toFixed(1)} h
                  </Badge>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Operador</TableHead>
                      <TableHead>Início</TableHead>
                      <TableHead>Final</TableHead>
                      <TableHead>Horímetro Inicial</TableHead>
                      <TableHead>Horímetro Final</TableHead>
                      <TableHead>Horas</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {g.rows.map((r: any) => {
                      const hours =
                        Number(r.workedHours ?? Number(r.hourMeterEnd) - Number(r.hourMeterStart)) || 0;
                      return (
                        <TableRow key={r.id}>
                          <TableCell className="font-medium">{r.operatorName}</TableCell>
                          <TableCell>
                            {new Date(r.startedAt || r.timestamp).toLocaleTimeString('pt-BR', {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </TableCell>
                          <TableCell>
                            {r.endedAt
                              ? new Date(r.endedAt).toLocaleTimeString('pt-BR', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                })
                              : '—'}
                          </TableCell>
                          <TableCell>{Number(r.hourMeterStart).toFixed(1)}</TableCell>
                          <TableCell>{Number(r.hourMeterEnd).toFixed(1)}</TableCell>
                          <TableCell className="font-semibold text-primary">{hours.toFixed(1)} h</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            ))
          )}
        </CardContent>
      </Card>



      {/* Nota de cobertura de dados */}
      <Card className="bg-muted/40">
        <CardContent className="p-4 text-xs text-muted-foreground space-y-1">
          <p><strong>Origem dos dados:</strong> cadastro de equipamentos, Ordens de Serviço (abertura/fechamento/tipo) e leituras de horímetro dos checklists. Nenhum dado é digitado novamente.</p>
          <p><strong>Ociosidade</strong> = horas disponíveis − horas efetivamente utilizadas (variação de horímetro). Cobertura atual: {formatPct(totals.idleCoverage)} dos equipamentos possuem leituras suficientes no período; para os demais o valor aparece como “—”.</p>
        </CardContent>
      </Card>

      {/* Drill-down */}
      <Dialog open={!!drill} onOpenChange={(o) => !o && setDrill(null)}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{drill?.equipment.code} — {drill?.type}</DialogTitle>
          </DialogHeader>
          {drill && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  ['Disponibilidade', formatPct(drill.availabilityPct)],
                  ['Indisponibilidade', formatHours(drill.downtimeHours)],
                  ['Ocioso', drill.idleHours === null ? '—' : formatHours(drill.idleHours)],
                  ['TMF', formatMtbf(drill.mtbfHours)],
                  ['Avarias', String(drill.byType.avaria.count)],
                  ['Corretivas', String(drill.byType.corretiva.count)],
                  ['Preventivas', String(drill.byType.preventiva.count)],
                  ['Pneus', String(drill.byType.pneus.count)],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-md border p-2">
                    <p className="text-[11px] text-muted-foreground">{k}</p>
                    <p className="font-semibold text-sm">{v}</p>
                  </div>
                ))}
              </div>
              <div>
                <p className="text-sm font-semibold mb-2">Histórico de OS no período</p>
                <div className="space-y-2">
                  {serviceOrders
                    .filter((os) => os.equipment_id === drill.equipment.id)
                    .slice(0, 20)
                    .map((os) => (
                      <div key={os.id} className="border rounded-md p-2 text-xs flex flex-wrap gap-x-3 gap-y-1">
                        <span className="font-semibold">{os.numero_os}</span>
                        <Badge variant="outline">{MAINTENANCE_TYPE_LABELS[os.tipo_manutencao]}</Badge>
                        <span>{STATUS_LABELS[os.status]}</span>
                        <span>Abertura: {new Date(os.data_hora_abertura).toLocaleString('pt-BR')}</span>
                        {os.data_hora_fechamento && <span>Fechamento: {new Date(os.data_hora_fechamento).toLocaleString('pt-BR')}</span>}
                        <span className="w-full text-muted-foreground">{os.descricao_ocorrencia}</span>
                      </div>
                    ))}
                  {serviceOrders.filter((os) => os.equipment_id === drill.equipment.id).length === 0 && (
                    <p className="text-xs text-muted-foreground">Nenhuma OS registrada para este equipamento.</p>
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OperationalManagement;
