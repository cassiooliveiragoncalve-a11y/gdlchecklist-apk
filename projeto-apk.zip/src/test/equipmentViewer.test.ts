import { describe, expect, it, vi } from 'vitest';
import { EQUIPMENT_ROTATION_INTERVAL, preloadEquipmentImages, adjacentEquipmentView, equipmentSwipeDirection, type EquipmentView } from '../lib/equipmentViewer';

describe('EquipmentViewer navigation', () => {
  it('loops front → right → rear → left → front', () => {
    let view: EquipmentView = 'front';
    const result: EquipmentView[] = [view];
    for (let i = 0; i < 4; i++) {
      view = adjacentEquipmentView(view, 1);
      result.push(view);
    }
    expect(result).toEqual(['front', 'right', 'rear', 'left', 'front']);
  });
  it('loops front → left → rear → right → front', () => {
    let view: EquipmentView = 'front';
    const result: EquipmentView[] = [view];
    for (let i = 0; i < 4; i++) {
      view = adjacentEquipmentView(view, -1);
      result.push(view);
    }
    expect(result).toEqual(['front', 'left', 'rear', 'right', 'front']);
  });
  it('moves to the next view on a left swipe', () => {
    expect(equipmentSwipeDirection(-100, 10)).toBe(1);
  });
  it('moves to the previous view on a right swipe', () => {
    expect(equipmentSwipeDirection(100, 10)).toBe(-1);
  });
  it('ignores taps and vertical scrolling', () => {
    expect(equipmentSwipeDirection(20, 0)).toBeNull();
    expect(equipmentSwipeDirection(70, 100)).toBeNull();
  });
});

describe('EquipmentViewer loading and rotation', () => {
  it('rotates at the requested 2.5 second interval', () => {
    expect(EQUIPMENT_ROTATION_INTERVAL).toBe(2500);
  });

  it('waits for all four images to decode before completing preload', async () => {
    const complete: (() => void)[] = [];
    const sources: string[] = [];
    vi.stubGlobal('Image', class {
      src = '';
      decode() {
        sources.push(this.src);
        return new Promise<void>((resolve) => complete.push(resolve));
      }
    });
    try {
      let ready = false;
      const pending = preloadEquipmentImages({ front: 'front.png', right: 'right.png', rear: 'rear.png', left: 'left.png' }).then(() => { ready = true; });
      expect(sources).toEqual(['front.png', 'right.png', 'rear.png', 'left.png']);
      complete.slice(0, 3).forEach((resolve) => resolve());
      await Promise.resolve();
      expect(ready).toBe(false);
      complete[3]();
      await pending;
      expect(ready).toBe(true);
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('settles failed images so navigation is not locked forever', async () => {
    vi.stubGlobal('Image', class {
      src = '';
      decode() { return this.src === 'broken.png' ? Promise.reject(new Error('failed')) : Promise.resolve(); }
    });
    try {
      expect(await preloadEquipmentImages({ front: 'front.png', right: 'broken.png' })).toEqual({ right: 'broken.png' });
    } finally {
      vi.unstubAllGlobals();
    }
  });
});