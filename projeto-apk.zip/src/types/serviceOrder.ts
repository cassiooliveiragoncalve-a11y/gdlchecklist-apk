export type ServiceOrderStatus = 'aberta' | 'em_manutencao' | 'finalizada' | 'cancelada';
export type MaintenanceType = 'avaria' | 'corretiva' | 'pneus' | 'preventiva';

export interface ServiceOrder {
  id: string;
  numero_os: string;
  equipment_id: string;
  equipment_code: string;
  equipment_model: string | null;
  unit: string | null;
  location: string | null;
  oficina: string | null;
  usuario_abertura_id: string | null;
  mecanico_responsavel: string;
  tipo_manutencao: MaintenanceType;
  descricao_ocorrencia: string;
  status: ServiceOrderStatus;
  data_hora_abertura: string;
  data_hora_inicio_manutencao: string | null;
  data_hora_fechamento: string | null;
  tempo_indisponibilidade_minutos: number | null;
  servico_executado: string | null;
  causa_identificada: string | null;
  pecas_materiais: string | null;
  observacoes: string | null;
  motivo_cancelamento: string | null;
  created_at: string;
  updated_at: string;
}

export const MAINTENANCE_TYPE_LABELS: Record<MaintenanceType, string> = {
  avaria: 'Avaria',
  corretiva: 'Manutenção Corretiva',
  pneus: 'Pneus',
  preventiva: 'Manutenção Preventiva',
};

export const STATUS_LABELS: Record<ServiceOrderStatus, string> = {
  aberta: 'Aberta',
  em_manutencao: 'Em Manutenção',
  finalizada: 'Finalizada',
  cancelada: 'Cancelada',
};

export const STATUS_CLASSES: Record<ServiceOrderStatus, string> = {
  aberta: 'bg-safety-red text-white',
  em_manutencao: 'bg-safety-orange text-white',
  finalizada: 'bg-safety-green text-white',
  cancelada: 'bg-gray-500 text-white',
};

/** Formata minutos como "06h 30min" */
export const formatDowntime = (minutes: number | null | undefined): string => {
  if (minutes === null || minutes === undefined || Number.isNaN(minutes)) return '-';
  const total = Math.max(0, Math.round(minutes));
  const days = Math.floor(total / (60 * 24));
  const hours = Math.floor((total % (60 * 24)) / 60);
  const mins = total % 60;
  if (days > 0) return `${days}d ${String(hours).padStart(2, '0')}h ${String(mins).padStart(2, '0')}min`;
  return `${String(hours).padStart(2, '0')}h ${String(mins).padStart(2, '0')}min`;
};

/** Minutos decorridos desde a abertura (ou até o fechamento) */
export const downtimeMinutes = (os: ServiceOrder, now: number = Date.now()): number => {
  const start = new Date(os.data_hora_abertura).getTime();
  const end = os.data_hora_fechamento ? new Date(os.data_hora_fechamento).getTime() : now;
  return Math.max(0, Math.round((end - start) / 60000));
};

export const isOpenStatus = (status: ServiceOrderStatus) =>
  status === 'aberta' || status === 'em_manutencao';
