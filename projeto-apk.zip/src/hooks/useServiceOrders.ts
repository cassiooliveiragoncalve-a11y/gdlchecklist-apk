import { useCallback, useEffect, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useSupabaseAuth';
import {
  ServiceOrder,
  ServiceOrderStatus,
  MaintenanceType,
  isOpenStatus,
} from '@/types/serviceOrder';

const SO_COLUMNS =
  'id,numero_os,equipment_id,equipment_code,equipment_model,unit,location,oficina,usuario_abertura_id,mecanico_responsavel,tipo_manutencao,descricao_ocorrencia,status,data_hora_abertura,data_hora_inicio_manutencao,data_hora_fechamento,tempo_indisponibilidade_minutos,servico_executado,causa_identificada,pecas_materiais,observacoes,motivo_cancelamento,created_at,updated_at';

export const SERVICE_ORDERS_KEY = ['service-orders'] as const;

export interface CreateServiceOrderInput {
  equipment_id: string;
  equipment_code: string;
  equipment_model?: string | null;
  unit?: string | null;
  location?: string | null;
  oficina?: string | null;
  tipo_manutencao: MaintenanceType;
  descricao_ocorrencia: string;
}

export interface FinalizeServiceOrderInput {
  servico_executado: string;
  causa_identificada: string;
  pecas_materiais?: string;
  observacoes?: string;
}

const fetchServiceOrders = async (): Promise<ServiceOrder[]> => {
  const { data, error } = await supabase
    .from('service_orders')
    .select(SO_COLUMNS)
    .order('data_hora_abertura', { ascending: false })
    .limit(1000);
  if (error) throw error;
  return (data || []) as ServiceOrder[];
};

export const useServiceOrders = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: serviceOrders = [], isLoading, refetch } = useQuery({
    queryKey: SERVICE_ORDERS_KEY,
    queryFn: fetchServiceOrders,
    enabled: !!user,
    staleTime: 60 * 1000,
    gcTime: 10 * 60 * 1000,
  });

  // Realtime: mantém a lista sincronizada sem polling
  useEffect(() => {
    if (!user) return;
    const channel = supabase
      .channel('service-orders-changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'service_orders' }, () => {
        queryClient.invalidateQueries({ queryKey: SERVICE_ORDERS_KEY });
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  const openOrders = useMemo(
    () => serviceOrders.filter((os) => isOpenStatus(os.status)),
    [serviceOrders]
  );

  const findOpenByEquipment = useCallback(
    (equipmentId: string) => openOrders.find((os) => os.equipment_id === equipmentId) || null,
    [openOrders]
  );

  const invalidate = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: SERVICE_ORDERS_KEY });
    queryClient.invalidateQueries({ queryKey: ['equipment'] });
  }, [queryClient]);

  const createServiceOrder = useCallback(
    async (input: CreateServiceOrderInput): Promise<ServiceOrder | null> => {
      if (!user) return null;
      if (!input.equipment_id) {
        toast({ title: 'Selecione o equipamento', variant: 'destructive' });
        return null;
      }
      if (!input.tipo_manutencao) {
        toast({ title: 'Selecione o tipo de manutenção', variant: 'destructive' });
        return null;
      }
      if (!input.descricao_ocorrencia?.trim()) {
        toast({ title: 'Informe a descrição da ocorrência', variant: 'destructive' });
        return null;
      }

      const existing = findOpenByEquipment(input.equipment_id);
      if (existing) {
        toast({
          title: 'Este equipamento já possui uma Ordem de Serviço em aberto.',
          description: `${existing.numero_os} — aberta por ${existing.mecanico_responsavel}`,
          variant: 'destructive',
        });
        return null;
      }

      const { data, error } = await supabase
        .from('service_orders')
        .insert([{
          numero_os: '', // gerado automaticamente pelo banco (OS-AAAA-000000)
          equipment_id: input.equipment_id,
          equipment_code: input.equipment_code,
          equipment_model: input.equipment_model ?? null,
          unit: input.unit ?? null,
          location: input.location ?? null,
          oficina: input.oficina?.trim() || null,
          usuario_abertura_id: user.id,
          mecanico_responsavel: user.name,
          tipo_manutencao: input.tipo_manutencao,
          descricao_ocorrencia: input.descricao_ocorrencia.trim(),
          status: 'aberta',
        }])
        .select(SO_COLUMNS)
        .single();

      if (error) {
        const duplicate = error.code === '23505';
        toast({
          title: duplicate
            ? 'Este equipamento já possui uma Ordem de Serviço em aberto.'
            : 'Erro ao abrir OS',
          description: duplicate ? undefined : error.message,
          variant: 'destructive',
        });
        invalidate();
        return null;
      }

      invalidate();
      toast({ title: `OS ${data.numero_os} aberta`, description: 'Equipamento marcado como indisponível.' });
      return data as ServiceOrder;
    },
    [user, findOpenByEquipment, toast, invalidate]
  );

  const startMaintenance = useCallback(
    async (id: string) => {
      const { error } = await supabase
        .from('service_orders')
        .update({ status: 'em_manutencao', data_hora_inicio_manutencao: new Date().toISOString() })
        .eq('id', id);
      if (error) {
        toast({ title: 'Erro ao iniciar manutenção', description: error.message, variant: 'destructive' });
        return false;
      }
      invalidate();
      toast({ title: 'Manutenção iniciada' });
      return true;
    },
    [toast, invalidate]
  );

  const finalizeServiceOrder = useCallback(
    async (id: string, input: FinalizeServiceOrderInput) => {
      if (!input.servico_executado?.trim() || !input.causa_identificada?.trim()) {
        toast({ title: 'Informe o serviço executado e a causa identificada', variant: 'destructive' });
        return false;
      }
      const { error } = await supabase
        .from('service_orders')
        .update({
          status: 'finalizada',
          servico_executado: input.servico_executado.trim(),
          causa_identificada: input.causa_identificada.trim(),
          pecas_materiais: input.pecas_materiais?.trim() || null,
          observacoes: input.observacoes?.trim() || null,
        })
        .eq('id', id);
      if (error) {
        toast({ title: 'Erro ao finalizar OS', description: error.message, variant: 'destructive' });
        return false;
      }
      invalidate();
      toast({ title: 'OS finalizada', description: 'Equipamento liberado como disponível.' });
      return true;
    },
    [toast, invalidate]
  );

  const cancelServiceOrder = useCallback(
    async (id: string, motivo: string) => {
      if (!motivo?.trim()) {
        toast({ title: 'Informe o motivo do cancelamento', variant: 'destructive' });
        return false;
      }
      const { error } = await supabase
        .from('service_orders')
        .update({ status: 'cancelada', motivo_cancelamento: motivo.trim() })
        .eq('id', id);
      if (error) {
        toast({ title: 'Erro ao cancelar OS', description: error.message, variant: 'destructive' });
        return false;
      }
      invalidate();
      toast({ title: 'OS cancelada' });
      return true;
    },
    [toast, invalidate]
  );

  const reopenServiceOrder = useCallback(
    async (id: string) => {
      const { error } = await supabase
        .from('service_orders')
        .update({ status: 'aberta', motivo_cancelamento: null })
        .eq('id', id);
      if (error) {
        toast({ title: 'Erro ao reabrir OS', description: error.message, variant: 'destructive' });
        return false;
      }
      invalidate();
      toast({ title: 'OS reaberta' });
      return true;
    },
    [toast, invalidate]
  );

  const deleteServiceOrder = useCallback(
    async (id: string) => {
      const { error } = await supabase.from('service_orders').delete().eq('id', id);
      if (error) {
        toast({ title: 'Erro ao excluir OS', description: error.message, variant: 'destructive' });
        return false;
      }
      invalidate();
      toast({ title: 'OS excluída' });
      return true;
    },
    [toast, invalidate]
  );

  const countsByStatus = useMemo(() => {
    const counts: Record<ServiceOrderStatus, number> = {
      aberta: 0,
      em_manutencao: 0,
      finalizada: 0,
      cancelada: 0,
    };
    serviceOrders.forEach((os) => {
      counts[os.status] = (counts[os.status] || 0) + 1;
    });
    return counts;
  }, [serviceOrders]);

  return {
    serviceOrders,
    openOrders,
    countsByStatus,
    isLoading,
    refetch,
    findOpenByEquipment,
    createServiceOrder,
    startMaintenance,
    finalizeServiceOrder,
    cancelServiceOrder,
    reopenServiceOrder,
    deleteServiceOrder,
  };
};
