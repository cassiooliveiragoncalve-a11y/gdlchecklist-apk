import { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Session, User as SupabaseUser } from '@supabase/supabase-js';

export interface User {
  id: string;
  username: string;
  name: string;
  profile: 'operador' | 'mecanico' | 'gestor' | 'admin';
  matricula?: string;
}

export interface SignupResult {
  success: boolean;
  errorCode?: 'user_already_exists' | 'weak_password' | 'network' | 'unknown';
  errorMessage?: string;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  login: (username: string, password: string) => Promise<boolean>;
  signup: (username: string, password: string, name: string, profile: 'operador' | 'mecanico' | 'gestor' | 'admin', matricula?: string) => Promise<SignupResult>;
  logout: () => void;
  isLoading: boolean;
  isAuthReady: boolean;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const useSupabaseAuthState = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthReady, setIsAuthReady] = useState(false);

  // Cache de perfil em memória + sessionStorage para evitar bater no DB toda hora
  const PROFILE_CACHE_KEY = 'gdl.profile.cache.v1';
  const PROFILE_TTL_MS = 30 * 60 * 1000; // 30 min

  const readProfileCache = (userId: string): User | null => {
    try {
      const raw = sessionStorage.getItem(PROFILE_CACHE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as { userId: string; profile: User; savedAt: number };
      if (parsed.userId !== userId) return null;
      if (Date.now() - parsed.savedAt > PROFILE_TTL_MS) return null;
      return parsed.profile;
    } catch {
      return null;
    }
  };

  const writeProfileCache = (userId: string, profile: User) => {
    try {
      sessionStorage.setItem(
        PROFILE_CACHE_KEY,
        JSON.stringify({ userId, profile, savedAt: Date.now() })
      );
    } catch {
      /* storage cheio: ignorar */
    }
  };

  // Fetch user profile from database - COM RETRY para conexões instáveis (4G)
  const fetchUserProfile = useCallback(async (userId: string, retryCount = 0, useCache = true): Promise<User | null> => {
    const maxRetries = 2;

    if (useCache) {
      const cached = readProfileCache(userId);
      if (cached) return cached;
    }

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, name, profile, matricula')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        if (retryCount < maxRetries && (error.message?.includes('network') || error.message?.includes('fetch') || error.message?.includes('Failed to fetch') || error.message?.includes('timeout') || error.code === 'PGRST301')) {
          const delay = Math.min(1000 * Math.pow(2, retryCount), 5000);
          await new Promise(resolve => setTimeout(resolve, delay));
          return fetchUserProfile(userId, retryCount + 1, false);
        }
        return null;
      }

      if (data) {
        writeProfileCache(userId, data as User);
        return data as User;
      }
      return null;
    } catch {
      if (retryCount < maxRetries) {
        const delay = Math.min(1000 * Math.pow(2, retryCount), 5000);
        await new Promise(resolve => setTimeout(resolve, delay));
        return fetchUserProfile(userId, retryCount + 1, false);
      }
      return null;
    }
  }, []);

  useEffect(() => {
    let mounted = true;
    console.log('[useAuth] Inicializando hook de autenticação');

    // Check for existing session FIRST
    const initAuth = async () => {
      try {
        console.log('[useAuth] Verificando sessão existente...');
        const { data: { session: currentSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          console.error('[useAuth] Erro ao obter sessão:', error);
          if (mounted) {
            setSession(null);
            setUser(null);
            setIsLoading(false);
          }
          return;
        }

        if (!mounted) return;
        
        console.log('[useAuth] Sessão encontrada:', !!currentSession);
        
        // Validar se a sessão não está expirada
        if (currentSession?.expires_at) {
          const expiresAt = currentSession.expires_at * 1000;
          const now = Date.now();
          
          if (expiresAt < now) {
            console.log('[useAuth] Sessão expirada, fazendo logout...');
            await supabase.auth.signOut();
            if (mounted) {
              setSession(null);
              setUser(null);
              setIsLoading(false);
            }
            return;
          }
        }
        
        setSession(currentSession);
        
        if (currentSession?.user) {
          const profile = await fetchUserProfile(currentSession.user.id);
          if (mounted) {
            setUser(profile);
            setIsLoading(false);
            setIsAuthReady(true);
          }
        } else {
          if (mounted) {
            setIsLoading(false);
            setIsAuthReady(true);
          }
        }
      } catch (error) {
        console.error('[useAuth] Erro inesperado ao inicializar:', error);
        if (mounted) {
          setSession(null);
          setUser(null);
          setIsLoading(false);
        }
      }
    };

    initAuth();

    // Set up auth state listener AFTER initial check
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, currentSession) => {
        if (!mounted) return;

        setSession(currentSession);

        // Só rebuscar perfil em SIGNED_IN e apenas se o usuário mudou.
        // TOKEN_REFRESHED, USER_UPDATED e INITIAL_SESSION não precisam bater no DB.
        if (currentSession?.user && event === 'SIGNED_IN') {
          setTimeout(() => {
            if (!mounted) return;
            setUser((prev) => {
              if (prev && prev.id === currentSession.user.id) return prev;
              fetchUserProfile(currentSession.user.id).then(profile => {
                if (mounted) setUser(profile);
              });
              return prev;
            });
          }, 0);
        } else if (!currentSession) {
          setUser(null);
          try { sessionStorage.removeItem(PROFILE_CACHE_KEY); } catch { /* ignore */ }
        }
      }
    );

    return () => {
      console.log('[useAuth] Cleanup');
      mounted = false;
      subscription.unsubscribe();
    };
  }, []); // Removendo fetchUserProfile das dependências para evitar loops

  const signup = async (
    username: string, 
    password: string, 
    name: string, 
    profile: 'operador' | 'mecanico' | 'gestor' | 'admin',
    matricula?: string
  ): Promise<SignupResult> => {
    try {
      setIsLoading(true);

      // Normalizar username (evita duplicidade/whitespace do teclado mobile)
      const normalized = (username || '').trim().toLowerCase();
      if (!normalized) {
        return { success: false, errorCode: 'unknown', errorMessage: 'Usuário inválido' };
      }

      const email = `${normalized}@gdl.com`;
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            username: normalized,
            name: name?.trim(),
            profile,
            matricula: matricula?.trim(),
          },
          emailRedirectTo: `${window.location.origin}/`
        }
      });

      if (error) {
        console.error('Signup error:', error);
        const msg = (error.message || '').toLowerCase();
        if (msg.includes('already') || msg.includes('registered') || (error as any).code === 'user_already_exists') {
          return { success: false, errorCode: 'user_already_exists', errorMessage: 'Este usuário já está cadastrado.' };
        }
        if (msg.includes('password')) {
          return { success: false, errorCode: 'weak_password', errorMessage: error.message };
        }
        if (msg.includes('network') || msg.includes('fetch')) {
          return { success: false, errorCode: 'network', errorMessage: 'Sem conexão. Tente novamente.' };
        }
        return { success: false, errorCode: 'unknown', errorMessage: error.message };
      }

      if (data.user) {
        const userProfile = await fetchUserProfile(data.user.id);
        setUser(userProfile);
      }

      return { success: true };
    } catch (error: any) {
      console.error('Unexpected signup error:', error);
      return { success: false, errorCode: 'unknown', errorMessage: error?.message || 'Erro inesperado' };
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      setIsLoading(true);

      // Normalizar username: remover espaços e forçar minúsculas
      // (evita falha quando teclado mobile capitaliza ou adiciona espaço)
      const normalized = (username || '').trim().toLowerCase();
      if (!normalized) {
        console.warn('[useAuth] Login abortado: username vazio após normalização');
        return false;
      }
      const email = `${normalized}@gdl.com`;
      console.log('[useAuth] Tentando login com usuário:', normalized);

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        console.error('Login error:', error);
        return false;
      }

      if (data.user) {
        const profile = await fetchUserProfile(data.user.id);
        setUser(profile);
      }

      return true;
    } catch (error) {
      console.error('Unexpected login error:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      console.log('[useAuth] Iniciando logout...');
      
      // Limpar estado imediatamente para evitar loops
      setUser(null);
      setSession(null);
      
      // Fazer signout no Supabase
      await supabase.auth.signOut();
      
      // Limpar cache do localStorage (se houver dados adicionais)
      // O Supabase já limpa automaticamente suas chaves de auth
      console.log('[useAuth] Logout concluído com sucesso');
    } catch (error) {
      console.error('[useAuth] Erro ao fazer logout:', error);
      // Mesmo com erro, garantir que o estado está limpo
      setUser(null);
      setSession(null);
    }
  };

  return {
    user,
    session,
    login,
    signup,
    logout,
    isLoading,
    isAuthReady
  };
};
