import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useSupabaseAuth';
import { HourMeterReading } from '@/lib/operationalMetrics';

/**
 * Leituras de horímetro extraídas dos checklists já existentes.
 * A API limita 1000 linhas por resposta, então paginamos em blocos de 1000
 * partindo das leituras MAIS RECENTES (essenciais para franquia/ociosidade).
 * Apenas 4 colunas, cache longo (dados históricos mudam pouco).
 */
const PAGE_SIZE = 1000;
const MAX_PAGES = 6; // até 6.000 leituras

const fetchReadings = async (): Promise<HourMeterReading[]> => {
  const rows: any[] = [];

  for (let page = 0; page < MAX_PAGES; page++) {
    const from = page * PAGE_SIZE;
    const { data, error } = await supabase
      .from('checklist_records')
      .select('equipment_id,equipment_code,hour_meter,timestamp')
      .not('hour_meter', 'is', null)
      .gt('hour_meter', 0)
      .order('timestamp', { ascending: false })
      .range(from, from + PAGE_SIZE - 1);

    if (error) throw error;
    rows.push(...(data || []));
    if (!data || data.length < PAGE_SIZE) break;
  }

  return rows
    .map((r: any) => ({
      equipmentId: r.equipment_id,
      equipmentCode: r.equipment_code,
      hourMeter: Number(r.hour_meter) || 0,
      timestamp: r.timestamp,
    }))
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
};


export const useHourMeterReadings = () => {
  const { user } = useAuth();
  const { data = [], isLoading } = useQuery({
    queryKey: ['hour-meter-readings'],
    queryFn: fetchReadings,
    enabled: !!user,
    staleTime: 15 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    refetchOnWindowFocus: false,
  });
  return { readings: data, isLoading };
};
