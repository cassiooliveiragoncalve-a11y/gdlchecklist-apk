import { useEffect, useState } from 'react';

/** Retorna Date.now() atualizado periodicamente (para contadores em tempo real) */
export const useNow = (intervalMs = 30000) => {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
};
