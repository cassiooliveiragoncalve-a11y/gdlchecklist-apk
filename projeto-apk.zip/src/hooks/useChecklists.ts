import { useCallback, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ChecklistAnswer } from '@/types/equipment';
import { useToast } from '@/hooks/use-toast';
import { keysToSnakeCase, keysToCamelCase } from '@/lib/utils';
import { checkEquipmentAvailability } from '@/lib/equipmentAvailability';
import { useAuth } from '@/hooks/useSupabaseAuth';
import { 
  QUERY_KEYS, CACHE_TIMES, CHECKLIST_LIGHT_COLUMNS, 
  withTiming, getAbortSignal, RETRY_CONFIG 
} from '@/lib/queryConfig';

/**
 * Fetch checklists with light columns and parallel sub-queries
 */
const fetchChecklists = async (): Promise<any[]> => {
  return withTiming('fetchChecklists', async () => {
    const signal = getAbortSignal('checklists', 15000);
    
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return [];

    const { data: records, error } = await supabase
      .from('checklist_records')
      .select(CHECKLIST_LIGHT_COLUMNS)
      .order('timestamp', { ascending: false })
      .limit(2000)
      .abortSignal(signal);

    if (error) throw error;
    if (!records || records.length === 0) return [];

    const recordIds = records.map(r => r.id);

    // Parallel fetch with only needed columns
    const [approvalsResult, rejectionsResult] = await Promise.all([
      supabase.from('checklist_approvals')
        .select('checklist_record_id,mechanic_name,timestamp,comment')
        .in('checklist_record_id', recordIds)
        .abortSignal(signal),
      supabase.from('checklist_rejections')
        .select('checklist_record_id,mechanic_name,timestamp,reason')
        .in('checklist_record_id', recordIds)
        .abortSignal(signal),
    ]);

    const approvalsByRecord = new Map<string, any[]>();
    (approvalsResult.data || []).forEach(a => {
      const list = approvalsByRecord.get(a.checklist_record_id) || [];
      list.push({ mechanicName: a.mechanic_name, timestamp: a.timestamp, comment: a.comment });
      approvalsByRecord.set(a.checklist_record_id, list);
    });

    const rejectionsByRecord = new Map<string, any[]>();
    (rejectionsResult.data || []).forEach(r => {
      const list = rejectionsByRecord.get(r.checklist_record_id) || [];
      list.push({ mechanicName: r.mechanic_name, timestamp: r.timestamp, reason: r.reason });
      rejectionsByRecord.set(r.checklist_record_id, list);
    });

    return records.map(record => {
      const camelRecord = keysToCamelCase(record);
      return {
        ...camelRecord,
        photos: {},
        checklistAnswers: [],
        approvals: approvalsByRecord.get(record.id) || [],
        rejections: rejectionsByRecord.get(record.id) || [],
      };
    });
  });
};

export const useChecklists = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: checklistRecords = [], isLoading } = useQuery({
    queryKey: QUERY_KEYS.checklists,
    queryFn: fetchChecklists,
    enabled: !!user,
    ...CACHE_TIMES.checklists,
    ...RETRY_CONFIG,
    refetchOnMount: false, // Use prefetch cache
  });

  // Debounced realtime invalidation
  useEffect(() => {
    if (!user) return;
    let debounceTimer: NodeJS.Timeout;

    const debouncedInvalidate = () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      }, 2000); // 2s debounce to batch rapid changes
    };

    const channel = supabase
      .channel('checklists-changes-rq')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'checklist_records' }, debouncedInvalidate)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checklist_approvals' }, debouncedInvalidate)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checklist_rejections' }, debouncedInvalidate)
      .subscribe();

    return () => {
      clearTimeout(debounceTimer);
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  const addChecklist = useCallback(async (checklistData: {
    equipmentId: string | null;
    equipmentCode: string;
    equipmentModel: string;
    operatorName: string;
    operatorId: string;
    answers: ChecklistAnswer[];
    signature: string;
    photos?: Record<string, string[]>;
    checklistType?: string;
    operationDescription?: string;
    loadDescription?: string;
    location?: string | null;
    unit?: string | null;
    equipmentSeries?: string | null;
    equipmentNumber?: string | null;
    hourMeter?: number | null;
    hourMeterJustification?: string | null;
  }) => {

    try {
      // Validação em tempo real: equipamento indisponível ou com OS aberta bloqueia o checklist
      const isEquipmentChecklist = (!checklistData.checklistType || checklistData.checklistType === 'empilhadeira');
      if (isEquipmentChecklist && checklistData.equipmentId) {
        const availability = await checkEquipmentAvailability(checklistData.equipmentId);
        if (availability.blocked) {
          throw new Error(`${availability.title}\n${availability.description}`);
        }
      }

      const conformeItems = checklistData.answers.filter(a => a.value === 'sim').length;
      const naoConformeItems = checklistData.answers.filter(a => a.value === 'nao').length;
      const hasCriticalIssues = naoConformeItems > 0;
      const isLiftingAccessory = checklistData.checklistType && checklistData.checklistType !== 'empilhadeira';
      
      let status: 'conforme' | 'pendente' | 'negado';
      if (hasCriticalIssues) {
        status = isLiftingAccessory ? 'negado' : 'pendente';
      } else {
        status = 'conforme';
      }

      const recordData = keysToSnakeCase({
        equipmentId: checklistData.equipmentId,
        equipmentCode: checklistData.equipmentCode,
        equipmentModel: checklistData.equipmentModel,
        operatorName: checklistData.operatorName,
        operatorId: checklistData.operatorId,
        status,
        totalItems: checklistData.answers.length,
        conformeItems,
        naoConformeItems,
        signature: checklistData.signature,
        hasCriticalIssues,
        checklistType: checklistData.checklistType || 'empilhadeira',
        operationDescription: checklistData.operationDescription,
        loadDescription: checklistData.loadDescription,
        location: checklistData.location,
        unit: checklistData.unit,
        equipmentSeries: checklistData.equipmentSeries,
        equipmentNumber: checklistData.equipmentNumber,
        hourMeter: checklistData.hourMeter,
        // Sessão operacional: checklists de equipamento abrem "em andamento"
        sessionStatus: !isLiftingAccessory && checklistData.equipmentId ? 'em_andamento' : 'finalizado',
        startedAt: new Date().toISOString(),
        endedAt: !isLiftingAccessory && checklistData.equipmentId ? null : new Date().toISOString(),
        hourMeterStart: checklistData.hourMeter ?? null,
        hourMeterJustification: checklistData.hourMeterJustification ?? null,
      });


      const { data: record, error: recordError } = await supabase
        .from('checklist_records')
        .insert([recordData])
        .select()
        .single();

      if (recordError) {
        if ((recordError as any).code === '23505') {
          throw new Error('Já existe um checklist em andamento para este equipamento. Encerre-o antes de iniciar outro.');
        }
        const msg = (recordError as any).message || '';
        if (msg.includes('EQUIPAMENTO_INDISPONIVEL')) {
          throw new Error(`⚠️ Equipamento indisponível. ${msg.split('EQUIPAMENTO_INDISPONIVEL:')[1]?.trim() || ''}`);
        }
        if (msg.includes('OS_ABERTA')) {
          throw new Error(`⚠️ Equipamento com OS aberta. ${msg.split('OS_ABERTA:')[1]?.trim() || ''} O checklist poderá ser iniciado somente após o encerramento da OS.`);
        }
        throw recordError;
      }


      // CRITICAL: Insert answers FIRST (with retry) — without answers the record is useless.
      // If this fails, rollback by deleting the parent record to avoid orphaned checklists.
      const answersToInsert = checklistData.answers.map(answer =>
        keysToSnakeCase({
          checklistRecordId: record.id,
          itemId: answer.itemId,
          value: answer.value,
          observation: answer.observation,
        })
      );

      const insertAnswersWithRetry = async (attempts = 3): Promise<void> => {
        let lastErr: any = null;
        for (let i = 0; i < attempts; i++) {
          const { error } = await supabase.from('checklist_answers').insert(answersToInsert);
          if (!error) return;
          lastErr = error;
          // Wait with exponential backoff before retrying (4G resilience)
          await new Promise(res => setTimeout(res, 500 * Math.pow(2, i)));
        }
        throw lastErr;
      };

      try {
        await insertAnswersWithRetry();
      } catch (answersError: any) {
        // Rollback: remove orphaned record so it doesn't appear in history without answers
        console.error('[useChecklists] Falha ao salvar respostas, revertendo registro:', answersError);
        await supabase.from('checklist_records').delete().eq('id', record.id);
        throw new Error('Não foi possível salvar as respostas do checklist. Verifique sua conexão e tente novamente.');
      }

      // Now insert photos and auto-approval in parallel (non-critical for record integrity)
      const parallelOps: Promise<any>[] = [];

      // Photos
      if (checklistData.photos) {
        const photosToInsert = Object.entries(checklistData.photos).flatMap(([itemId, urls]) =>
          urls.map(url => keysToSnakeCase({ checklistRecordId: record.id, itemId, photoUrl: url }))
        );
        if (photosToInsert.length > 0) {
          parallelOps.push(
            (async () => {
              const { error } = await supabase.from('checklist_photos').insert(photosToInsert);
              if (error) console.warn('[useChecklists] Falha ao salvar fotos:', error);
            })()
          );
        }
      }

      // Auto-approve conformes
      if (status === 'conforme' && !isLiftingAccessory) {
        parallelOps.push(
          (async () => {
            const { error } = await supabase.from('checklist_approvals').insert([keysToSnakeCase({
              checklistRecordId: record.id,
              mechanicName: 'Sistema',
              comment: 'Checklist aprovado automaticamente - todos os itens conformes',
            })]);
            if (error) console.warn('Auto-approve failed:', error);
          })()
        );
      }

      await Promise.all(parallelOps);

      let toastDescription = '';
      if (isLiftingAccessory) {
        toastDescription = status === 'negado'
          ? "Checklist registrado. Equipamento bloqueado devido a itens não conformes."
          : "Checklist de acessório de içamento registrado com sucesso!";
      } else {
        toastDescription = status === 'conforme'
          ? "Checklist aprovado automaticamente!"
          : "Checklist enviado para aprovação do mecânico.";
      }

      toast({ title: "Checklist registrado", description: toastDescription, variant: status === 'negado' ? 'destructive' : 'default' });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      return record;
    } catch (error: any) {
      console.error('[useChecklists] Erro:', error);
      toast({ title: "Erro ao registrar checklist", description: error.message || "Erro desconhecido.", variant: "destructive" });
      return null;
    }
  }, [toast, queryClient]);

  const approveChecklist = useCallback(async (recordId: string, mechanicName: string, comment: string) => {
    try {
      // Parallel update + insert
      const [updateResult, insertResult] = await Promise.all([
        supabase.from('checklist_records').update({ status: 'conforme' }).eq('id', recordId),
        supabase.from('checklist_approvals').insert([keysToSnakeCase({ checklistRecordId: recordId, mechanicName, comment })]),
      ]);
      if (updateResult.error) throw updateResult.error;
      if (insertResult.error) throw insertResult.error;

      toast({ title: "Checklist aprovado", description: "O checklist foi aprovado com sucesso." });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      return true;
    } catch (error: any) {
      toast({ title: "Erro ao aprovar checklist", description: error.message, variant: "destructive" });
      return false;
    }
  }, [toast, queryClient]);

  const rejectChecklist = useCallback(async (recordId: string, mechanicName: string, reason: string) => {
    try {
      const [updateResult, insertResult] = await Promise.all([
        supabase.from('checklist_records').update({ status: 'negado' }).eq('id', recordId),
        supabase.from('checklist_rejections').insert([keysToSnakeCase({ checklistRecordId: recordId, mechanicName, reason })]),
      ]);
      if (updateResult.error) throw updateResult.error;
      if (insertResult.error) throw insertResult.error;

      toast({ title: "Checklist negado", description: "O checklist foi negado e o operador será notificado." });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      return true;
    } catch (error: any) {
      toast({ title: "Erro ao negar checklist", description: error.message, variant: "destructive" });
      return false;
    }
  }, [toast, queryClient]);

  const deleteChecklist = useCallback(async (recordId: string) => {
    try {
      const { error } = await supabase.from('checklist_records').delete().eq('id', recordId);
      if (error) throw error;
      toast({ title: "Checklist excluído", description: "Registro removido com sucesso." });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      return true;
    } catch (error: any) {
      toast({ title: "Erro ao excluir checklist", description: error.message, variant: "destructive" });
      return false;
    }
  }, [toast, queryClient]);

  /**
   * Encerra a sessão operacional de um checklist em andamento.
   * Calcula horas trabalhadas = horímetro final - horímetro inicial.
   */
  const closeChecklistSession = useCallback(async (
    recordId: string,
    hourMeterEnd: number,
    justification?: string,
  ) => {
    try {
      const { data: current, error: fetchError } = await supabase
        .from('checklist_records')
        .select('id,session_status,hour_meter_start,hour_meter')
        .eq('id', recordId)
        .single();
      if (fetchError) throw fetchError;
      if (!current) throw new Error('Checklist não encontrado.');
      if (current.session_status !== 'em_andamento') {
        throw new Error('Este checklist já foi encerrado.');
      }

      const start = Number(current.hour_meter_start ?? current.hour_meter ?? 0);
      if (!isFinite(hourMeterEnd)) {
        throw new Error('Informe o horímetro final.');
      }
      if (hourMeterEnd < start && !justification?.trim()) {
        throw new Error('O horímetro final não pode ser menor que o horímetro inicial.');
      }

      const workedHours = Math.max(0, Number((hourMeterEnd - start).toFixed(2)));
      const endedAt = new Date().toISOString();

      const { data: updated, error } = await supabase
        .from('checklist_records')
        .update({
          session_status: 'finalizado',
          ended_at: endedAt,
          hour_meter_end: hourMeterEnd,
          worked_hours: workedHours,
          ...(justification?.trim() ? { hour_meter_justification: justification.trim() } : {}),
        })
        .eq('id', recordId)
        .select('id');
      if (error) throw error;
      if (!updated || updated.length === 0) {
        throw new Error('Não foi possível encerrar: você não tem permissão para encerrar este checklist.');
      }

      toast({
        title: 'Checklist encerrado',
        description: `Horas trabalhadas: ${workedHours.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })} h`,
      });
      queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists });
      return true;
    } catch (error: any) {
      toast({ title: 'Erro ao encerrar checklist', description: error.message, variant: 'destructive' });
      return false;
    }
  }, [toast, queryClient]);

  return {
    checklistRecords,
    isLoading,
    addChecklist,
    approveChecklist,
    rejectChecklist,
    deleteChecklist,
    closeChecklistSession,
    refreshChecklists: () => queryClient.invalidateQueries({ queryKey: QUERY_KEYS.checklists }),
  };

};
