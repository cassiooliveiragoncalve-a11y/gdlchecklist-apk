import { useCallback } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useSupabaseAuth';
import { useToast } from '@/hooks/use-toast';

export interface EquipmentContract {
  id: string;
  equipment_id: string;
  monthly_franchise_hours: number;
  cycle_start_day: number;
  extra_hour_rate: number;
  equipment_value: number | null;
  notes: string | null;
}

export interface EquipmentContractInput {
  equipment_id: string;
  monthly_franchise_hours: number;
  cycle_start_day: number;
  extra_hour_rate: number;
  equipment_value: number | null;
  notes?: string | null;
}

const fetchContracts = async (): Promise<EquipmentContract[]> => {
  const { data, error } = await supabase
    .from('equipment_contracts')
    .select('id,equipment_id,monthly_franchise_hours,cycle_start_day,extra_hour_rate,equipment_value,notes');
  if (error) throw error;
  return (data || []).map((c: any) => ({
    ...c,
    monthly_franchise_hours: Number(c.monthly_franchise_hours) || 0,
    cycle_start_day: Number(c.cycle_start_day) || 1,
    extra_hour_rate: Number(c.extra_hour_rate) || 0,
    equipment_value: c.equipment_value === null ? null : Number(c.equipment_value),
  }));
};

export const useEquipmentContracts = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data = [], isLoading } = useQuery({
    queryKey: ['equipment-contracts'],
    queryFn: fetchContracts,
    enabled: !!user,
    staleTime: 10 * 60 * 1000,
    gcTime: 30 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  const saveMutation = useMutation({
    mutationFn: async (input: EquipmentContractInput) => {
      const { error } = await supabase
        .from('equipment_contracts')
        .upsert(input, { onConflict: 'equipment_id' });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['equipment-contracts'] });
      toast({ title: 'Franquia atualizada', description: 'Configuração contratual salva com sucesso.' });
    },
    onError: (error: any) => {
      toast({
        title: 'Erro ao salvar franquia',
        description: error?.message || 'Tente novamente.',
        variant: 'destructive',
      });
    },
  });

  const getContract = useCallback(
    (equipmentId: string) => data.find((c) => c.equipment_id === equipmentId) || null,
    [data]
  );

  return {
    contracts: data,
    isLoading,
    getContract,
    saveContract: saveMutation.mutateAsync,
    isSaving: saveMutation.isPending,
  };
};
