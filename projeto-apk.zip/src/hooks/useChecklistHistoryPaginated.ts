import { useEffect } from 'react';
import { keepPreviousData, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { keysToCamelCase } from '@/lib/utils';
import { CHECKLIST_LIGHT_COLUMNS } from '@/lib/queryConfig';

export const PAGE_SIZE = 50;

export interface ChecklistHistoryFilters {
  search?: string;              // ilike em equipment_code / operator_name / equipment_model
  status?: string;              // 'todos' | 'conforme' | 'pendente' | 'negado'
  checklistType?: string;       // 'todos' | 'empilhadeira' | ...
  year?: string;                // 'todos' | 'YYYY'
  month?: string;               // 'todos' | 'YYYY-MM'
  operatorName?: string;        // usado para restringir operadores ao próprio nome
}

export interface PaginatedChecklists {
  records: any[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

// Trata a string como plain string para não estourar tempo de typecheck do supabase-js
const sel = (s: string): string => s;

const buildRange = (filters: ChecklistHistoryFilters): { from?: string; to?: string } => {
  const { year, month } = filters;
  if (month && month !== 'todos') {
    const [y, m] = month.split('-').map((v) => parseInt(v, 10));
    const from = new Date(y, m - 1, 1).toISOString();
    const to = new Date(y, m, 1).toISOString();
    return { from, to };
  }
  if (year && year !== 'todos') {
    const y = parseInt(year, 10);
    const from = new Date(y, 0, 1).toISOString();
    const to = new Date(y + 1, 0, 1).toISOString();
    return { from, to };
  }
  return {};
};

const fetchPage = async (
  page: number,
  filters: ChecklistHistoryFilters
): Promise<PaginatedChecklists> => {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    return { records: [], total: 0, page, pageSize: PAGE_SIZE, totalPages: 0 };
  }

  const fromIdx = (page - 1) * PAGE_SIZE;
  const toIdx = fromIdx + PAGE_SIZE - 1;

  let q: any = supabase
    .from('checklist_records')
    .select(sel(CHECKLIST_LIGHT_COLUMNS), { count: 'exact' })
    .order('timestamp', { ascending: false })
    .range(fromIdx, toIdx);

  if (filters.status && filters.status !== 'todos') {
    q = q.eq('status', filters.status);
  }
  if (filters.checklistType && filters.checklistType !== 'todos') {
    if (filters.checklistType === 'empilhadeira') {
      // registros antigos podem ter checklist_type nulo
      q = q.or('checklist_type.eq.empilhadeira,checklist_type.is.null');
    } else {
      q = q.eq('checklist_type', filters.checklistType);
    }
  }
  const { from, to } = buildRange(filters);
  if (from) q = q.gte('timestamp', from);
  if (to) q = q.lt('timestamp', to);

  if (filters.operatorName) {
    q = q.eq('operator_name', filters.operatorName);
  }

  const search = filters.search?.trim();
  if (search) {
    const like = `%${search.replace(/[%,]/g, '')}%`;
    q = q.or(
      `equipment_code.ilike.${like},operator_name.ilike.${like},equipment_model.ilike.${like}`
    );
  }

  const { data: records, error, count } = await q;
  if (error) throw error;

  const rows = records || [];
  if (rows.length === 0) {
    return {
      records: [],
      total: count || 0,
      page,
      pageSize: PAGE_SIZE,
      totalPages: Math.max(1, Math.ceil((count || 0) / PAGE_SIZE)),
    };
  }

  const recordIds = rows.map((r: any) => r.id);

  const [approvalsResult, rejectionsResult] = await Promise.all([
    supabase
      .from('checklist_approvals')
      .select('checklist_record_id,mechanic_name,timestamp,comment')
      .in('checklist_record_id', recordIds),
    supabase
      .from('checklist_rejections')
      .select('checklist_record_id,mechanic_name,timestamp,reason')
      .in('checklist_record_id', recordIds),
  ]);

  const approvalsByRecord = new Map<string, any[]>();
  (approvalsResult.data || []).forEach((a: any) => {
    const list = approvalsByRecord.get(a.checklist_record_id) || [];
    list.push({ mechanicName: a.mechanic_name, timestamp: a.timestamp, comment: a.comment });
    approvalsByRecord.set(a.checklist_record_id, list);
  });

  const rejectionsByRecord = new Map<string, any[]>();
  (rejectionsResult.data || []).forEach((r: any) => {
    const list = rejectionsByRecord.get(r.checklist_record_id) || [];
    list.push({ mechanicName: r.mechanic_name, timestamp: r.timestamp, reason: r.reason });
    rejectionsByRecord.set(r.checklist_record_id, list);
  });

  const mapped = rows.map((record: any) => {
    const camel = keysToCamelCase(record);
    return {
      ...camel,
      photos: {},
      checklistAnswers: [],
      approvals: approvalsByRecord.get(record.id) || [],
      rejections: rejectionsByRecord.get(record.id) || [],
    };
  });

  return {
    records: mapped,
    total: count || 0,
    page,
    pageSize: PAGE_SIZE,
    totalPages: Math.max(1, Math.ceil((count || 0) / PAGE_SIZE)),
  };
};

export const useChecklistHistoryPaginated = (
  page: number,
  filters: ChecklistHistoryFilters,
  enabled = true,
) => {
  const queryClient = useQueryClient();

  const queryKey = [
    'checklists-page',
    page,
    filters.search || '',
    filters.status || 'todos',
    filters.checklistType || 'todos',
    filters.year || 'todos',
    filters.month || 'todos',
    filters.operatorName || '',
  ] as const;

  const query = useQuery({
    queryKey,
    queryFn: () => fetchPage(page, filters),
    enabled,
    placeholderData: keepPreviousData,
    staleTime: 5 * 60 * 1000,
    gcTime: 15 * 60 * 1000,
  });

  // Invalidação por realtime — leve, com debounce
  useEffect(() => {
    if (!enabled) return;
    let debounce: ReturnType<typeof setTimeout>;
    const invalidate = () => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ['checklists-page'] });
      }, 2000);
    };
    const channel = supabase
      .channel('checklists-page-rt')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'checklist_records' }, invalidate)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checklist_approvals' }, invalidate)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'checklist_rejections' }, invalidate)
      .subscribe();

    return () => {
      clearTimeout(debounce);
      supabase.removeChannel(channel);
    };
  }, [enabled, queryClient]);

  return query;
};
